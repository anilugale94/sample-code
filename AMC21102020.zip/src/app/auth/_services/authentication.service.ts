import { Injectable } from "@angular/core";
import { Http, Response } from "@angular/http";
import { HttpHeaders, HttpClient } from '@angular/common/http';
import "rxjs/add/operator/map";
import { Observable } from 'rxjs/observable';
import { environment } from '../../../environments/environment';
@Injectable()
export class AuthenticationService {

    constructor(private http: HttpClient) {
    }

    login(email: any, password: any): Observable<any> {
        return
    }
    logout() {
        //remove user from local storage to log user out
        localStorage.removeItem('Token');
        localStorage.removeItem('currentUser');

    }
}