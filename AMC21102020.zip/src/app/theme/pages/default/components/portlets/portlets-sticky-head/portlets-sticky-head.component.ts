import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
    selector: "app-portlets-sticky-head",
    templateUrl: "./portlets-sticky-head.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class PortletsStickyHeadComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}