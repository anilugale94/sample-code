import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
    selector: "app-widgets-recaptcha",
    templateUrl: "./widgets-recaptcha.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class WidgetsRecaptchaComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}