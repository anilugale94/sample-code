import { Component, OnInit, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Helpers } from '../../../helpers';
import { interval, Subscription } from 'rxjs';
import { LayoutService } from '../layout.service';
declare let mLayout: any;
@Component({
    selector: "app-aside-nav",
    templateUrl: "./aside-nav.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class AsideNavComponent implements OnInit, AfterViewInit {

    Count = 0;
    MACCount: number;
    MACsubscription: Subscription;
    constructor(private mainService: LayoutService) {

    }
    ngOnInit() {
        mLayout.initAside();
        const source = interval(1000);
        // this.MACsubscription = source.subscribe(val => this.getCount());

    }
    ngAfterViewInit() {


    }
    getCount() {
        var Status = 'UnApproved';
        this.mainService.GetMACID(Status).subscribe((data: any) => {
            if (data.length != 0) {
                this.MACCount = data[0]['UnseenCount'];
            } else {
                this.MACCount = 0;
            }
        });
    }
}