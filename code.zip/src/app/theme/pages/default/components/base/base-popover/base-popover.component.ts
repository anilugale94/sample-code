import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
    selector: "app-base-popover",
    templateUrl: "./base-popover.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class BasePopoverComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}