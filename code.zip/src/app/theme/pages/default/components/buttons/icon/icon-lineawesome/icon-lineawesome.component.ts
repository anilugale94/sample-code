import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
    selector: "app-icon-lineawesome",
    templateUrl: "./icon-lineawesome.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class IconLineawesomeComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}