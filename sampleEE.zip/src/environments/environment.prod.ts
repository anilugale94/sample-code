export const environment = {
    production: true,
    //baseUrl: 'http://eagleconstruction.co.in/api/'
    baseUrl :'http://192.168.0.56:91/api/'
};
