import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeComponent } from './theme/theme.component';
import { LayoutModule } from './theme/layouts/layout.module';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ReactiveFormsModule ,FormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ScriptLoaderService } from "./_services/script-loader.service";
import { ThemeRoutingModule } from "./theme/theme-routing.module";
import { AuthModule } from "./auth/auth.module";
import 'hammerjs'; 
import { ToastrModule } from 'ngx-toastr';
import { ConfirmDialogComponent } from './theme/pages/default/index/confirm-dialog/confirm-dialog.component';
import { MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatDialogModule} from '@angular/material';

@NgModule({
    declarations: [
        ThemeComponent,
        AppComponent,
        ConfirmDialogComponent
    ],
    imports: [
        CommonModule,
        LayoutModule,
        BrowserModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        ThemeRoutingModule,
        AuthModule,
        ReactiveFormsModule,
        HttpModule,
        FormsModule,

        MatToolbarModule,
        MatButtonModule,
        MatSidenavModule,
        MatIconModule,
        MatDialogModule,
        ToastrModule.forRoot()
    ],
    providers: [ScriptLoaderService],
    entryComponents:[ConfirmDialogComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }