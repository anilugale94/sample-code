import { Injectable } from "@angular/core";
import { Http, Response } from "@angular/http";
import { HttpHeaders,HttpClient }  from '@angular/common/http';
import "rxjs/add/operator/map";
import { Observable } from 'rxjs/observable';

@Injectable()
export class AuthenticationService {

    constructor(private http: HttpClient) {
    }

    login(email: string, password: string):Observable<any> {
        var body = 'MobileNo='+email+'&Password='+password+'&UserType=Admin';
        var headerOption = new HttpHeaders({'content-type':'application/x-www-form-urlencoded'});
        var requestOption = {headers:headerOption};
        return this.http.post('http://eagleconstruction.co.in/api/ADUserCheckLogin',body,requestOption); 
    }

    logout() {
        //remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }
}