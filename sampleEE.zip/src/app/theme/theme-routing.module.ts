import { NgModule } from '@angular/core';
import { ThemeComponent } from './theme.component';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from "../auth/_guards/auth.guard";

const routes: Routes = [
    {
        "path": "",
        "component": ThemeComponent,
        "canActivate": [AuthGuard],
        "children": [
            {
                "path": "index",
                "loadChildren": ".\/pages\/default\/index\/index.module#IndexModule"
            },
            {
                "path": "contractor",
                "loadChildren": ".\/pages\/default\/contractor\/contractor.module#ContractorModule"
            },
            {
                "path": "supplier",
                "loadChildren": ".\/pages\/default\/supplier\/supplier.module#SupplierModule"
            },
            {
                "path": "client",
                "loadChildren": ".\/pages\/default\/client\/client.module#ClientModule"
            },
            {
                "path": "employee",
                "loadChildren": ".\/pages\/default\/employee\/employee.module#EmployeeModule"
            },
            {
                "path": "enquiry",
                "loadChildren": ".\/pages\/default\/Enquiry\/enquiry.module#EnquiryModule"
            },
            {
                "path": "workorder",
                "loadChildren": ".\/pages\/default\/workorder\/workorder.module#WorkorderModule"
            }
        ]
    },


];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ThemeRoutingModule { }