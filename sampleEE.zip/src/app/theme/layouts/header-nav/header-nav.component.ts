import { Component, OnInit, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Helpers } from '../../../helpers';
import { LayoutsService } from '../layouts.service';
import { FormBuilder } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

declare let mLayout: any;
@Component({
    selector: "app-header-nav",
    templateUrl: "./header-nav.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class HeaderNavComponent implements OnInit, AfterViewInit {
    FirstName: any;
    LastName: any;
    EmailId: any;
    ImgUrl: string;
    FileToUpload:File=null;
    imgUrl: string;
    UserGroup: any;
    UserId = localStorage.getItem('currentUser');

    constructor(private LayoutService : LayoutsService,private formBuilder:FormBuilder,private toster:ToastrService) {

    }
    ngOnInit() {
        this.UserGroup = this.formBuilder.group({
            ImgUrl:['']
        })
        this.GetAllUser();
    }
    ngAfterViewInit() {

        mLayout.initHeader();

    }
    GetAllUser(){
        var UserId = localStorage.getItem("currentUser");
        this.LayoutService.GetAllUser(UserId).subscribe((data:any)=>{
            this.FirstName = data[0]['FirstName'];
            this.LastName = data[0]['LastName'];
            this.EmailId = data[0]['EmailId'];
            this.ImgUrl = data[0]['ImgUrl'];
           
        })
    }
    ImageChange(file:FileList){
        this.FileToUpload=file.item(0);
        var reader = new FileReader();
        reader.onload=(event:any)=>{
          this.imgUrl = event.target.result;
        }
        reader.readAsDataURL(this.FileToUpload);
        this.ProfileImg(this.UserId,this.FileToUpload);
      }
      ProfileImg(UserId,FileToUpload){
         this.LayoutService.ProfileImg(UserId,FileToUpload).subscribe(data=>{
            console.log(data);
            if(data == 'Updated'){
                this.toster.success("Update Profile Image.");
                this.GetAllUser();
            }else{
                this.toster.error("Please Try Again, Profile Image Not Updated.");
            }
         })   
      }
}