import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '@angular/http';
import "rxjs/add/operator/map";
@Injectable({
  providedIn: 'root'
})
export class LayoutsService {
  Url: string = 'http://library.alphamobi.co/api/';
  headerOption = new HttpHeaders({'content-type':'application/x-www-form-urlencoded'});
  requestOption = {headers:this.headerOption};

  constructor(private http : HttpClient) { }

  GetAllUser(UserId){
    var body = 'UserId='+UserId;
    return this.http.post(this.Url+'ADUserGetById',body,this.requestOption);
  }
  ProfileImg(UserId,FileToUpload){
      var formData:any = new FormData();
      formData.append("file",FileToUpload);
      return this.http.post(this.Url+'UIUserImgUpdate?UserId='+UserId,formData);
  }

}
