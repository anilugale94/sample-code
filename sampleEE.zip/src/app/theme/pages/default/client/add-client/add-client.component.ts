import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { FormBuilder, Validators } from '@angular/forms';
import { AlphamobiService } from '../../../default/index/services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../../../default/index/services/confirm-dialog.service';
import { interval,Subscription } from 'rxjs';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-client',
  templateUrl:'./add-client.component.html',
  styles: []
})
export class AddClientComponent implements OnInit {
ClientGroup;
  fileToUpload: File;
  imgUrl: any;
  dataSource;
  displayedColumns: string[] = ['CName','COffAddress','CBillAddress','CWebUrl','ProName','ProAddress','DepId','EmailId','MobileNo','AlternateNo','SiteImg','SiteImg2','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  ClientId: any;
  User: any;
  DepList: any;
  fileToUpload2: File;
  imgUrl2: any;

  constructor(private mainService: AlphamobiService,
    private formBuilder: FormBuilder,
    private toaster:ToastrService,
    private router:Router,
    private Dialog:ConfirmDialogService,) { }

  ngOnInit() {
    this.ClientGroup = this.formBuilder.group({
      ClientId:[null],
      CName:['',Validators.required],
      COffAddress:['',Validators.required],
      CBillAddress:['',Validators.required],
      CWebUrl:['',Validators.required], 
      ProName:['',Validators.required],
      ProAddress:['',Validators.required],
      DepId:[''],
      MobileNo:['',Validators.required],
      AlternateNo:[''],
      EmailId:['',[Validators.required,Validators.email]],
      ImgUrl:[''],
      ImgUrl2:['']
    }); 
  
    this.reset();
    this.GetAllClient();  
    this.GetAllDep();
 
  }
  reset(){
    this.ClientGroup.reset();
  }
  ImageChange(file:FileList){
    this.fileToUpload = file.item(0);
    var reader = new FileReader();
    reader.onload=(event:any)=>{
      this.imgUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }
  ImageChange2(file:FileList){
    this.fileToUpload2 = file.item(0);
    var reader = new FileReader();
    reader.onload=(event:any)=>{
      this.imgUrl2 = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload2);
  }
 
  GetAllDep() {
    this.mainService.GetAllDepartment().subscribe((Catlist: any) => {
      if(Catlist != null ){
        if(Catlist.length != 0){
          this.DepList = Catlist;
        }else{
          this.toaster.error("No Data Found");
        }
      }else{
        this.toaster.error("No Data Found");
      }
    },error=>{
      this.router.navigate(['/index/Error']);
    });
  }
  GetAllClient() {
    this.mainService.GetAllClient().subscribe((Catlist: any) => {
      if(Catlist != null ){
        if(Catlist.length != 0){
          this.dataSource = new MatTableDataSource(Catlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("No Data Found");
        }
      }else{
        this.toaster.error("No Data Found");
      }
    },error=>{
      this.router.navigate(['/index/Error']);
    });
  }
  SaveImg1(ClientId,fileToUpload){
    this.mainService.SaveClientSiteImg1(ClientId,fileToUpload).subscribe((data)=>{
        if(data == 'Updated'){
        }else{
          this.toaster.error("Client Site Image Is Not Upload, Please Try Again");
        }
    });
  }
  SaveImg2(ClientId,fileToUpload2){
    this.mainService.SaveClientSiteImg2(ClientId,fileToUpload2).subscribe((data)=>{
      if(data == 'Update'){
        this.toaster.error("Client Site Image Is Not Upload, Please Try Again");
      }
    });
  }
  OnSave(ClientGroup){
    var formValue = this.ClientGroup.value;
    this.SaveClient(formValue);
  }
  SaveClient(formValue){
    this.ClientId = formValue.ClientId;
    if(this.ClientId == null){
      this.mainService.SaveClient(formValue).subscribe((data:any)=>{
          if(data == 'Exist'){
            this.toaster.error('Client Is Already Exist.');
          }else if(data != 0){
              this.SaveImg1(data,this.fileToUpload);
              this.SaveImg2(data,this.fileToUpload2);
              this.toaster.success("Client Is Save Successfully.");
              this.reset();
              this.GetAllClient();
           
          }else{
            this.toaster.error("Data Not Save, Please Try Again.");
          }
      },error=>{
        this.router.navigate(['/index/Error']);
      });
    }else{

      this.mainService.UpdateClient(formValue).subscribe((data:any)=>{
        if(data != null){
          if(data == 'Updated'){
            if(this.fileToUpload != null){
              this.SaveImg1(this.ClientId,this.fileToUpload);
            }
            if(this.fileToUpload2 != null){
              this.SaveImg2(this.ClientId,this.fileToUpload2);
            }
            this.toaster.success("Client Is Update Successfully.");
            this.reset();
            this.GetAllClient();
          }else if(data == 'Exist'){
            this.toaster.error('Client Is Already Exist.');
          }else{
            this.toaster.error("Data Not Update, Please Try Again.");
          }
        }else {
          this.toaster.error("Data Not Update, Please Try Again.");
        }
      },error=>{
        this.router.navigate(['/index/Error']);
      });
    }
  }
  Edit(ClientId){
    this.mainService.GetClientById(ClientId).subscribe((data:any)=>{

      if(data != null || data.length != 0){
        this.ClientGroup.controls['ClientId'].setValue(data[0]['ClientId']);
        this.ClientGroup.controls['CName'].setValue(data[0]['CompanyName']);
        this.ClientGroup.controls['COffAddress'].setValue(data[0]['CompOfficeAddr']);
        this.ClientGroup.controls['CBillAddress'].setValue(data[0]['CompBillingAddr']);
        this.ClientGroup.controls['CWebUrl'].setValue(data[0]['CompWebUrl']);
        this.ClientGroup.controls['ProName'].setValue(data[0]['ProjName']);
        this.ClientGroup.controls['ProAddress'].setValue(data[0]['SiteAddr']);
        this.ClientGroup.controls['DepId'].setValue(data[0]['DepartmentId']);
        this.ClientGroup.controls['AlternateNo'].setValue(data[0]['AlternateMobNo']);
        this.ClientGroup.controls['MobileNo'].setValue(data[0]['MobileNo']);
        this.ClientGroup.controls['EmailId'].setValue(data[0]['EmailId']);
        this.imgUrl = 'http://eagleconstruction.co.in/'+ data[0]['SiteImgUrl1'];
        this.imgUrl2 = 'http://eagleconstruction.co.in/'+ data[0]['SiteImgUrl2'];
        this.ScrollTop();
        
      }else{
        this.toaster.error("Data Not Found");
      }
    },error=>{
      this.router.navigate(['/index/Error']);
    })
  }
  Delete(ClientId){
    this.Dialog.openConfirmationDialog("Are You Sure Delete Client?").afterClosed().subscribe(res=>{
  
   if(res){
      this.mainService.DeleteClient(ClientId).subscribe((data:any)=>{
        if(data.length != 0){
          if(data != null){
            this.toaster.success("Client Is Successfully Deleted.");
            this.GetAllClient();
            this.reset();
          }else{
            this.toaster.error("Client Is Not Deleted, Please Try Again.");
          }
        }else{
          this.toaster.error("Client Is Not Deleted, Please Try Again.");
        }
      },error=>{
        this.router.navigate(['/index/Error']);
      })
    }
    })
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
}
numberOnly(event): boolean {
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

ScrollTop() {
  let scrollToTop = window.setInterval(() => {
      let pos = window.pageYOffset;
      if (pos > 0) {
        window.scrollTo(0, 0)
          //window.scrollTo(0, pos - 20); // how far to scroll on each step
      } else {
          window.clearInterval(scrollToTop);
      }
    }, 0);
  }
}
