import { NgModule } from '@angular/core';
import { CommonModule,DatePipe } from '@angular/common';
import { WorkorderComponent } from './workorder.component';
import { AddWorkorderComponent } from './add-workorder/add-workorder.component';
import { ReactiveFormsModule ,FormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { ToastrModule } from 'ngx-toastr';
import { HttpClientModule } from '@angular/common/http';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { MatToolbarModule, MatButtonModule, MatCheckboxModule, MatSidenavModule, MatIconModule, MatListModule,MatInputModule,MatTableModule,MatPaginatorModule,MatSortModule,MatSelectModule,MatMenuModule,MatGridListModule, MatDialogModule,MatTooltipModule,MatDatepickerModule,MatNativeDateModule, MatProgressSpinnerModule, MatAutocompleteModule } from '@angular/material';
import { DefaultComponent } from '../default.component';
import { LayoutModule } from '../../../layouts/layout.module';
import { AlphamobiService } from '../index/services/alphamobi.service';
import { ConfirmDialogService } from '../index/services/confirm-dialog.service';
import { RouterModule, Routes } from '@angular/router';

const routes :Routes = [
    {
      path:"",
      component:DefaultComponent,
      children:[
        {
          path:"Add_Workorder",
          component:AddWorkorderComponent
        }
      ]
    }
  ];   

@NgModule({
  declarations: [WorkorderComponent, AddWorkorderComponent],
  imports: [
    CommonModule,RouterModule.forChild(routes),
    LayoutModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatSelectModule,
    MatMenuModule,
    MatGridListModule,
    MatCheckboxModule,
    MatDialogModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatAutocompleteModule,
    OwlDateTimeModule, 
    OwlNativeDateTimeModule,
    ToastrModule.forRoot()
  ],
  exports: [
    RouterModule
  ],
  providers:[AlphamobiService,MatDatepickerModule,DatePipe,ConfirmDialogService],
})
export class WorkorderModule { }
