import { Component, OnInit ,ViewChild} from '@angular/core';
import { AlphamobiService } from '../../index/services/alphamobi.service';
import { FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import {MatTableDataSource,MatSort,MatPaginator} from '@angular/material';
import { ConfirmDialogService } from '../../index/services/confirm-dialog.service';

class Enquiry{
  Dia:any;
  Depth:any;
  Unit:any;
  DrillDia: any;
  DrillDepth: any;
  BarDia: any;
  BarDepth: any;
  AnchorDia: any;
  AnchorDepth: any;
  Height: any;
  Length: any;
  TotalSQFT: any;
  TotHoleQTY: any;
  PerDayHoleQty: any;
  CompProd: any;
  Company: any;
  SelAnchorFastner: any;
  PerDaySQFTQTY: any;
  RateReq: any;
}



@Component({
  selector: 'app-add-workorder',
  templateUrl:'./add-workorder.component.html',
  styles: []
})
export class AddWorkorderComponent implements OnInit {
  dataSource;
  WorkOrderGroup: any;

  displayedColumns: string[] = ['UserName','projectName','BuilderName','BuildingName','FloorName','PlotName','WorkDestinationName','OrientationName','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
 
  buildingList: any;
  projectList: any;
  floorList: any;
  flatList: any;
  serviceList: any;
  worklist: any;
  AllBuilder: any;
  DrillDia: any;
  PerDaySQFTQTY: any;
  Height: any;
  Length: any;
  CompanyProd: any;
  Company: any;
  CoreDepth: any;
  CoreDia: any;
  TotalHoleqTY: any;
  PerDayHoleQty: any;
  BarDia: any;
  BarDepth: any;
  AnchorFastner: any;
  AnchorDia: any;
  AnchorDepth: any;
  filled= [];
  AllRate: any;
  ProjbuildingList: any;
  RateReq: boolean;
  AllOrientation: any;
  WorkOrderId: any;
  FormValue: any;
  AllManager: any;
  TotalSQFT:any;

  constructor(private mainService:AlphamobiService,
    private toaster:ToastrService, private formBuilder:FormBuilder,
    private router:Router, private dialog:ConfirmDialogService) { }

  ngOnInit() {
    this.WorkOrderGroup = this.formBuilder.group({
      WorkOrderId:[''],
      ProjectId:[''],
      ProjManager:[''],
      BuildingId:[''],
      FloorId:[''],
      PlotId:[''],
      service:[''],
      Workdest:[''],
      Dia:[''],
      Depth:[''],
      PerDayHoleQty:[''],
      TotalHoleQTY:[''],
      DrillDia:[''],
      BarDia:[''],
      BarDepth:[''],
      AnchorDia:[''],
      AnchorDepth:[''],
      Height:[''],
      Length:[''],
      TotalSQFT:[''],
      PerDaySQFTQTY:[''],
      RateReq:[''],
      BuilderId:[''],
      orientation:[''],
      order:['']
      
      //ProjectId:[''],

    });
    this.GetAllManager();
    this.GetAllWorkOrder();
    this.GetAllOrientaion();
    this.GetAllRateUnit();
    this.GetAllWorkDestination();
    this.GetAllService();
    this.GetAllBuilder();
    
  }

  GetAllManager(){
    this.mainService.UserGetByManager().subscribe((Projlist: any) => {
      if(Projlist.length != 0){
        if(Projlist != null){
          this.AllManager = Projlist;
        }else{
          this.toaster.error("Manager Not Found");
        }
      }else{
        this.toaster.error("Manager Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }







  GetAllOrientaion(){
    this.mainService.GetAllOrientation().subscribe((Projlist: any) => {
      if(Projlist.length != 0){
        if(Projlist != null){
          this.AllOrientation = Projlist;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }
  GetAllWorkOrder() {
    this.mainService.GetAllWorkOrder().subscribe((Catlist: any) => {
      if(Catlist.length != 0){
        if(Catlist != null){
          this.dataSource = new MatTableDataSource(Catlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Work Order Not Found");
        }
      }else{
        this.toaster.error("Work Order Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }


  GetAllBuilder() {
    this.mainService.GetAllBuilderName().subscribe((Catlist: any) => {
  
      if(Catlist.length != 0){
        if(Catlist != null){
         this.AllBuilder =Catlist;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
        this.AllBuilder = '';
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }


  GetAllWorkDestination() {
    this.mainService.GetAllWorkDestination().subscribe((Catlist: any) => {
      if(Catlist.length != 0){
        if(Catlist != null){
          this.worklist = Catlist;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }

  GetAllService(){
    this.mainService.GetByAllService().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
         this.serviceList = data;
        }else{
          this.toaster.error("Service not found");
        }
      }else{
        this.toaster.error("Service not found");
      
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }

  GetAllFloor(event){
    if(event.value > 0){
      var BuildingId = event.value;
     }else if(event > 0){
      var BuildingId = event;
     }
    this.mainService.GetFloorByBuildingId(BuildingId).subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
         this.floorList = data;
        }else{
          this.toaster.error("Floor not found");
        }
      }else{
        this.toaster.error("Floor not found");
        this.floorList = '';
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  GetAllFlat(event){
    if(event.value > 0){
      var FloorId = event.value;
     }else if(event > 0){
      var FloorId = event;
     }
    this.mainService.GetPlotGetByFloorId(FloorId).subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
         this.flatList = data;
        }else{
          this.toaster.error("Flat not found");
        }
      }else{
        this.toaster.error("Flat not found");
        this.flatList = '';
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  
  GetAllproject(event){
   if(event.value > 0){
    var BuilderId = event.value;
   }else if(event > 0){
    var BuilderId = event;
   }
    this.mainService.ProjectGetByBuilderId(BuilderId).subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
         this.ProjbuildingList = data;
        }else{
          this.toaster.error("Project not found");
        }
      }else{
        this.toaster.error("Project not found");
        this.ProjbuildingList = '';
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  GetAllBuilding(event){
    if(event.value > 0){
      var projectId = event.value;
     }else if(event > 0){
      var projectId = event;
     }
    this.mainService.GetBuildingByProjectId(projectId).subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
         this.buildingList = data;
        }else{
          this.toaster.error("Building not found");
        }
      }else{
        this.toaster.error("Building not found");
        this.buildingList = '';
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }

  GetAllRateUnit(){
    this.mainService.GetAllRateReqUnit().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.AllRate =data;
        }else{
          this.toaster.error("RateUnit Is Not Found");
        }
      }else{
        this.toaster.error("RateUnit Is Not Found");
      }
    },error =>{
      this.router.navigate(['/index/Error']);
    })
  }


  reset()
  {
    this.WorkOrderGroup.reset();
  }
  OnSaveWorkOrder(WorkOrderGroup){
    this.FormValue = this.WorkOrderGroup.value;
    this.SaveWorkOrder(this.FormValue);
  }
  SaveWorkOrder(FormValue){
    
    this.WorkOrderId = FormValue.WorkOrderId;
    if(this.WorkOrderId == null){ 
      this.mainService.SaveWorkOrder(FormValue).subscribe(data=>{
        if(data == 'Saved'){
        this.toaster.success("Work Order Save Successfully.");
        this.GetAllWorkOrder();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Work Order Is Already Exist.");
        }
      },error =>{ 
          this.router.navigate(['/index/Error']);
        });
    
    }else{
    this.mainService.UpdateWorkOrder(FormValue).subscribe(data=>{
      if(data == 'Updated'){
        this.toaster.success("Work Order Update Successfully.");
        this.GetAllWorkOrder();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Work Order Is Already Exist.");
        }
      },error =>{ 
        this.router.navigate(['/index/Error']);
      });
    }
  } 

  Delete(WorkOrderId){
    this.dialog.openConfirmationDialog("Are Sure Delete Work order?").afterClosed().subscribe(res=>{
      if(res){
      this.mainService.DeleteWorkOrder(WorkOrderId).subscribe(data=>{
        if(data == "Deleted"){
          this.toaster.success("Work Order Delete Successfully.");
          this.GetAllWorkOrder();
          this.reset();
        }else{
          this.toaster.error("Work Order Is Not Delete,Please Try Again.");
        }
      },error =>{ 
          this.router.navigate(['/index/Error']);
        });
      }
    });
  }
  Edit(WorkOrderId){
    this.mainService.GetWorkOrderById(WorkOrderId).subscribe((data:any)=>{
      if(data!=null){
        if(data.length != 0){
          this.WorkOrderGroup.controls['WorkOrderId'].setValue(data[0]['WorkOrderId']);
          this.WorkOrderGroup.controls['order'].setValue(data[0]['OrderNo']);
          this.WorkOrderGroup.controls['ProjManager'].setValue(data[0]['UserId']);
          this.WorkOrderGroup.controls['BuilderId'].setValue(data[0]['BuilderId']);
          this.WorkOrderGroup.controls['ProjectId'].setValue(data[0]['ProjectId']);
          this.WorkOrderGroup.controls['BuildingId'].setValue(data[0]['BuildingId']);
          this.WorkOrderGroup.controls['FloorId'].setValue(data[0]['FloorId']);
          this.WorkOrderGroup.controls['PlotId'].setValue(data[0]['PlotId']);
          this.WorkOrderGroup.controls['Workdest'].setValue(data[0]['WorkDestinationId']);
          this.WorkOrderGroup.controls['orientation'].setValue(data[0]['OrientationId']);
        
          this.GetAllproject(data[0]['BuilderId']);
          this.GetAllBuilding(data[0]['ProjectId']);
          this.GetAllFloor(data[0]['BuildingId']);
          this.GetAllFlat(data[0]['FloorId']);

        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },
    error =>{ 
      this.router.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }

  ShowHide(event){
    if(event.value == 1)//Core Cuting
    {
      this.CoreDepth =true;
      this.CoreDia = true;
      this.TotalHoleqTY = true;
      this.PerDayHoleQty = true;
      this.RateReq = true;

      this.DrillDia = false;
      this.BarDia = false;
      this.BarDepth = false;
      this.Company = false;
      this.CompanyProd = false;
      this.AnchorFastner = false;
      this.AnchorDia = false;
      this.AnchorDepth = false;
      this.Length = false;
      this.Height = false;
      this.PerDaySQFTQTY = false;
    }else if(event.value == 2){ //Rebiring
     this.Company = true;
     this.CompanyProd = true;
     this.DrillDia = true;
     this.BarDia = true;
     this.BarDepth = true;
     this.TotalHoleqTY = true;
     this.PerDayHoleQty = true;
     this.RateReq = true;

     this.CoreDepth =false;
     this.CoreDia = false;
     this.AnchorFastner = false;
     this.AnchorDia = false;
     this.AnchorDepth = false;
     this.Length = false;
     this.Height = false;
     this.PerDaySQFTQTY = false;
    }else if(event.value == 3){ //Chemical Anchor
      this.Company = true;
      this.CompanyProd = true;
      this.DrillDia = true;
      this.AnchorDepth = true;
      this.AnchorDia = true;
      this.TotalHoleqTY = true;
      this.PerDayHoleQty = true;
      this.AnchorFastner = true;
      this.RateReq = true;
 
      this.CoreDepth =false;
      this.CoreDia = false;
      this.BarDia = false;
      this.BarDepth = false;
      this.Length = false;
      this.Height = false;
      this.PerDaySQFTQTY = false;
    }else if(event.value == 4){ //Mechanical Anchor
    this.Company = true;
    this.CompanyProd = true;
    this.DrillDia = true;
    this.AnchorDepth = true;
    this.AnchorDia = true;
    this.TotalHoleqTY = true;
    this.PerDayHoleQty = true;
    this.AnchorFastner = true;
    this.RateReq = true;

    this.CoreDepth =false;
    this.CoreDia = false;
    this.BarDia = false;
    this.BarDepth = false;
    this.Length = false;
    this.Height = false;
    this.PerDaySQFTQTY = false;
  }else if(event.value == 5){ // Painting 
    this.Company = true;
    this.CompanyProd = true;
    this.Length = false;
    this.Height = false;
    this.PerDaySQFTQTY = false;

    this.DrillDia = false;
    this.AnchorDepth = false;
    this.AnchorDia = false;
    this.TotalHoleqTY = false;
    this.PerDayHoleQty = false;
    this.AnchorFastner = false;
    this.CoreDepth = false;
    this.CoreDia = false;
    this.BarDia = false;
    this.BarDepth = false;
  }

}


add(formValue) {
  var T= new Enquiry();
  var FormValue = formValue.value;
  
  T.Dia = FormValue.Dia;
  T.Depth = FormValue.Depth;
  T.DrillDia = FormValue.DrillDia;
  T.BarDia =FormValue.BarDia;
  T.BarDepth =FormValue.BarDepth;
  T.AnchorDia =FormValue.AnchorDia;
  T.AnchorDepth =FormValue.AnchorDepth;
  T.Height =FormValue.Height;
  T.Length =FormValue.Length;
  T.TotalSQFT =FormValue.TotalSQFT;
  T.PerDayHoleQty =FormValue.PerDayHoleQty;
  T.CompProd = FormValue.CompProd;
  T.Company =FormValue.Company;
  T.SelAnchorFastner =FormValue.SelAnchorFastner;
  T.PerDaySQFTQTY =FormValue.PerDaySQFTQTY;
  T.TotHoleQTY = FormValue.TotalHoleQTY;
  T.RateReq =FormValue.RateReq;


  if(T.Dia == ""){T.Dia = 0} 
  if(T.Depth == ""){T.Depth = 0 }
  if(T.DrillDia == ""){T.DrillDia =0}
  if(T.BarDia == ""){T.BarDia =0}
  if(T.BarDepth == ""){T.BarDepth =0}
  if(T.AnchorDia == ""){T.AnchorDia =0}
  if(T.AnchorDepth == ""){T.AnchorDepth =0}
  if(T.Height == ""){T.Height =0}
  if(T.Length == ""){T.Length =0}
  if(T.TotalSQFT == ""){T.TotalSQFT =0}
  if(T.PerDayHoleQty == ""){T.PerDayHoleQty =0}
  if(T.CompProd == ""){T.CompProd =0}
  if(T.Company == ""){T.Company =0}
  if(T.SelAnchorFastner == ""){T.SelAnchorFastner =0}
  if(T.PerDaySQFTQTY == ""){T.PerDaySQFTQTY =0}
  if(T.TotHoleQTY ==""){T.TotHoleQTY =0}
  if(T.RateReq ==""){T.RateReq =0}
  this.filled.push(T);

 this.WorkOrderGroup.controls['Dia'].setValue("");
 this.WorkOrderGroup.controls['ProjType'].setValue("");
 this.WorkOrderGroup.controls['ScopeReq'].setValue("");
 this.WorkOrderGroup.controls['Orientation'].setValue("");
 this.WorkOrderGroup.controls['Depth'].setValue("");
 this.WorkOrderGroup.controls['DrillDia'].setValue("");
 this.WorkOrderGroup.controls['BarDia'].setValue("");
 this.WorkOrderGroup.controls['BarDepth'].setValue("");
 this.WorkOrderGroup.controls['AnchorDia'].setValue("");
 this.WorkOrderGroup.controls['AnchorDepth'].setValue("");
 this.WorkOrderGroup.controls['Height'].setValue("");
 this.WorkOrderGroup.controls['Length'].setValue("");
 this.WorkOrderGroup.controls['TotalSQFT'].setValue("");
 this.WorkOrderGroup.controls['CompProd'].setValue("");
 this.WorkOrderGroup.controls['Company'].setValue("");
 this.WorkOrderGroup.controls['PerDaySQFTQTY'].setValue("");
 this.WorkOrderGroup.controls['SelAnchorFastner'].setValue("");
 this.WorkOrderGroup.controls['RateReq'].setValue("");
 this.WorkOrderGroup.controls['TotalHoleQTY'].setValue("");
 this.WorkOrderGroup.controls['PerDayHoleQty'].setValue("");
 
 }
 DeleteService(i){
 this.filled.splice(i,1);
} 
numberOnly(event): boolean {
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
} 
applyFilter(filterValue: string) {
this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
