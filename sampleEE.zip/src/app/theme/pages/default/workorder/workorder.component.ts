import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workorder',
  templateUrl: './workorder.component.html',
  styles: []
})
export class WorkorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
