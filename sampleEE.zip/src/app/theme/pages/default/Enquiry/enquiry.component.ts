import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styles: []
})
export class EnquiryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
