import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { EnquiryComponent } from './enquiry.component';
import { EnquriyListComponent } from './enquriy-list/enquriy-list.component';
import { DefaultComponent } from '../default.component';
import { AlphamobiService } from '../index/services/alphamobi.service';
import { MatDatepickerModule, MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatListModule, MatInputModule, MatTableModule, MatPaginatorModule, MatSortModule, MatSelectModule, MatMenuModule, MatGridListModule, MatCheckboxModule, MatDialogModule, MatTooltipModule, MatNativeDateModule, MatProgressSpinnerModule, MatAutocompleteModule } from '@angular/material';
import { ConfirmDialogService } from '../index/services/confirm-dialog.service';
import { LayoutModule } from '../../../layouts/layout.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { ToastrModule } from 'ngx-toastr';
import { EnquiryDetailsComponent } from './enquiry-details/enquiry-details.component';
import {GoogleMapsAPIWrapper,AgmCoreModule} from '@agm/core';
import { MatGoogleMapsAutocompleteModule } from '@angular-material-extensions/google-maps-autocomplete';


const routes:Routes=[
  {
    path:'',
    component:DefaultComponent,
    children:[
      { path:'Enquiry',component:EnquriyListComponent },
      { path:'Enquiry_Details/:EnquiryId',component:EnquiryDetailsComponent }
    ]
  }
];

@NgModule({
  declarations: [
    EnquiryComponent, 
    EnquriyListComponent, EnquiryDetailsComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    LayoutModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatSelectModule,
    MatMenuModule,
    MatGridListModule,
    MatCheckboxModule,
    MatDialogModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatAutocompleteModule,
    OwlDateTimeModule, 
    OwlNativeDateTimeModule,
    AgmCoreModule.forRoot({apiKey: 'AIzaSyBeH7lTVqyo9DIaknhUaFBBbMvEvviTIWI',libraries: ["places"]}),
    MatGoogleMapsAutocompleteModule.forRoot(),
    ToastrModule.forRoot()
  ],
  providers:[AlphamobiService,MatDatepickerModule,DatePipe,ConfirmDialogService,GoogleMapsAPIWrapper],
})
export class EnquiryModule { }
