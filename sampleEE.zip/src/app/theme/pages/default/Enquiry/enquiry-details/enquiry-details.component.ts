import { Component, OnInit, ViewChild} from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort} from '@angular/material';
import { FormBuilder, Validators } from '@angular/forms';
import { AlphamobiService } from '../../index/services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute,Router} from '@angular/router'; 
import { Enquiry } from './enquiry';
import * as jsPDF from 'jspdf';
// import 'jspdf-autotable';
import * as html2canvas from "html2canvas";
class CalData{
  Service:any;
  Dia:any;
  Depth:any;
  Hole:any;
  Quantity:any;
  Unit:any;
  Rate:any
  Total:any;
}
@Component({
  selector: 'app-enquiry-details',
  templateUrl: './enquiry-details.component.html',
  styles: []
})
export class EnquiryDetailsComponent implements OnInit {
  EnquiryId: string;
  enquiryDetails=[];
  displayedColumns: string[] = ['QNo','Qversion','Service','Dia','Depth','Hole','Quantity','Unit','Rate','Total','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

 TableData=[{QNo:"Q001",Qversion:"02",Service: "MNGL GAS PIPE LINE", Dia: "0", Depth: "0", Hole: "0", Quantity: "150",Unit:"MM",Rate:"10",Total:"1500"},
          {QNo:"Q001",Qversion:"01",Service: "Core Cutting", Dia: "12", Depth: "3", Hole: "5", Quantity: "10",Unit:"CM",Rate:"20",Total:"200"},
          {QNo:"Q001",Qversion:"00",Service: "Pop Services", Dia: "0", Depth: "0", Hole: "0", Quantity: "200",Unit:"Inches",Rate:"40",Total:"8000"}]
  dataSource;
  Total: any;
  QuotationGroup:any;
  EnqService: any;
  EnqServiceQuotation: any;
  QuotationDetails=[];
  QuotTbl: boolean;
 
  

  constructor(private activeRoute:ActivatedRoute,
    private mainService: AlphamobiService,
    private toaster:ToastrService,
    private router:Router,
    private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.QuotationGroup = this.formBuilder.group({
      Qty:[''],
      rate:['']
    })
    this.activeRoute.params.subscribe(param=>{
      this.EnquiryId = atob(param['EnquiryId']);
    });
    this.GetEnquiryById();
    this.GetAllData();
    this.GetServiceByEnqId();
  }
  GetEnquiryById(){
    this.mainService.GetEnqiryById(this.EnquiryId).subscribe((data:any)=>{
      this.enquiryDetails = data;
      console.log("dfds",this.enquiryDetails);
    });
  }
  GetServiceByEnqId(){
    this.mainService.GetEnqiryServiceByEnqId(this.EnquiryId).subscribe((data:any)=>{
      this.EnqService = data;
      for(let i=0;i<this.EnqService.length;i++){
        var ServiceId = this.EnqService[i]['EnquiryServiceId'];
        if(ServiceId != null){
          this.mainService.GetQuotationGetByEnquiryId(this.EnquiryId).subscribe((QuoList:any)=>{
            this.EnqServiceQuotation = QuoList;
            var QuotArray = new Enquiry();
            QuotArray.RoleWorkCategoryName = this.EnqService[i]['RoleWorkCategoryName'];
            QuotArray.ProjectTypeName = this.EnqService[i]['ProjectTypeName'];
            QuotArray.OrientationName = this.EnqService[i]['OrientationName'];
            QuotArray.CompanyName = this.EnqService[i]['CompanyName'];
            QuotArray.ProductName = this.EnqService[i]['ProductName'];
            QuotArray.RateRequiredInId = this.EnqService[i]['RateRequiredInName'];

            QuotArray.CoreDia = this.EnqServiceQuotation[0]['CoreDia'];
            QuotArray.CoreDepth = this.EnqServiceQuotation[0]['CoreDepth'];
            QuotArray.TotalHoleQty = this.EnqServiceQuotation[0]['TotalHoleQty'];
            QuotArray.HoleQtyPerDay = this.EnqServiceQuotation[0]['HoleQtyPerDay'];
            QuotArray.DrillDia = this.EnqServiceQuotation[0]['DrillDia'];
            QuotArray.BarDia = this.EnqServiceQuotation[0]['BarDia'];
            QuotArray.BarDepth = this.EnqServiceQuotation[0]['BarDepth'];
            QuotArray.DrillDia = this.EnqServiceQuotation[0]['DrillDia'];
            QuotArray.AnchorDia = this.EnqServiceQuotation[0]['AnchorDia'];
            QuotArray.AnchorDepth = this.EnqServiceQuotation[0]['AnchorDepth'];
            QuotArray.AnchorFastnerName = this.EnqServiceQuotation[0]['AnchorFastnerName'];
            QuotArray.Height = this.EnqServiceQuotation[0]['Height'];
            QuotArray.Length = this.EnqServiceQuotation[0]['Length'];
            QuotArray.TotalSqFt = this.EnqServiceQuotation[0]['TotalSqFt'];
            QuotArray.SqFtQtyPerDay = this.EnqServiceQuotation[0]['SqFtQtyPerDay'];
            QuotArray.QuoNumber = this.EnqServiceQuotation[0]['QuoNumber'];
            QuotArray.QuoVersion = this.EnqServiceQuotation[0]['Version'];
            // QuotArray.Rate = this.EnqServiceQuotation[0]['Rate'];
            QuotArray.Rate = 1;
            QuotArray.Total = 1 * this.EnqServiceQuotation[0]['TotalHoleQty'];
            this.QuotationDetails.push(QuotArray);
    
          },error=>{
            this.router.navigate(['/index/Error']);
          })  
        }
      }
    },error=>{
      this.router.navigate(['/index/Error']);
    })
    console.log(this.QuotationDetails);
  }
  
  GetAllData(){
    this.dataSource = new MatTableDataSource(this.TableData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  QuantityTotal(value,Rate,index){
    this.Total = value*Rate;
    this.QuotationDetails[index]['Total'] = this.Total;
    this.QuotationDetails[index]['TotalHoleQty'] = value;
  }
  RateTotal(value,Qty,index){
    this.Total = value*Qty;
    this.QuotationDetails[index]['Total'] = this.Total;
    this.QuotationDetails[index]['Rate'] = value;
  }
 GenrateQuotation(QuotationGroup){
   this.QuotTbl = true;
 // console.log(this.filled);
  //this.onPrint();
  }
  onPrint(){
  var imgData = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABkCAYAAABkW8nwAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAEKNJREFUeNrsnXt0XNV1xn/n3DsPPSxZsiRjSX6Uh4HgGAwFWgMhpG1a2jRpUgNtyiokXU1pSVoILbRZad5pIQ/SR1ZKG1ZCE9I0ZKWri5ZQVhMIaSiUGIwNNsRgCH5JlmRpRhq95nFv/9h7rLE8kkbSjDSSzrfWWaO5I82M7v3u/vbZZ+99TBiGODiUG9adAgdHLIclA7+UX9p527kAhLksjeduY81VOwiNBZHRDcCNQAgcArqBYzqOLvUTFHo+fu/rEARk156OyWWW0/VvA9YB7UACePLEK9EavGe+i/f8YxCNn/KHDR/aNX9iTYFa4HrgI0DHpNcGdSSBLuA1HT/VMVAw0u7+rgiiQDOwWsdG4Ex9PF1J1VgwRoEHgE8Ary6IxQKuAo4AB43nZW00/uYgDD8dZjOXUNz5b9DRCZxX5PURJVyXWrYjwAHgdeAVtXRj+s86TO3GxPUG36DjDGCTWqC1BY+1JbxfDXAD8KsY8zm8yJewXqrAiHjAULmJ9QXgHIzdM97XM5Tc/cQV0aaWSLS1AxOrExU0BoKAMAggDEqxdmfomIw0MFxg4V5WiT2sxHtdLd1KQocSp1N/3lRAoo1KsMic3tkYsB4YK9cxpJXM6F322MvXmuSxr2HtmcCbgZeA3wKCchIrBGLG2otHuw8xcuRV/Jo6vNoGIqvXUNu+Eb91PZGGJvxVqzGxWsIgB7kcIaH4YqWHNaI6moALi0jsAHAc+ImOvUrCXrWAS9UJalbrcppK1tlq7TeolDWpVZkHjBDJGLBWCJUZx6SOw3ASr/8I9B3GDPZhRgcvIpu5CD+a/+ODygPKTSz5ap6H8TxymQy5RC/pgR5Sr+7DGEOkvpFIUyuRNWupaesg2n46NlaLjcYwkRhhkCPMZWdDsqkkdmMR0uV9uUPAbuA5YA/QB4xXme+zuoA4F6kl2gisB+rL+mnGgPWFRLmMEGlsCJPowvR3Yfu7Mak+GE5CEEyQz1q1YicQzOZj5+y8G2tPRCuMHsuMDJEeSsDB/Qx6PiYSJdq4hljLOiJt64k1txJt7cDE6/R/NoSly+dMWKcD4Dp9HAZ2AY8Dj+kIFoFMq4BfAi4Bfg7YpsdM+UlUKGshZNPY4wch2Ycd6MIMdGEG+yCbgVxWvTVPybfA4YbSyeZhrHfCyIXZLGO9XYweOwR7n8aP1WJr64k2tVDb/jP4LR1EGpvwVzVNyGcQEIbBbOVzKtQBl+u4Xf21/wQeVMKNVJBMG4BLgWuUUBvLTiKKyNrQccxIAjNwFNN7SGUtBeMjcj6tr9bIUCBzixPHmrueT0gnQC6bIZc8TibRR+rAPoy1RFY1ElndQqRpLfG1ncTWbcLG67CxeIF85sph0SLAG3TcrsT6D+Belc9yoEYd3RuUzB0VsUjWE2uTGcOMprCJo5jjRzCJHkyqX2QtlxUCocSrIIkWmFglyufwEOnBBObgKwxaD3yfWFMLsZZ2Iq2dYbS51cRaOzDxWowR3Q+DnFi3+Vm0bTpuVnJ9UWeec8VvAx8Afr5sJDKekiMU/0dlzQz0YBLdMpK9ImtBrkDWLNjYojqSPouMk+UTCALGersZ7T6MMT82Nl6DF68Lo81t1Jy23kTaNoSRxmbjNzRhonGRzUCk84SEzg5rgDvUL/s4cN8s//5i4K+AX5z/bM2CVULlZLZmUgOhSXYb23sQEj2Y8ZFTZS1vxaoIPtUGY06SzyCbIRjsN5nkcVIH9srss7EJv2FNGG1uC+JtnV70tPWhV7MKr6bO4EcJc9m5zD43AV9VJ/uOEqxXTCX1DvXl5ihrPgQZTHo0ZGzY2P7DmP6uwCSOGZMaMAwnIJebmKVV2DdavsQ65fxb8E6ST5MZGiSdHDCjh17xktZi/EgYbWwOY20dXqSlIxNvWetHWjuNjcZDrGeMtYS5gDAoiWzv1hDAHwGPTvE75wD3AFeWbJFOWJUAglxINm1E1o5lTaLbN4ljoUn0QC5rCHJ2QtY8g636y7T0iFX0MhVYNJVPO368h7Geo2B2en68xthYTRBtas3WtG+K+i3t2WjjGuM3tXkyIdDwxtTyeTbwsFqjv5n02tuUVB1Tk8hOBCKNhVwGk+rNmVQCm+jyTM/BjEn2+qRHLelRjyAA61k8ryplbcUQawb5tLlshlw6bTODA9HUay+JfK5qNH5jSxhZvWa4tn1TTaS109ja+sCvXeWHXoQgCIoFMr8Qev7ZeP4tkBsP/citwJ362mQ6gSezNTOWyjI2bG2iy5jegyNmsK/GDA8YUolQSGSjJ2TNixg8lh18liFEPgG8vHz6mZEU6aEk5vCBusF9O42xXiba2JyNru3069euH1rV0JAtErA0obHvsaPJZoxNmfToe01+9lUIawiMTZPsTZvB3nrbfyTDUL9PNhshDGoBg/XA88EzrAT4rBAUzD71yoaR8URfZKTnKPbI/vSazvW1hMXPR2jstRiDmSqWZgyZZI/PSFJ8I8+vwVohUrmj645YVU81jPXy65gWz4+G4fSiFJqpXg4hCCx+1EpE3MGlJp/EjnnGoRwcsRwcsRwcsRwcHLFWKrqBW5H0ITcrdCgLxpAlq8eQipxdSLWOs1gO88K3lVQglVDHnRQ6lANPTHq+q1qJ1QvsAP4cyLnrtiT8q0J8r1p9rPuA7+jPbcAH3bWrarROev5DpKSuodos1oGCn+9m5RWSLjWcW+T6PVJtUpgG9hU8P4LU9TlUL362iEp9DOivJmJ1ATuL+FwO5UdGJWu+9XCXAFsmHdsHfKqaiPV9Tm3a0eI4UHY8A/wKUqP4LuDzwItzfK848GtFjv8T8HQ1ECsA7p90rB4pFXcoLz6P5N6/BPw78KfAZUh10O3AfzG7srVi1UTDSOlaarGJ9QBStl6Iy5BSKofy4roiN+yAuiGfBa4GtiNhn38twV9qpnjy4dPATWWQ2zmHG/qAv+DUHghX45aIKoF3KHEeAL42hWQd0vEdpL3R9SqfHUqULNL+aZ9avanI8w2kUvxDi0GsO5G+VZNl8K1z/A4hEgF+GHhKzfGvA38Cy7HMYE5oRSq2b1Tf9ov6WCxX+gBSePtZpN4x1DFEad0TP4aUv/3ypONeJYn1KPC3RY6fjtTalYpu4FmNoTyNtBwaK3j9B0gPhAsdp05CHfB2Hf+LxA7/bQoLNMLcmp5kgN9FSty2I03yosyyu2KpxKpVMrxXzepknMbMRQODSJeX76l16pnmd7fqezpMje06HgQ+qjdnudCjM9B1eh0a9VjZG68NA7epThfDbtX/rUj7nkY1naNMtA76R6Qr3HS4UM39jUj/KIeZ8Xb1p/4e+GvKm7GQ7xNbMR/rz5i63BykQe0N6mu1Kylqka7JP1VrNRUiSKn6zeqn1TquTIuRAskaKTiH7wG+TgVTYSpBrEdL/L0UsH8Wn78D+EPgLY4vp+Ao8E197FYipfUmzp/rvoKwUabypDIQ5gjHhysyKywHtqhfsMPxZ8ob+fq5ylClSBVmx7GxeiLnXV11xGoB3g/con6YQ3HsqS5SAbk0WEvNuz6Df9aVVUesTwPvc7yZEdcgAc+XkKyRnM66c8jyTVZlMWAhmvWGAfhx6q65G//MN5XVxyoX7gF+xES26Tp1+A2ybBHRWE2jxk4uQRZOVxo6kDXCAGklnp/mh/o8qwQb0zBAn/pjj1aEV+Mp4ld/uGRSLQaxdlF6nrUPnKXSeRMrMz/fcuqmAfnugW1INP1lKr1bRxhiIrPbu6Ca1/aySHrIB9TJb8NhRGfdjyCL0Ls4OYu3snK4TIiVx29Q7t0alg4OIUteB9Shf1J9rvFq/+L+Inze6Uh6TZyJ3ama1CI1F/hfneprnYU0kl1peExDDtWx5+PE9if5nurZaiPWR5FdpFxN4/R4tARSRZFVjvOZSP5LqU86OI/Pjp1kFY0hTGsLcGMakdWRI9VErDHg95joi36xjs2OR6fgOqTAdI+6Am1IHHCtjrP1vJ2jFj9/owZIytFskV9ae5tek8eBLwOvmVgd409+lehF12Ji9ZYStrBbDB9rDNkKbq8+b1G5uwJ4k56ojhUaZijEFnXSu9Qy1Zfga2aB32diqWc6NOp53oykKL1Vf87nXW1Hslnuw3hfCQeP7R9/4l7ib7klpITYWTU47306ngQ+o/7XmeqLvVvvoJWKCJItUipuovjOGrXIVnZb1Cqdz8SOrNMt+q9FWpL/AWHurjDZfSclps4sFLFiSE3by0yfhwWykHoc+D8kd+tFXC79TEgCf4ykLk0+7+/XG/Qc5p45shrML+BH79TJ1YxbY5TqQG+ep7N9K5JKuwv4byR19mpkI8jWGb5f6HgzLXqB3ylCqs3AQ8DnkDy3eaUjmVjdaGbvd03QdyBVTim8H1mb+pZ+2fxm4KXiNb172nXkS5BS6kN0qxweQtJCutWf+E1creJ0OICsK05ezdiBJP6VLwvXWMKRBEGyK7AtZxwsF7FiOlO4DLgLifo+qQ74fqSocrq9mL+FVH98ZNLxenXcz3IcmTX2aNimsHi1DvikKkT54fmM//Af8M+4PFsuYhW2KKrRGdwV+nxE/abd6he9oP/05DTmj6vV+5TjxLxxFFmRKOyVsQ2p3tleqQ81fpzs68+Q2f84kc1XlsXHmg61yJZs79D41INIBcmHJ71/gKTN3Mbi7Mu8nDDCRAleG/CX6sNur+inGtl0YfwHf7dos8J2NclbdbZS2PDrbp313YOLVc0VZ6qz/hMkv239gn2yHyPofnHRiJXHNUhPppuRJl95/LPK4peZyyaSDiDriIuAEPyZl24XYr1uC9K44oOcXE37TZXPbseR5YeFWgiuQTIiv63+WB7fR/qXOjhizQvvRBY3b2aiINX1Z1iGWIy1wg06LX6fhife6S6DI1Y5sVWHg5NCBwdHLAdHLAdHLAcHRywHRywHRywHB0csB0csB0csBwdHLAdHLAdHLAeH+ROr3p2qFY9YJYj1SeBfkALJIXeOVxRSSCHx41Rgy5Ov64ggPQAuRXKptiENJtz2JMsHI0iN6LNIfehOfczO5k1mm+iXAZ7XAVK+1cpEF5MLkL5Nm9z1WTI4iDRr2YM0YXkB6QcxOp83nW8G6RgTmzA+rMfWIe1xtgKXIw0p8jtIOSwuhpDeGDuB/1ED8SozdOdbDGIVQ37HqB8BX0J6uJ+HbK54PtK7fauTzwXBsJJnZ4GsPccCdPBZiJz3UM3rCwXy2aIku0Ifz8A1BikHXkd2s9iLNMfdUw5Zq1ZiFZPPwzoe0mNtSAe/85F2kRc5+ZwRgyprzyJV5ruRJiFV0WW5Wvq89+h4CtkwE50QXKDjQpXQlVyOn1Kr/5TK2W61SFXZYKWaNxDIy+f9SGvCNUqwSzXMcfYyl88DSNOP3UqmZ5HmdGNL4cv7S+Qkp3VC8NAk+dwIvBHpEHiBzkhXL1FZ61ISPa4keo2JTS+XHPwlfEfn5fPHwFf02Bt1xnk+0oFwG9DAzBuhL8Zs7TlkO5Nn1TI/z8kN7pY0fJYX8sHbbyCrBA1It+YrlHBv0BnoZFSaeK8iLR33IE3pdgL9aomXJXyWL/J7JD+iIy+fG1Q2r1ILtwHpSliuczGoM959SIfo3RoGWFHtmnxWFvLyuRO4V49tBbMZTNOc44Zh6BPmOjG8iMSQdrPC22GaMHRt1B3KD5fo5+CI5bB08P8DAMX010LWoEB9AAAAAElFTkSuQmCC';
   
    const elementToPrint = document.getElementById('content'); //The html element to become a pdf
    var pdf = new jsPDF('p', 'mm', 'a4');
    pdf.internal.scaleFactor = 6;
    pdf.addHTML(elementToPrint,0,0,() => {
        pdf.save('web.pdf');
    });
     
  }
  WorkOrder(WorkOrderId){
    this.router.navigate(['./workorder/Add_WorkOrder',btoa(WorkOrderId)]);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}