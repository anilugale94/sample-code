export class Enquiry {
  Service:any;
  ProjectType:any;
  ScopeReq:any;
  Orientation:any;
  Dia:any;
  Depth:any;
  Unit:any;
  DrillDia: any;
  DrillDepth: any;
  BarDia: any;
  BarDepth: any;
  AnchorDia: any;
  AnchorDepth: any;
  Height: any;
  Length: any;
  TotalSQFT: any;
  TotHoleQTY: any;
  PerDayHoleQty: any;
  CompProd: any;
  Company: any;
  SelAnchorFastner: any;
  PerDaySQFTQTY: any;
  RateReq: any;

}
