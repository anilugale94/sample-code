import { Component, OnInit, ViewChild} from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort} from '@angular/material';
import { FormBuilder, Validators } from '@angular/forms';
import { AlphamobiService } from '../../index/services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router} from '@angular/router';
import { Enquiry } from './enquiry';
import {Location, Appearance} from '@angular-material-extensions/google-maps-autocomplete';
import PlaceResult = google.maps.places.PlaceResult;
class prodqty{
  ProductName: any;
  Qty: any;
}

@Component({
  selector: 'app-enquriy-list',
  templateUrl:'./enquriy-list.component.html',
  styleUrls: ['./enquiry-list.css']
})
export class EnquriyListComponent implements OnInit {
  dataSource;
  EnquryGroup:any;
  displayedColumns: string[] = ['BuliderName','RoleName','ProjectName','ProjectAddr','ContPersonName','EmailId','MobileNo','Department','Latitude','Longitude','CompanyUrl','ImgUrl1','ImgUrl2','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  RoleList: any;
  fileToUpload: File;
  imgUrl: any;
  SecondImag: File;
  SecondImg: any;
  filled = [];
  productqty = [];
  service: any;
  SeviceCont: boolean;
  formValue: any;
  AllDep: any;
  unitList: any;
  EnquiryId:any;

  DrillDia:any;
  BarDia:any;
  BarDepth:any;
  TotalHoleQTY:any;
  PerDayHoleQty:any;
  CoreDia:any;
  CoreDepth:any;
  Company:any;
  CompanyProd:any;
  AnchorFastner:any;
  AnchorDia:any;
  AnchorDepth:any;
  Height:any;
  Length:any;
  TotalSQFT:any;
  PerDaySQFTQTY:any;
  RoleWorkCategoryId:any;
  quantity=0;

  contractor:any;
  supplier:any;

  lat: any;
  lng: any;
  location: string;
  public latitude: any;
  public longitude: any;
  public appearance = Appearance;
  public selectedAddress: PlaceResult;
  checkedOptions: any;
  subscription: any;
  AllRequired: any;
  AllOrientation: any;
  AllProj: any;
  AllProjType: any;
  AllCompany: any;
  AllRate: any;
  AllProduct: any;
  ServiceId1: any;
  ScoprReq=[];
  TotalHoleqTY: boolean;
  Anchor: any;
  AllProductList: any;
  Price: any;
  AllBuilder: any;
  ProjbuildingList: any;
  
  // label: string;

  constructor(private mainService: AlphamobiService,
    private toaster:ToastrService,
    private router:Router,
    private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.EnquryGroup = this.formBuilder.group({
      EnquiryId:[null],
      BuilderName:[''],
      ProjectName:[''],
      CompProductName:[''],
      PAddress:[''],
      City:[''],
      ContactPerson:[''],
      CPDepartment:[''],
      MobileNo:[''],
      Email:['',Validators.email],
      CompanyURL:[''],
      RoleId:[''],
      ImgUrl1:[''],
      ImgUrl2:[''],
      Service:[''],
      TotalHoleQTY:[''],
      RateReq:[''],
      Dia:[''],
      Depth:[''],
      DrillDia:[''],
      BarDia:[''],
      BarDepth:[''],
      AnchorDia:[''],
      AnchorDepth:[''],
      Height:[''],
      Length:[''],
      TotalSQFT:[''],
      TotalSQFTQTY:[''],
      PerDaySQFTQTY:[''],
      ProjType:[''],
      ScopeReq:[''],
      Orientation:[''],
      CompProd:[''],
      SelAnchorFastner:[''],
      PerDayHoleQty:[''],
       qty:[''],
      Company:[''] 
    });
    this.GetAllEnqiry();
    this.GetAllRole();
    this.GetAllDepartment();
    this.GetAllProjectType();
    this.GetAllOrientaion();
    this.GetAllCompany();
    this.GetAllRateUnit();
    this.GetAllAnchorFastner();
    this.GetAllProduct();
    this.GetAllBuilder();
  }
  reset(){
    this.EnquryGroup.reset();
  }
  GetAllEnqiry() {
    this.mainService.GetAllEnqiry().subscribe((data: any) => {
      if(data != null ){
        if(data.length != 0){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Enquiry Not Found");
        }
      }else{
        this.toaster.error("Enquiry Not Found");
      }
    },error=>{
       this.router.navigate(['/index/Error']);
    });
  }

  GetAllproject(event){
    if(event.value > 0){
     var BuilderId = event.value;
    }else if(event > 0){
     var BuilderId = event;
    }
     this.mainService.ProjectGetByBuilderId(BuilderId).subscribe((data:any)=>{
       if(data != null){
         if(data.length != 0){
          this.ProjbuildingList = data;
         }else{
           this.toaster.error("Project not found");
         }
       }else{
         this.toaster.error("Project not found");
         this.ProjbuildingList = '';
       }
     },error=>{
       this.router.navigate(['index/Error']);
     })
   }
  GetAllBuilder() {
    this.mainService.GetAllBuilderName().subscribe((Catlist: any) => {
      if(Catlist.length != 0){
        if(Catlist != null){
         this.AllBuilder =Catlist;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }
  GetAllRole(){
    this.mainService.GetTwoRole().subscribe((Rolelist: any) => {
      if(Rolelist.length != 0){
        if(Rolelist != null){
          this.RoleList = Rolelist;
        }else{
          this.toaster.error("Role Not Found");
        }
      }else{
        this.toaster.error("Role Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }
  GetAllAnchorFastner() {
    this.mainService.GetAllAnchorFastner().subscribe((Catlist: any) => {
      if(Catlist.length != 0){
        if(Catlist != null){
          this.Anchor = Catlist;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }

GetCompanyProduct(event)
{
  this.mainService.GetProductGetByCompanyId(event.value).subscribe((data:any)=>{ 
  if(data.length !=0){
    if(data !=null)
    {
      this.AllProduct =data;
    }else{
      this.toaster.error("Company Product Not Found");
      this.AllProduct = [];
    }
  }else{
    this.AllProduct = [];
  }
  },error =>{
    this.router.navigate(['/index/Error']);
  });
}
GetAllProduct(){
  this.mainService.GetAllCompanyProd().subscribe((data:any)=>{
    if(data.length != 0){
        this.AllProductList = data;
    }else{
      this.toaster.error("Data not found.")
    }
  },error=>{
    this.router.navigate(['/index/Error']);
  })
}
  GetAllService(RoleId){
    var RoleId = RoleId.value;
    if(RoleId == 1){
      this.contractor = true;
      this.supplier = false;
      this.mainService.GetAllServiceByRole(RoleId).subscribe((data:any)=>{
        if(data != null){ 
          if(data.length != 0){
              this.service = data;
              this.SeviceCont = true;
          }else{
            this.toaster.error("Service Not Found");
          }
        } else{
          this.toaster.error("Service Not Found");
        }
      },error=>{
        this.router.navigate(['/index/Error']);
      });
    }else if(RoleId == 2){
      this.supplier = true;
      this.contractor = false;
      this.filled = [];
      this.productqty = [];
    }
  }
  GetAllDepartment(){
    this.mainService.GetAllDepartment().subscribe((Rolelist: any) => {
      if(Rolelist.length != 0){
        if(Rolelist != null){
          this.AllDep = Rolelist;
        }else{
          this.toaster.error("Department Not Found");
        }
      }else{
        this.toaster.error("Department Not Found");
      }
    },
    error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }
  GetAllCompany(){
    this.mainService.GetAllCompany().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.AllCompany = data;
        }else{
          this.toaster.error("Company Is Not Found");
        }
      }else{
        this.toaster.error("Company Is Not Found");
      }
    },error =>{
      this.router.navigate(['/index/Error']);
    })
  }
  GetAllRateUnit(){
    this.mainService.GetAllRateReqUnit().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.AllRate =data;
        }else{
          this.toaster.error("RateUnit Is Not Found");
        }
      }else{
        this.toaster.error("RateUnit Is Not Found");
      }
    },error =>{
      this.router.navigate(['/index/Error']);
    })
  }
  GetAllOrientaion(){
    this.mainService.GetAllOrientation().subscribe((Projlist: any) => {
      if(Projlist.length != 0){
        if(Projlist != null){
          this.AllOrientation =Projlist;
          
        }else{
          this.toaster.error("Orientation Not Found");
        }
      }else{
        this.toaster.error("Orientation Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }
  GetAllProjectType() {
    this.mainService.GetAllProjectType().subscribe((Projlist: any) => {
      if(Projlist.length != 0){
        if(Projlist != null){
         this.AllProjType = Projlist;
        }else{
          this.toaster.error("ProjectType Not Found");
        }
      }else{
        this.toaster.error("ProjectType Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }

  ImageChange(file:FileList){
    this.fileToUpload = file.item(0);
    var reader = new FileReader();
    reader.onload=(event:any)=>{
      this.imgUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }
  ImageSecond(file:FileList){
    this.SecondImag = file.item(0);
    var reader = new FileReader();
    reader.onload=(event:any)=>{
      this.SecondImg = event.target.result;
    }
    reader.readAsDataURL(this.SecondImag);
    
  }
  add(formValue) {
   var T= new Enquiry();
   var FormValue = formValue.value;
    this.ScoprReq.push(FormValue.ScopeReq);
  //  if(this.filled.length > 0){
  //     for(let i=0;i < this.filled.length;i++){
  //       if(FormValue.Service == this.filled[i]["Service"]){
  //         this.toaster.error("Already Service Exist In List");
  //         return false;
  //       }
  //     }
  //  }
   T.Service = FormValue.Service;
   T.ProjectType = FormValue.ProjType
   T.ScopeReq = FormValue.ScopeReq;
   T.Orientation = FormValue.Orientation;

   T.Dia = FormValue.Dia;
   T.Depth = FormValue.Depth;
   T.DrillDia = FormValue.DrillDia;
   T.BarDia =FormValue.BarDia;
   T.BarDepth =FormValue.BarDepth;
   T.AnchorDia =FormValue.AnchorDia;
   T.AnchorDepth =FormValue.AnchorDepth;
   T.Height =FormValue.Height;
   T.Length =FormValue.Length;
   T.TotalSQFT =FormValue.TotalSQFT;
   T.PerDayHoleQty =FormValue.PerDayHoleQty;
   T.CompProd = FormValue.CompProd;
   T.Company =FormValue.Company;
   T.SelAnchorFastner =FormValue.SelAnchorFastner;
   T.PerDaySQFTQTY =FormValue.PerDaySQFTQTY;
   T.TotHoleQTY = FormValue.TotalHoleQTY;
   T.RateReq =FormValue.RateReq;


   if(T.Dia == ""){T.Dia = 0} 
   if(T.Depth == ""){T.Depth = 0 }
   if(T.DrillDia == ""){T.DrillDia =0}
   if(T.BarDia == ""){T.BarDia =0}
   if(T.BarDepth == ""){T.BarDepth =0}
   if(T.AnchorDia == ""){T.AnchorDia =0}
   if(T.AnchorDepth == ""){T.AnchorDepth =0}
   if(T.Height == ""){T.Height =0}
   if(T.Length == ""){T.Length =0}
   if(T.TotalSQFT == ""){T.TotalSQFT =0}
   if(T.PerDayHoleQty == ""){T.PerDayHoleQty =0}
  //  if(T.CompProd == ""){T.CompProd =0}
   if(T.Company == ""){T.Company =0}
  //  if(T.SelAnchorFastner == ""){T.SelAnchorFastner =0}
   if(T.PerDaySQFTQTY == ""){T.PerDaySQFTQTY =0}
   if(T.TotHoleQTY ==""){T.TotHoleQTY =0}
   if(T.RateReq ==""){T.RateReq =0}

   this.filled.push(T);
   
  this.EnquryGroup.controls['Dia'].setValue("");
  this.EnquryGroup.controls['ProjType'].setValue("");
  this.EnquryGroup.controls['ScopeReq'].setValue("");
  this.EnquryGroup.controls['Orientation'].setValue("");
  this.EnquryGroup.controls['Depth'].setValue("");
  this.EnquryGroup.controls['DrillDia'].setValue("");
  this.EnquryGroup.controls['BarDia'].setValue("");
  this.EnquryGroup.controls['BarDepth'].setValue("");
  this.EnquryGroup.controls['AnchorDia'].setValue("");
  this.EnquryGroup.controls['AnchorDepth'].setValue("");
  this.EnquryGroup.controls['Height'].setValue("");
  this.EnquryGroup.controls['Length'].setValue("");
  this.EnquryGroup.controls['TotalSQFT'].setValue("");
  this.EnquryGroup.controls['CompProd'].setValue("");
  this.EnquryGroup.controls['Company'].setValue("");
  this.EnquryGroup.controls['PerDaySQFTQTY'].setValue("");
  this.EnquryGroup.controls['SelAnchorFastner'].setValue("");
  this.EnquryGroup.controls['RateReq'].setValue("");
  this.EnquryGroup.controls['TotalHoleQTY'].setValue("");
  this.EnquryGroup.controls['PerDayHoleQty'].setValue("");
  
  }
 
  DeleteService(i){
    this.filled.splice(i,1);
  }
  OnSave(EnquryGroup){
    this.formValue = EnquryGroup.value;
    this.SaveEnquiry(this.formValue,this.EnquiryId);
  }
  SaveEnquiry(formValue,EnquiryId){
    if(this.formValue.EnquiryId == null){
      this.mainService.SaveEnquiry(this.formValue,this.lat,this.lng).subscribe((Enqid:any)=>{
        var EnqId:any = parseInt(Enqid);
        if(EnqId != null){
           if(EnqId.length != 0){
                this.mainService.UpdateEnquiryImage1(EnqId,this.fileToUpload).subscribe((data:any)=>{
                },error=>{
                  this.router.navigate(['/index/Error']);
                })
                this.mainService.UpdateEnquiryImage2(EnqId,this.SecondImag).subscribe((data:any)=>{
                },error=>{
                  this.router.navigate(['/index/Error']);
                })
                for(let i=0;i<this.filled.length;i++){
                 
                  var Service = this.filled[i]['Service'];
                  var ProjectType = this.filled[i]['ProjectType'];
                  var Orientation = this.filled[i]['Orientation'];
                  var RateReq = this.filled[i]['RateReq'];
                  var ProdId = this.filled[i]['CompProd'];
                
                  this.mainService.EnquiryServiceSave(EnqId,Service,ProjectType,Orientation,RateReq,ProdId).subscribe((ServiceId:any)=>{
                    if(ServiceId != 0){
                    this.ServiceId1 = ServiceId;
                    this.SaveQuotation(i);
                    this.SaveScope(i);
                 }
              },error=>{
                this.router.navigate(['/index/Error']);
              })
            }
      
              this.toaster.success("Enquiry save successfully.");
              this.GetAllEnqiry();
              this.reset();
          
           } else{
             this.toaster.error("Enquiry not save, please try again");
           }
        }else{
          this.toaster.error("Enquiry not save, please try again");
        }
      },error=>{
        this.router.navigate(['/index/Error']);
      });
    }else{
      this.mainService.UpdateProject(this.formValue).subscribe((data:any)=>{
        if(data != null){
           if(data.length != 0){  
              this.toaster.success("Enquiry update successfully.");
              this.GetAllEnqiry();
              this.reset();
           } else{
             this.toaster.error("Enquiry not update, please try again");
           }
        }else{
          this.toaster.error("Enquiry not save, please try again");
        }
      },error=>{
        this.router.navigate(['index/Error']);
      });
    }
  }
SaveQuotation(i){

      var CoreDia = this.filled[i]['Dia'];
      var DrillDia = this.filled[i]['DrillDia'];
      var BarDia = this.filled[i]['BarDia'];
      var AnchorDepth = this.filled[i]['AnchorDepth'];
      var AnchorDia = this.filled[i]['AnchorDia'];
      var AnchorFastner = this.filled[i]['SelAnchorFastner'];
      var CoreDepth = this.filled[i]['Depth'];
      var BarDepth = this.filled[i]['BarDepth'];
      var TotalHoleQty = this.filled[i]['TotHoleQTY'];
      var HoleQtyPerDay = this.filled[i]['PerDayHoleQty'];
      var Height = this.filled[i]['Height'];
      var Length = this.filled[i]['Length'];
      var TotalSqFt = this.filled[i]['TotalSQFT'];
      var SqFtQtyPerDay = this.filled[i]['PerDaySQFTQTY'];

    this.mainService.SaveQuotation(this.ServiceId1,CoreDia,DrillDia,BarDia,AnchorDepth,AnchorDia
      ,CoreDepth,BarDepth,TotalHoleQty,HoleQtyPerDay,Height,Length,TotalSqFt,SqFtQtyPerDay,AnchorFastner,this.formValue.Email).subscribe((data:any)=>{

    },error=>{
      this.router.navigate(['/index/Error']);
    })
 
}
SaveScope(i){
  var ScopId = this.ScoprReq[i];
  for(let k=0;k<ScopId.length;k++){
    this.mainService.SaveServiceScopeRequired(this.ServiceId1,ScopId[k]).subscribe((data:any)=>{
  
    },error=>{
      this.router.navigate(['/index/Error']);
    })
  }
 
}

ShowHide(event){
 this.mainService.GetScopeRequiredGetByRoleWorkCateId(event.value).subscribe((data:any)=>{
 if(data !=null)
 {
   if(data.length !=0)
   {
     this.AllRequired=data;
   }
  }else{
    this.toaster.error("Scope required not found");
  }
 },error=>{
  this.router.navigate(['/index/Error'])
});
    
    if(event.value == 1)//Core Cuting
    {
      this.CoreDepth =true;
      this.CoreDia = true;
      this.TotalHoleqTY = true;
      this.PerDayHoleQty = true;

      this.DrillDia = false;
      this.BarDia = false;
      this.BarDepth = false;
      this.Company = false;
      this.CompanyProd = false;
      this.AnchorFastner = false;
      this.AnchorDia = false;
      this.AnchorDepth = false;
      this.Length = false;
      this.Height = false;
      this.PerDaySQFTQTY = false;
    }else if(event.value == 2){ //Rebiring
     this.Company = true;
     this.CompanyProd = true;
     this.DrillDia = true;
     this.BarDia = true;
     this.BarDepth = true;
     this.TotalHoleqTY = true;
     this.PerDayHoleQty = true;

     this.CoreDepth =false;
     this.CoreDia = false;
     this.AnchorFastner = false;
     this.AnchorDia = false;
     this.AnchorDepth = false;
     this.Length = false;
     this.Height = false;
     this.PerDaySQFTQTY = false;
    }else if(event.value == 3){ //Chemical Anchor
      this.Company = true;
      this.CompanyProd = true;
      this.DrillDia = true;
      this.AnchorDepth = true;
      this.AnchorDia = true;
      this.TotalHoleqTY = true;
      this.PerDayHoleQty = true;
      this.AnchorFastner = true;
 
      this.CoreDepth =false;
      this.CoreDia = false;
      this.BarDia = false;
      this.BarDepth = false;
      this.Length = false;
      this.Height = false;
      this.PerDaySQFTQTY = false;
    }else if(event.value == 4){ //Mechanical Anchor
    this.Company = true;
    this.CompanyProd = true;
    this.DrillDia = true;
    this.AnchorDepth = true;
    this.AnchorDia = true;
    this.TotalHoleqTY = true;
    this.PerDayHoleQty = true;
    this.AnchorFastner = true;

    this.CoreDepth =false;
    this.CoreDia = false;
    this.BarDia = false;
    this.BarDepth = false;
    this.Length = false;
    this.Height = false;
    this.PerDaySQFTQTY = false;
  }else if(event.value == 5){ // Painting 
    this.Company = true;
    this.CompanyProd = true;
    this.Length = false;
    this.Height = false;
    this.PerDaySQFTQTY = false;

    this.DrillDia = false;
    this.AnchorDepth = false;
    this.AnchorDia = false;
    this.TotalHoleqTY = false;
    this.PerDayHoleQty = false;
    this.AnchorFastner = false;
    this.CoreDepth = false;
    this.CoreDia = false;
    this.BarDia = false;
    this.BarDepth = false;
  }
}

  AddCat(){
    this.checkedOptions =
    this.subscription && this.subscription.unsubscribe();
  }
  onAutocompleteSelected(result: PlaceResult) {
    console.log('onAutocompleteSelected: ', result.formatted_address);
    this.location =result.formatted_address;
  }

  onLocationSelected(location: Location) {
    console.log('onLocationSelected: ', location);
    this.latitude = location.latitude;
    this.longitude = location.longitude;
    this.lat = location.latitude;
    this.lng = location.longitude;
  }


  EnquiryDetails(EnquiryId){
    this.router.navigate(['./enquiry/Enquiry_Details',btoa(EnquiryId)]);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  
  increase_quantity(temp_package){
      this.quantity++;
  }

  decrease_quantity(temp_package){
  
      if(temp_package ==0)
      {
        return false;
      }
      this.quantity--
    }
 addqty(formValue)
 {
  var T= new prodqty();
  var FormValue = formValue.value;
   
  // if(this.productqty.length > 0){
  //    for(let i=0;i < this.productqty.length;i++){
  //      if(FormValue.Service == this.productqty[i]["Service"]){
  //        this.toaster.error("Already Service Exist In List");
  //        return false;
  //      }
  //    }
  // }

  T.ProductName = FormValue.CompProductName;
  T.Qty = this.quantity;
  console.log("dsgfdsg",this.quantity);
  
  
  this.productqty.push(T);
console.log(this.productqty);
//  this.EnquryGroup.controls['ProductName'].setValue("");
//  this.EnquryGroup.controls['Qty'].setValue("");
 }

}
