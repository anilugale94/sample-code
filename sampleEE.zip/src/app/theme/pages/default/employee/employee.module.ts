import { NgModule } from '@angular/core';
import { CommonModule, DatePipe} from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeComponent } from '../employee/employee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { DefaultComponent } from '../default.component';
import { AlphamobiService } from '../index/services/alphamobi.service';
import { MatDatepickerModule, MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatListModule, MatInputModule, MatTableModule, MatPaginatorModule, MatSortModule, MatSelectModule, MatMenuModule, MatGridListModule, MatCheckboxModule, MatDialogModule, MatTooltipModule, MatNativeDateModule, MatProgressSpinnerModule, MatAutocompleteModule } from '@angular/material';
import { ConfirmDialogService } from '../index/services/confirm-dialog.service';
import { LayoutModule } from '../../../layouts/layout.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { ToastrModule } from 'ngx-toastr';
const routes:Routes=[
  {
    path:'',
    component:DefaultComponent,
    children:[
      { path:'Add_Employee',component:AddEmployeeComponent },
      { path:'Employee_Details/:UserId',component:EmployeeDetailsComponent }
    ]
  }
];

@NgModule({
  declarations: [EmployeeComponent,AddEmployeeComponent,EmployeeDetailsComponent],
  imports: [
    CommonModule,RouterModule.forChild(routes),
    LayoutModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatSelectModule,
    MatMenuModule,
    MatGridListModule,
    MatCheckboxModule,
    MatDialogModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressSpinnerModule,
    MatAutocompleteModule,
    OwlDateTimeModule, 
    OwlNativeDateTimeModule,
    ToastrModule.forRoot()
  ],
  providers:[AlphamobiService,MatDatepickerModule,DatePipe,ConfirmDialogService],
})
export class EmployeeModule { }
