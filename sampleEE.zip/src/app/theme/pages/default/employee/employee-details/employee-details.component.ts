import { Component, OnInit,ViewChild } from '@angular/core';
import { AlphamobiService } from '../../index/services/alphamobi.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatTableDataSource, MatPaginator, MatSort} from '@angular/material';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styles: []
})
export class EmployeeDetailsComponent implements OnInit {
  
  dataSource: any;

  displayedColumns: string[] = ['Department','Address','PersonName','ContactNo','EmailId'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  FirstName: any;
  LastName: any;
  FatherName: any;
  MobileNo: any;
  EmailId: any;
  PanCard: any;
  AadhaarCard: any;
  VotingCard: any;
  AddressProof: any;
  BankStatementUrl: any;
  ImgUrl: any;

  constructor(private activeRoute : ActivatedRoute,
    private route:Router,private mainService:AlphamobiService) { }

  ngOnInit() {
    this.activeRoute.params.subscribe(param =>{
      this.UserId = param['UserId']
   }); 
   this.GetEmpById();
  }


  GetEmpById(){
    this.mainService.GetByIdAllUser(this.UserId).subscribe((data:any)=>{
      
      console.log("Emp",data);
      var Empdata = data;
      this.FirstName = Empdata[0]['FirstName'];
      this.LastName = Empdata[0]['LastName'];
      this.FatherName = Empdata[0]['FatherName'];
      this.MobileNo = Empdata[0]['MobileNo'];
      this.EmailId = Empdata[0]['EmailId'];
      this.PanCard = Empdata[0]['PancardUrl'];
      this.AadhaarCard = Empdata[0]['AadhaarCardUrl'];
      this.VotingCard = Empdata[0]['VotingCardUrl'];
      this.AddressProof = Empdata[0]['AddressProofUrl'];
      this.BankStatementUrl = Empdata[0]['BankStatementUrl'];
      this.ImgUrl = Empdata[0]['ImgUrl'];
      
    });
  }
  UserId(UserId: any) {
    throw new Error("Method not implemented.");
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
