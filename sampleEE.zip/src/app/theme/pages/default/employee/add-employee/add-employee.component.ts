import { Component, OnInit, ViewChild} from '@angular/core';
import { FormBuilder,Validators} from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort} from '@angular/material';
import { AlphamobiService } from '../../index/services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router, NavigationExtras } from '@angular/router';
import { ConfirmDialogService } from '../../index/services/confirm-dialog.service';
import { interval,Subscription } from 'rxjs';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styles: []
})
export class AddEmployeeComponent implements OnInit {
  UserGroup: any; 
  sub:any;
  UserId:any=null;
  displayedColumns: string[] = ['FirstName','EmailId','MobileNo','Gender','Address','DOJ','SalaryPerMonth','ContractBasicRate','EndContractDate','Update','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  progressbar = false;
  roleList: any;
  file:any;
  fileToUpload: File=null;
  AadhaarFile: File=null;
  PancardFile: File=null;
  VotingCardFile: File=null;
  AddressProofFile: File=null;
  BankStatementFile: File=null;
  imgUrl:string;
  AadhaarCard: any;
  Pancard: any;
  VotingCard: any;
  AddressProof: any;
  BankStatement: any;
  service: any;
 
  CatName=[];
  subscription: Subscription;
  checkedOptions=[];
  uplodfile=[];
  User: any;

  constructor(private mainService: AlphamobiService,
    private formBuilder: FormBuilder,
    private toaster:ToastrService,
    private router:Router,
    private Dialog:ConfirmDialogService,
    private datePipe: DatePipe) { }

  ngOnInit() {
    this.UserGroup = this.formBuilder.group({
      UserId:[''],
      RoleId:['',Validators.required],
      FirstName:['',Validators.required],
      LastName:['',Validators.required],
      MobileNo:['',Validators.required],
      EmailId:['',[Validators.required,Validators.email]],
      Gender:['',Validators.required],
      Address:['',Validators.required],

      MotherName:['',Validators.required],
      FatherName:['',Validators.required],
      DOB:['',Validators.required],
      DOJ:['',Validators.required],
      SalaryPerMonth:['',Validators.required],
      ContractBasicRate:['',Validators.required],
      EndContractDate:['',Validators.required],

      ImgUrl:[''],
      AadhaarCardUrl:[''],
      PancardUrl:[''],
      VotingCardUrl:[''],
      AddressProofUrl:[''],
      BankStatementUrl:[''],
      
    });
    this.reset();
    this.GetAllUser();
    this.GetAllRole();
  }
  reset(){
    this.UserGroup.reset();
  }
  
  GetAllUser() {
    this.mainService.GetByAllUser().subscribe((Catlist: any) => {
      if(Catlist != null ){
        if(Catlist.length != 0){
          this.dataSource = new MatTableDataSource(Catlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("No Data Found");
        }
      }else{
        this.toaster.error("No Data Found");
      }
    },error=>{
      this.router.navigate(['/index/Error']);
    });
}

GetAllRole(){
  this.mainService.GetAllRole().subscribe((data:any)=>{
    if(data != null){
      if(data.length != 0){
        this.roleList = data;
      }else{
        this.toaster.error("Data Not Found");
      }
    }else{
      this.toaster.error("Data Not Found");
    }
  },error=>{
    this.router.navigate(['/index/Error']);
  });
}

validateDOB(DOB){

  let year = new Date(DOB.value).getFullYear();
  let today  = new Date().getFullYear();

  if(today - year >= 100){
    //Code Something
  }
}
// ImageChange(file:FileList){
//   //this.fileToUpload = file.item(0);
//   var reader = new FileReader();
//   reader.onload=(event:any)=>{
//     this.imgUrl = event.target.result;
//     this.uplodfile.push(event.target.result);
//   }
//   reader.readAsDataURL(file.item(0));

//   console.log(this.uplodfile);
// }
ImageChange(file:FileList){
  this.fileToUpload = file.item(0);
  var reader = new FileReader();
  reader.onload=(event:any)=>{
    this.imgUrl = event.target.result;
  }
  reader.readAsDataURL(this.fileToUpload);
}
ImageAadhar(file:FileList){
  this.AadhaarFile = file.item(0);
  var reader = new FileReader();
  reader.onload=(event:any)=>{
    this.AadhaarCard = event.target.result;
  }
  reader.readAsDataURL(this.AadhaarFile);
  
}
ImagePan(file:FileList){
  this.PancardFile = file.item(0);
  var reader = new FileReader();
  reader.onload=(event:any)=>{
    this.Pancard = event.target.result;
  }
  reader.readAsDataURL(this.PancardFile);
}
ImageVoting(file:FileList){
  this.VotingCardFile = file.item(0);
  var reader = new FileReader();
  reader.onload=(event:any)=>{
    this.VotingCard = event.target.result;
  }
  reader.readAsDataURL(this.VotingCardFile);
  this.SaveVoting(this.User,this.VotingCardFile);
}
ImageAddress(file:FileList){
  this.AddressProofFile = file.item(0);
  var reader = new FileReader();
  reader.onload=(event:any)=>{
    this.AddressProof = event.target.result;
  }
  reader.readAsDataURL(this.AddressProofFile);
}
ImageBank(file:FileList){
  this.BankStatementFile = file.item(0);
  var reader = new FileReader();
  reader.onload=(event:any)=>{
    this.BankStatement = event.target.result;
  }
  reader.readAsDataURL(this.BankStatementFile);
}
OnSaveUser(UserGroup){
  var formValue = this.UserGroup.value;
  this.SaveUser(formValue);
}
SaveImg(UserId,fileToUpload){
  this.mainService.SaveUserImg(UserId,fileToUpload).subscribe((data)=>{
        if(data == 'Updated'){
     
        }else{
          this.toaster.error("User Image Is Not Upload, Please Try Again");
        }
  })
}
SaveAadhar(UserId,AadhaarFile){
  this.mainService.SaveUserAadhar(UserId,AadhaarFile).subscribe(data=>{
        if(data == 'Updated'){   
        }else{
         this.toaster.error("Aadhar Card Is Not Upload, Please Try Again");
        }
  })
}

SavePan(UserId,PancardFile){
  this.mainService.SaveUserPan(UserId,PancardFile).subscribe(data=>{
        if(data == 'Updated'){   
        }else{
         this.toaster.error("PAN Card Is Not Upload, Please Try Again");
        }
  })
}
SaveVoting(UserId,VotingCardFile){
  this.mainService.SaveUserVoting(UserId,VotingCardFile).subscribe(data=>{
        if(data == 'Updated'){   
        }else{
         this.toaster.error("Voting Card Is Not Upload, Please Try Again");
        }
  })
}
SaveAddress(UserId,AddressProofFile){
  this.mainService.SaveUserAddress(UserId,AddressProofFile).subscribe(data=>{
        if(data == 'Updated'){   
        }else{
         this.toaster.error("Address Proof Is Not Upload, Please Try Again");
        }
  })
}
SaveBank(UserId,BankStatementFile){
  this.mainService.SaveUserBank(UserId,BankStatementFile).subscribe(data=>{
        if(data == 'Updated'){   
        }else{
         this.toaster.error("Bank Statement Is Not Upload, Please Try Again");
        }
  })
}
SaveUser(formValue){
  this.progressbar = true;
  this.UserId = formValue.UserId;
  if(this.UserId == null){
    this.mainService.SaveUser(formValue).subscribe((data:any)=>{
      var data1 = data[0]['Result'];

        if(data1 == 'Exist'){
          this.toaster.error('User Is Already Exist.');
        }else if(data1 != null){
          if(data1 != 0){
          
              this.SaveImg(data1,this.fileToUpload);
              this.SaveAadhar(data1,this.AadhaarFile);
              this.SavePan(data1,this.PancardFile);
              this.SaveVoting(data1,this.VotingCardFile);
              this.SaveAddress(data1,this.AddressProofFile);
              this.SaveBank(data1,this.BankStatementFile);

            this.toaster.success("User Is Save Successfully.");
            this.reset();
            this.GetAllUser();
          }else{
          this.toaster.error("Data Not Save, Please Try Again.");
        }
        }else{
          this.toaster.error("Data Not Save, Please Try Again.");
        }
    },error=>{
      this.router.navigate(['/index/Error']);
    });
  }else{
    this.mainService.ServiceDelete(this.UserId).subscribe(data=>{
      
    });
    this.mainService.UpdateUser(formValue).subscribe((data:any)=>{
      if(data != null){
        if(data == 'Updated'){
         
          if(this.fileToUpload != null){
            this.SaveImg(this.UserId,this.fileToUpload);
          }
          if(this.AadhaarFile != null){
            this.SaveAadhar(this.UserId,this.AadhaarFile);
          }
          if(this.PancardFile != null){
            this.SavePan(this.UserId,this.PancardFile);
          }
          if(this.VotingCardFile != null){
            this.SaveVoting(this.UserId,this.VotingCardFile);
          }
          if(this.AddressProofFile != null){
            this.SaveAddress(this.UserId,this.AddressProofFile);
          }
          if(this.BankStatementFile != null){
            this.SaveBank(this.UserId,this.BankStatementFile);
          }
           
          this.toaster.success("User Is Update Successfully.");
          this.reset();
          this.GetAllUser();
        }else if(data == 'Exist'){
          this.toaster.error('User Is Already Exist.');
        }else{
          this.toaster.error("Data Not Update, Please Try Again.");
        }
      }else {
        this.toaster.error("Data Not Update, Please Try Again.");
      }
    },error=>{
      this.router.navigate(['/index/Error']);
    });
  }
  this.progressbar = false;
}
Edit(UserId){
  this.mainService.GetByIdAllUser(UserId).subscribe((data:any)=>{
    this.CatName=[];
  
    if(data != null || data.length != 0){
      this.mainService.GetServiceByUserId(UserId).subscribe((data:any)=>{
        for(var i=0;i < data.length;i++){
         this.CatName.push(data[i]['RoleWorkCategoryId']);
        }
       });
       const source = interval(100);
       this.subscription = source.subscribe(val =>this.EditService());
      this.UserGroup.controls['UserId'].setValue(data[0]['UserId']);
      this.UserGroup.controls['RoleId'].setValue(data[0]['RoleId']);
      this.UserGroup.controls['FirstName'].setValue(data[0]['FirstName']);
      this.UserGroup.controls['LastName'].setValue(data[0]['LastName']);
      this.UserGroup.controls['MobileNo'].setValue(data[0]['MobileNo']);
      this.UserGroup.controls['EmailId'].setValue(data[0]['EmailId']);
      this.UserGroup.controls['Gender'].setValue(data[0]['Gender']);
      this.UserGroup.controls['Address'].setValue(data[0]['Address']);
      this.UserGroup.controls['MotherName'].setValue(data[0]['MotherName']);
      this.UserGroup.controls['FatherName'].setValue(data[0]['FatherName']);
      this.UserGroup.controls['DOB'].setValue(this.datePipe.transform(data[0]['DOB'], 'yyyy-MM-dd'));
      this.UserGroup.controls['DOJ'].setValue(this.datePipe.transform(data[0]['DOJ'], 'yyyy-MM-dd'));
      this.UserGroup.controls['SalaryPerMonth'].setValue(data[0]['SalaryPerMonth']);
      this.UserGroup.controls['ContractBasicRate'].setValue(data[0]['ContractBasicRate']);
      this.UserGroup.controls['EndContractDate'].setValue(this.datePipe.transform(data[0]['EndContractDate'], 'yyyy-MM-dd'));
   
      this.User = data[0]['UserId'];
      this.imgUrl = 'http://eagleconstruction.co.in/'+ data[0]['ImgUrl'];
      this.AadhaarCard = 'http://eagleconstruction.co.in/'+ data[0]['AadhaarCardUrl'];
       this.Pancard ='http://eagleconstruction.co.in/'+ data[0]['PancardUrl'];
       this.VotingCard = 'http://eagleconstruction.co.in/'+ data[0]['VotingCardUrl'];
       this.AddressProof = 'http://eagleconstruction.co.in/'+ data[0]['AddressProofUrl'];
       this.BankStatement = 'http://eagleconstruction.co.in/'+ data[0]['BankStatementUrl'];

      this.ScrollTop();
     

    }else{
      this.toaster.error("Data Not Found");
    }
  },error=>{
    this.router.navigate(['/index/Error']);
  })
}
EditService(){
  this.checkedOptions =  this.CatName;
  this.subscription && this.subscription.unsubscribe();
}
Delete(UserId){
  this.Dialog.openConfirmationDialog("Are You Sure Delete Employee?").afterClosed().subscribe(res=>{

 if(res){
    this.mainService.DeleteUser(UserId).subscribe((data:any)=>{
      if(data.length != 0){
        if(data != null){
          this.toaster.success("User Is Successfully Deleted.");
          this.GetAllUser();
          this.reset();
        }else{
          this.toaster.error("User Is Not Deleted, Please Try Again.");
        }
      }else{
        this.toaster.error("User Is Not Deleted, Please Try Again.");
      }
    },error=>{
      this.router.navigate(['/index/Error']);
    })
  }
  })
}
UpdateStatus(UserId){
  this.Dialog.openConfirmationDialog("Are you sure change status ?").afterClosed().subscribe(res=>{
    if(res){
      this.mainService.UpdateUserStatus(UserId).subscribe(data=>{
        this.toaster.success("Status Update Successfully");
        this.reset();
        this.GetAllUser();
      },error=>{
        this.router.navigate(['/index/Error']);
      })
      }
  });
}
OrderList(UserId){
  let navigationExtras : NavigationExtras = {
    queryParams:{
      "UserId":UserId
    }
  };
  this.router.navigate(['/index/User_Details'],navigationExtras);
}
EmployeeDetails(UserId){
    this.router.navigate(['/employee/Employee_Details',UserId]);  
}

  applyFilter(filterValue: string) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
          window.scrollTo(0, 0)
            //window.scrollTo(0, pos - 20); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
}
