import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier',
  templateUrl: './supplier.component.html',
  styles: []
})
export class SupplierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
