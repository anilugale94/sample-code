import { Component, OnInit ,ViewChild } from '@angular/core';
import { AlphamobiService } from '../../index/services/alphamobi.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatTableDataSource, MatPaginator, MatSort} from '@angular/material';
import { ConfirmDialogService } from '../../index/services/confirm-dialog.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-supplier-details',
  templateUrl: './supplier-details.component.html',
  styles: []
})
export class SupplierDetailsComponent implements OnInit {
  dataSource: any;
  FirstName: any;
  LastName: any;
  MobileNo: any;
  EmailId: any;
  ProductName: any;
  CompanyName: any;
  UserEmailId: any;

  displayedColumns: string[] = ['CompanyName','ProductName'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  constructor(private activeRoute : ActivatedRoute,
    private route:Router,
    private mainService:AlphamobiService,
    private toaster:ToastrService) { }

  ngOnInit() {
    this.activeRoute.params.subscribe(param =>{
      this.UserId = param['UserId']
   }); 
   this.GetByIdAllUser();
   this.GetUserProductGetByUserId();

  }
  GetByIdAllUser(){
    this.mainService.GetByIdAllUser(this.UserId).subscribe((data:any)=>{
      var Suppdata = data;
      //this.FirstName = Suppdata[0]['FirstName'];
      this.LastName = Suppdata[0]['LastName'];
      this.MobileNo = Suppdata[0]['MobileNo'];
      this.EmailId = Suppdata[0]['EmailId'];
    });
  }

  GetUserProductGetByUserId() {
    this.mainService.GetUserProductGetByUserId(this.UserId).subscribe((Catlist: any) => {
      if(Catlist.length != 0){
        if(Catlist != null){
          this.dataSource = new MatTableDataSource(Catlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Work Order Not Found");
        }
      }else{
        this.toaster.error("Work Order Not Found");
      }
    },error =>{ 
      this.route.navigate(['/index/Error']);
    });
  }



  UserId(UserId: any) {
    throw new Error("Method not implemented.");
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }



}
