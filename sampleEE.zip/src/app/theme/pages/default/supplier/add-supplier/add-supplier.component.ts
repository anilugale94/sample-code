import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { FormBuilder, Validators } from '@angular/forms';
import { AlphamobiService } from '../../../default/index/services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router, NavigationExtras } from '@angular/router';
import { ConfirmDialogService } from '../../../default/index/services/confirm-dialog.service';
import { interval,Subscription } from 'rxjs';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-supplier',
  templateUrl: './add-supplier.component.html',
  styles: []
})
export class AddSupplierComponent implements OnInit {
  SupplierGroup;
  sub:any;
  UserId:any=null;
  displayedColumns: string[] = ['FirstName','EmailId','MobileNo','AlterMobNo','Address','Description','Update','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  isLoadingResults = false;
  isRateLimitReached = false;
  roleList: any;
  file:any;
  fileToUpload: File=null;
  AadhaarFile: File=null;
  PancardFile: File=null;
  imgUrl:string;
  AadhaarCard: any;
  Pancard: any;
  service: any;
  SeviceCont: any;
  CatName=[];
  subscription: Subscription;
  checkedOptions=[];
  uplodfile=[];
  User: any;
  AllProduct: any;
  AllCompany: any;
  ScoprReq: any;
  ProductId: any;
  constructor(private mainService: AlphamobiService,
    private formBuilder: FormBuilder,
    private toaster:ToastrService,
    private router:Router,
    private Dialog:ConfirmDialogService,
    private datePipe: DatePipe) { }

  ngOnInit() {
    this.SupplierGroup = this.formBuilder.group({
      UserId:[null],
      Company:['',Validators.required],
      ContactName:['',Validators.required],
      // RoleWorkCategoryId:[''],
      MobileNo:['',Validators.required],
      OfficeNo:[''],
      EmailId:['',Validators.required],
      PAN:[''],
      GST:['',Validators.pattern("^([0][1-9]|[1-2][0-9]|[3][0-5])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$")],
      Address:['',Validators],
      Description:[''],
      RegNo:[''],
      ImgUrl:[''],
      PancardUrl:[''],
      AadhaarCardUrl:[''],
      Brand:[''],
      CompProd:['']

    });
    this.reset();
    this.GetAllUser();
    this.GetAllService(3);
    this.GetAllCompany();
    
  }
  reset(){
    this.SupplierGroup.reset();
  }
  ImageChange(file:FileList){
    this.fileToUpload = file.item(0);
    var reader = new FileReader();
    reader.onload=(event:any)=>{
      this.imgUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }
  ImageAadhar(file:FileList){
    this.AadhaarFile = file.item(0);
    var reader = new FileReader();
    reader.onload=(event:any)=>{
      this.AadhaarCard = event.target.result;
    }
    reader.readAsDataURL(this.AadhaarFile);
  }
  ImagePan(file:FileList){
    this.PancardFile = file.item(0);
    var reader = new FileReader();
    reader.onload=(event:any)=>{
      this.Pancard = event.target.result;
    }
    reader.readAsDataURL(this.PancardFile);
  }

GetCompanyProduct(event)
{
  if(event.value > 0){
    var CompanyId = event.value;
   }else if(event > 0){
    var CompanyId = event;
   }
this.mainService.GetProductGetByCompanyId(CompanyId).subscribe((data:any)=>{
 if(data.length !=0){
   if(data !=null)
   {
     this.AllProduct =data;
   }else{
     this.toaster.error("Company Product Not Found");
   }
 }else{
   this.toaster.error("Company Product Not Found");
 }
});
}

GetAllCompany(){
  this.mainService.GetAllCompany().subscribe((data:any)=>{
    if(data != null){
      if(data.length != 0){
        this.AllCompany = data;
      }else{
        this.toaster.error("Company Is Not Found");
      }
    }else{
      this.toaster.error("Company Is Not Found");
    }
  },error =>{
    this.router.navigate(['/index/Error']);
  })
}
 
  GetAllUser() {
    this.mainService.GetByAllUserByRoleId(2).subscribe((Catlist: any) => {
      if(Catlist != null ){
        if(Catlist.length != 0){
          this.dataSource = new MatTableDataSource(Catlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("No Data Found");
        }
      }else{
        this.toaster.error("No Data Found");
      }
    },error=>{
      this.router.navigate(['/index/Error']);
    });
}
GetAllService(RoleId){
  this.mainService.GetAllServiceByRole(RoleId).subscribe((data:any)=>{
    if(data != null){ 
      if(data.length != 0){
          this.service = data;
          this.SeviceCont = true;
      }else{
        //this.toaster.error("Data Not Found");
      }
    } else{
      //this.toaster.error("Data Not Found");
    }
  },error=>{
    this.router.navigate(['/index/Error']);
  })
}
  OnSave(SupplierGroup){
    var formValue = this.SupplierGroup.value;
    this.SaveUser(formValue);
  }
  SavePan(UserId,PancardFile){
    this.mainService.SaveUserPan(UserId,PancardFile).subscribe(data=>{
          if(data == 'Updated'){   
          }else{
           this.toaster.error("PAN Card Is Not Upload, Please Try Again");
          }
    })
  }
  SaveImg(UserId,fileToUpload){
    this.mainService.SaveUserImg(UserId,fileToUpload).subscribe((data)=>{
          if(data == 'Updated'){
          }else{
            this.toaster.error("User Image Is Not Upload, Please Try Again");
          }
    })
  }
  SaveAadhar(UserId,AadhaarFile){
    this.mainService.SaveUserAadhar(UserId,AadhaarFile).subscribe(data=>{
          if(data == 'Updated'){   
          }else{
           this.toaster.error("Aadhar Card Is Not Upload, Please Try Again");
          }
      })
  }
  
  SaveUser(formValue){
    this.UserId = formValue.UserId;
    if(this.UserId == null){
      this.mainService.SaveSupplier(formValue).subscribe((data:any)=>{
        var data1 = data[0]['Result'];
          if(data1 == 'Exist'){
            this.toaster.error('Supplier Is Already Exist.');
          }else if(data1 != null){
            if(data1 != 0){
              // if(formValue.RoleWorkCategoryId.length != 0){
              // for(let i=0;i < formValue.RoleWorkCategoryId.length;i++){
              //   this.mainService.SaveUserService(data1,formValue.RoleWorkCategoryId[i]).subscribe(data=>{
              //   },error=>{
              //     this.router.navigate(['/index/Error']);
              //   });
               
              // }
           // }
            if(formValue.CompProd.length != 0){
              for(let i=0;i < formValue.CompProd.length;i++){
              this.mainService.SaveUserProduct(data1,formValue.CompProd[i]).subscribe((product:any)=>{
        
              },error=>{
                this.router.navigate(['/index/Error']);
              });
            }
          }
              this.SaveImg(data1,this.fileToUpload);
              this.SaveAadhar(data1,this.AadhaarFile);
              this.SavePan(data1,this.PancardFile);
              this.toaster.success("Supplier Is Save Successfully.");
              this.reset();
              this.GetAllUser();
            }else{
            this.toaster.error("Data Not Save, Please Try Again.");
          }
    
      }else{
        this.toaster.error("Data Not Save, Please Try Again.");
      }
  },error=>{
    this.router.navigate(['/index/Error']);
  });
    }else{
      this.mainService.ServiceDelete(this.UserId).subscribe(data=>{
      });
      this.mainService.UpdateSupplier(formValue).subscribe((data:any)=>{
        if(data != null){
          if(data == 'Updated'){
            if(formValue.RoleWorkCategoryId.length != 0){
            for(let i=0;i < formValue.RoleWorkCategoryId.length;i++){
              this.mainService.SaveUserService(this.UserId,formValue.RoleWorkCategoryId[i]).subscribe(data=>{
              });
            }}
            if(this.fileToUpload != null){
              this.SaveImg(this.UserId,this.fileToUpload);
            }
            if(this.AadhaarFile != null){
              this.SaveAadhar(this.UserId,this.AadhaarFile);
            }
            if(this.PancardFile != null){
              this.SavePan(this.UserId,this.PancardFile);
            }
            this.toaster.success("Supplier Is Update Successfully.");
            this.reset();
            this.GetAllUser();
          }else if(data == 'Exist'){
            this.toaster.error('Supplier Is Already Exist.');
          }else{
            this.toaster.error("Data Not Update, Please Try Again.");
          }
        }else {
          this.toaster.error("Data Not Update, Please Try Again.");
        }
      },error=>{
        this.router.navigate(['/index/Error']);
      });
    }
  }
  Edit(UserId){
    this.mainService.GetByIdAllUser(UserId).subscribe((data:any)=>{
   
      this.CatName=[];
      this.SeviceCont = '';
      if(data != null || data.length != 0){
        this.mainService.GetServiceByUserId(UserId).subscribe((data:any)=>{
          for(var i=0;i < data.length;i++){
           this.CatName.push(data[i]['RoleWorkCategoryId']);
          }
         });
         const source = interval(100);
         this.subscription = source.subscribe(val =>this.EditService());
        this.SupplierGroup.controls['UserId'].setValue(data[0]['UserId']);
        this.SupplierGroup.controls['Company'].setValue(data[0]['FirstName']);
        this.SupplierGroup.controls['ContactName'].setValue(data[0]['LastName']);
        this.SupplierGroup.controls['MobileNo'].setValue(data[0]['MobileNo']);
        this.SupplierGroup.controls['OfficeNo'].setValue(data[0]['AlterMobNo']);
        this.SupplierGroup.controls['EmailId'].setValue(data[0]['EmailId']);
        this.SupplierGroup.controls['Address'].setValue(data[0]['Address']);
        this.SupplierGroup.controls['PAN'].setValue(data[0]['Pancard']);
        this.SupplierGroup.controls['GST'].setValue(data[0]['GST']);
        this.SupplierGroup.controls['Description'].setValue(data[0]['Description']);
        this.User = data[0]['UserId'];
        this.imgUrl = 'http://eagleconstruction.co.in/'+ data[0]['ImgUrl'];
        this.AadhaarCard = 'http://eagleconstruction.co.in/'+ data[0]['AadhaarCardUrl'];
         this.Pancard ='http://eagleconstruction.co.in/'+ data[0]['PancardUrl'];

        this.ScrollTop();
        if(data[0]['RoleWorkCategoryName'] != null){
          this.SeviceCont = true;
          this.GetAllService(data[0]['RoleId']);
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error=>{
      this.router.navigate(['/index/Error']);
    })
  }
  EditService(){
    this.checkedOptions =  this.CatName;
    this.subscription && this.subscription.unsubscribe();
  }
  Delete(UserId){
    this.Dialog.openConfirmationDialog("Are You Sure Delete Supplier ?").afterClosed().subscribe(res=>{
   if(res){
      this.mainService.DeleteUser(UserId).subscribe((data:any)=>{
        if(data.length != 0){
          if(data != null){
            this.toaster.success("Supplier Is Successfully Deleted.");
            this.GetAllUser();
            this.reset();
          }else{
            this.toaster.error("Supplier Is Not Deleted, Please Try Again.");
          }
        }else{
          this.toaster.error("Supplier Is Not Deleted, Please Try Again.");
        }
      },error=>{
        this.router.navigate(['/index/Error']);
      })
    }
    })
  }


  UpdateStatus(UserId){
    this.Dialog.openConfirmationDialog("Are you sure change status ?").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.UpdateUserStatus(UserId).subscribe(data=>{
          this.toaster.success("Status Update Successfully");
          this.reset();
          this.GetAllUser();
        },error=>{
          this.router.navigate(['/index/Error']);
        })
        }
    });
  }

  SupplierDetails(UserId){
    this.router.navigate(['/supplier/Supplier_Details',UserId]);  
}



  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
}
numberOnly(event): boolean {
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

ScrollTop() {
  let scrollToTop = window.setInterval(() => {
      let pos = window.pageYOffset;
      if (pos > 0) {
        window.scrollTo(0, 0)
          //window.scrollTo(0, pos - 20); // how far to scroll on each step
      } else {
          window.clearInterval(scrollToTop);
      }
    }, 0);
  }
}
