import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contractor',
  templateUrl: './contractor.component.html',
  styles: []
})
export class ContractorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
