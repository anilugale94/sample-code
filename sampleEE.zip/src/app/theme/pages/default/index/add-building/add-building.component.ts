import { Component, OnInit, ViewChild} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatTableDataSource, MatPaginator,MatSort } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
@Component({
  selector: 'app-add-building',
  templateUrl: './add-building.component.html',
  styles: []
})
export class AddBuildingComponent implements OnInit {
  BuildingGroup;
  @ViewChild(MatPaginator) paginator : MatPaginator;
  @ViewChild(MatSort) sort : MatSort; 
  displayedColumns:string[]=['projectName','BuildingName','Action'];
  dataSource;
  formvalue: any;
  projectList: any;

  constructor(private mainService : AlphamobiService,
              private router:Router,
              private formBuilder:FormBuilder,
              private toastr:ToastrService,
              private confirm:ConfirmDialogService) { }

  ngOnInit() {
    this.BuildingGroup = this.formBuilder.group({
      BuildingId:[null],
      ProjectId:['',Validators.required],
      Building:['',Validators.required]
    });
    this.GetAllBuilding();
    this.GetAllProject();
    this.reset();
  }
  GetAllBuilding(){
    this.mainService.GetAllprojectBuilding().subscribe((data:any)=>{
      if(data.length != 0){
        if(data != null){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toastr.error("Data not found.");
        }
      }else{
        this.toastr.error("Data not found.");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  GetAllProject(){
    this.mainService.GetAllProject().subscribe((data:any)=>{
      if(data.length != 0){
        if(data != null){
          this.projectList = data;
        }else{
          this.toastr.error("Data not found.");
        }
      }else{
        this.toastr.error("Data not found.");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  reset(){
    this.BuildingGroup.reset();
  }
  onSave(BuildingGroup){
    this.formvalue = this.BuildingGroup.value;
    if(this.formvalue.BuildingId == null){
      this.mainService.SaveProjectBuilding(this.formvalue).subscribe((data:any)=>{
        if(data =="Saved"){
            this.toastr.success("Building save successfully.");
            this.GetAllBuilding();
            this.reset();
        }else if(data =="Exist"){
          this.toastr.error("Building is already exist.");
        }else{
          this.toastr.error("Building not save, please try again.");
        }
      },error=>{
        this.router.navigate(['index/Error']);
      })
    }else{
      this.mainService.UpdateProjectBuilding(this.formvalue).subscribe((data:any)=>{
        if(data =="Updated"){
            this.toastr.success("Building update successfully.");
            this.GetAllBuilding();
            this.reset();
        }else if(data =="Exist"){
          this.toastr.error("Building is already exist.");
        }else{
          this.toastr.error("Building not update, please try again.");
        }
      },error=>{
        this.router.navigate(['index/Error']);
      })
    }
  }
  Edit(BuildingId){
    this.mainService.GetProjectBuildingById(BuildingId).subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.BuildingGroup.controls['BuildingId'].setValue(data[0]['BuildingId']);
          this.BuildingGroup.controls['ProjectId'].setValue(data[0]['ProjectId']);
          this.BuildingGroup.controls['Building'].setValue(data[0]['BuildingName']);
          this.ScrollTop();
        }else{
          this.toastr.error("Please try again");
        }
      }else{
        this.toastr.error("Please try again");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  Delete(BuildingId){
    this.confirm.openConfirmationDialog("Are you sure delete project building?").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.DeleteProjectBuildingById(BuildingId).subscribe((data:any)=>{
          if(data == "Deleted"){
            this.toastr.success("Building delete successfully.");
            this.GetAllBuilding();
          }else{
            this.toastr.error("Building not delete, please try again.");
          }
        },error=>{
          this.router.navigate(['index/Error']);
        })
      }
    })
  
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
