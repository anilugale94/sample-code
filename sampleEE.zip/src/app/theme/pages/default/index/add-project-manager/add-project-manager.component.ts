import { Component, OnInit } from '@angular/core';
import {FormControl,FormBuilder, Validators} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
@Component({
  selector: 'app-add-project-manager',
  templateUrl:'./add-project-manager.component.html',
  styles: []
})
export class AddProjectManagerComponent implements OnInit {
  ManagerGroup:any;
  myControl = new FormControl();
  options = [];
  filteredOptions: Observable<string[]>;
  constructor(private formBuild:FormBuilder) { }

  ngOnInit() {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
     this.ManagerGroup = this.formBuild.group({
      ProjectName:['',Validators.required],
      MangName:['',Validators.required]
     });
     this.GetAllData();
  }
  
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }
  onSave(){
    console.log(this.ManagerGroup.value,this.myControl.value);
  }
  GetAllData(){
    this.options = ['Rahul Rathod', 'Sachin Pawar', 'Ramesh Patil','Anil Ugale','Ganesh Jagtap','Ram Avhad'];
  }
}
