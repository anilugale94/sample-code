import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
@Component({
  selector: 'app-user-role',
  templateUrl: './user-role.component.html',
  styles: []
})
export class UserRoleComponent implements OnInit {
  RoleGroup:any;
  dataSource;
  displayedColumns: string[] = ['Name','Action'];
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
  FormValue: any;
  RoleId: any;
  
  constructor(private mainService: AlphamobiService, private formBuilder: FormBuilder,private toaster:ToastrService,private route:Router,private dialog:ConfirmDialogService) { }

  ngOnInit() {
    this.RoleGroup = this.formBuilder.group({
      RoleId:[null],
      Name:['',Validators.required]
    });
    this.reset();
    this.GetAllRole();
  }
  reset(){
    this.RoleGroup.reset();
  }
  GetAllRole() {
    this.mainService.GetAllRole().subscribe((Catlist: any) => {
      if(Catlist.length != 0){
        if(Catlist != null){
          this.dataSource = new MatTableDataSource(Catlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.route.navigate(['/index/Error']);
    });
  }
  OnSaveRole(RoleGroup){
    this.FormValue = this.RoleGroup.value;
    this.SaveRole(this.FormValue);
  }
  SaveRole(FormValue){
    this.RoleId = FormValue.RoleId;
    if(this.RoleId == null){ 
      this.mainService.SaveRole(FormValue).subscribe(data=>{
        if(data == 'Saved'){
        this.toaster.success("User Role Save Successfully.");
        this.GetAllRole();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("User Role Is Already Exist.");
        }
      },error =>{ 
          this.route.navigate(['/index/Error']);
        });
    
    }else{
    this.mainService.UpdateRole(FormValue).subscribe(data=>{
      if(data == 'Updated'){
        this.toaster.success("User Role Update Successfully.");
        this.GetAllRole();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("User Role Is Already Exist.");
        }
      },error =>{ 
        this.route.navigate(['/index/Error']);
      });
    }
  } 
  Delete(RoleId){
    this.dialog.openConfirmationDialog("Are Sure Delete Role?").afterClosed().subscribe(res=>{
      if(res){
      this.mainService.DeleteRole(RoleId).subscribe(data=>{
        if(data == "Deleted"){
          this.toaster.success("User Role Delete Successfully.");
          this.GetAllRole();
          this.reset();
        }else{
          this.toaster.error("User Role Is Not Delete, Please Try Again.");
        }
      },error =>{ 
          this.route.navigate(['/index/Error']);
        });
      }
    });
  }
  Edit(RoleId){
    this.mainService.GetRoleById(RoleId).subscribe((data:any)=>{
      if(data!=null){
        if(data.length != 0){
          this.RoleGroup.controls['RoleId'].setValue(data[0]['RoleId']);
          this.RoleGroup.controls['Name'].setValue(data[0]['Name']);
        }else{
          this.toaster.error("Data Not Found");
        }
      
      }else{
        this.toaster.error("Data Not Found");
      }
    },
    error =>{ 
      this.route.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
