import { Component, OnInit,ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
@Component({
  selector: 'app-scope-required',
  templateUrl: './scope-required.component.html',
  styles: []
})
export class ScopeRequiredComponent implements OnInit {

  displayedColumns: string[] = ['SelectService','Required','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource;
  ScopeGroup: any;
  servicelist: any;
  formValue: any;
  ScopeRequiredId:any;

  constructor( private mainService: AlphamobiService, 
    private formBuilder: FormBuilder,
    private toaster:ToastrService,
    private route:Router,
    private dialog:ConfirmDialogService) { }

  ngOnInit() {
    this.ScopeGroup = this.formBuilder.group({
      ScopeRequiredId:[''],
      ScopRequired: ['', Validators.required],
      RoleWorkCategoryId: ['', Validators.required],
  });
  this.reset();
  this.GetAllService();
  this.GetAllRequired();
  }
  reset(){
    this.ScopeGroup.reset();
  }
  GetAllRequired(){
    this.mainService.GetAllScopeRequird().subscribe((data:any)=>{
      if(data != 0){
        if(data != null){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Data Not Found");
        }

      }else{
        this.toaster.error("Data Not Found");
      }
    },error=>{
      this.route.navigate(['/index/Error']);
    })
  } 
  GetAllService(){
    this.mainService.GetByAllService().subscribe((data:any)=>{
      if(data != 0){
        if(data != null){
          this.servicelist=data;
        }else{
          this.toaster.error("Data Not Found");
        }

      }else{
        this.toaster.error("Data Not Found");
      }
    },error=>{
      this.route.navigate(['/index/Error']);
    })
  } 
  OnSave(ScopeGroup){
    this.formValue =this.ScopeGroup.value;
    this.ScopeRequiredId = this.formValue.ScopeRequiredId;
    if(this.ScopeRequiredId == null){ 
      this.mainService.SaveScopeRequird(this.formValue).subscribe(data=>{
        if(data == 'Saved'){
        this.toaster.success("Scope Required Save Successfully.");
        this.GetAllService();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Scope Required Is Already Exist.");
        }
      },
        error =>{ 
          this.route.navigate(['/index/Error']);
        });
    
    }else{
    this.mainService.UpdateScopeRequird(this.formValue).subscribe(data=>{
      if(data == 'Updated'){
        this.toaster.success("Scope Required Update Successfully.");
        this.GetAllService();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Scope Required Is Already Exist.");
        }
      },
      error =>{ 
        this.route.navigate(['/index/Error']);
      });
    }
  }
  Delete(RoleWorkCategoryId){
    this.dialog.openConfirmationDialog("Are Sure Delete Service ?").afterClosed().subscribe(res=>{
      if(res){
      this.mainService.DeleteService(RoleWorkCategoryId).subscribe(data=>{
        if(data == "Deleted"){
          this.toaster.success("Service Delete Successfully.");
          this.GetAllService();
          this.reset();
        }else{
          this.toaster.error("Service Is Not Delete, Please Try Again.");
        }
      },error =>{ 
          this.route.navigate(['/index/Error']);
        });
      }
    });
  }
  Edit(RoleWorkCategoryId){
    this.mainService.GetServiceById(RoleWorkCategoryId).subscribe((CatList:any)=>{
      if(CatList!=null){
         this.ScopeGroup.controls['ScopeRequiredId'].setValue(CatList[0]['ScopeRequiredId']);
        this.ScopeGroup.controls['RoleWorkCategoryId'].setValue(CatList[0]['RoleWorkCategoryId']);
        this.ScopeGroup.controls['ScopRequired'].setValue(CatList[0]['Name']);
      }else{
        this.toaster.error("Data Not Found");
      }
    },
    error =>{ 
      this.route.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
