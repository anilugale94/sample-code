import { Component, OnInit, ViewChild} from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort} from '@angular/material';
import { FormBuilder, Validators } from '@angular/forms';
import { AlphamobiService } from '../../index/services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router} from '@angular/router';
import { ConfirmDialogService } from '../../index/services/confirm-dialog.service';
class Address{
  DepartmentId:any;
  Address:any;
  PersonName:any;
  ContactNo:any;
  EmailId:any;
}
@Component({
  selector: 'app-add-project',
  templateUrl:'./add-project.component.html',
  styles: []
})
export class AddProjectComponent implements OnInit {
  dataSource;
  ProjectGroup:any;
  displayedColumns: string[] = ['ProjectName','Builder','Location','Details','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  Deptlist: any;
  formValue: any;
  Address=[];
  AllBuilder: any;
  constructor(private mainService: AlphamobiService,
    private toaster:ToastrService,
    private router:Router,
    private formBuilder:FormBuilder,
    private dialog:ConfirmDialogService) { }

  ngOnInit() {
    this.ProjectGroup = this.formBuilder.group({
      ProjectId:[null],
      BuilderName:['',Validators.required],
      ProjectName:['',Validators.required],
      Location:[''],
      PAddress:['',Validators.required],
      DepartmentId:['',Validators.required],
      PersonName:['',Validators.required],
      ContNo:['',Validators.required],
      EmailId:['',[Validators.required,Validators.email]]
    })
    this.GetAllDepartment();
    this.GetAllproject();
    this.GetAllBuilder();
    this.reset();
  }
  reset(){
    this.ProjectGroup.reset();
  }

  ProjectDetails(ProjectId){
    this.router.navigate(['./index/Project_Details',btoa(ProjectId)]);
  }
  GetAllBuilder() {
    this.mainService.GetAllBuilderName().subscribe((Catlist: any) => {
      if(Catlist.length != 0){
        if(Catlist != null){
         this.AllBuilder =Catlist;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }

  GetAllDepartment(){
    this.mainService.GetAllDepartment().subscribe((data:any)=>{
      if(data.length !=0){
        this.Deptlist = data;
      }else{
        this.toaster.error("Data Not Found");
      }
    });
  }
  GetAllproject(){
    this.mainService.GetAllProject().subscribe((data:any)=>{
      if(data.length != 0){
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }else{
        this.toaster.error("Data not found");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    });
  }
  SaveAddress(formValue){
    var addr = new Address();
    var formvalue = this.ProjectGroup.value
    addr.DepartmentId = formvalue.DepartmentId;
    addr.PersonName = formvalue.PersonName;
    addr.Address = formvalue.PAddress;
    addr.ContactNo = formvalue.ContNo;
    addr.EmailId = formvalue.EmailId;
    this.Address.push(addr);
  }
  Deleteaddress(index){
    this.dialog.openConfirmationDialog("Are you sure delete address ?").afterClosed().subscribe(res=>{
      if(res){
        this.Address.splice(index,1);
      }
    })
  
  }
  OnSave(ProjectGroup){
    this.formValue = this.ProjectGroup.value;
    this.SaveProject(this.formValue);
  }
  SaveProject(formValue){
    if(this.formValue.ProjectId == null){
      this.mainService.SaveProject(this.formValue).subscribe((data:any)=>{
        console.log(data);
        if(data != null){
           if(data.length != 0){  
              for(let i=0;i<this.Address.length;i++){
                  this.mainService.SaveProjectAddress(data,this.Address[i]).subscribe((data:any)=>{
                  
                  })
              }
              this.toaster.success("Project save successfully.");
              this.GetAllproject();
              this.reset();
              this.Address =[];
           } else{
             this.toaster.error("Project not save please try again");
           }
        }else{
          this.toaster.error("Project not save please try again");
        }
      },error=>{
        this.router.navigate(['index/Error']);
      });
    }else{
      this.mainService.UpdateProject(this.formValue).subscribe((data:any)=>{
        if(data != null){
           if(data.length != 0){  
              this.toaster.success("Project update successfully.");
              this.GetAllproject();
              this.reset();
           } else{
             this.toaster.error("Project not update, please try again");
           }
        }else{
          this.toaster.error("Project not save please try again");
        }
      },error=>{
        this.router.navigate(['index/Error']);
      });
    }
  }
  Edit(ProjectId){
    this.mainService.GetByIdProject(ProjectId).subscribe((data:any)=>{
      if(data.length != 0){
      this.ProjectGroup.controls['ProjectId'].setValue(data[0]['ProjectId']);
        this.ProjectGroup.controls['ProjectName'].setValue(data[0]['Name']);
        this.ProjectGroup.controls['BuilderName'].setValue(data[0]['Builder']);
        this.ProjectGroup.controls['Location'].setValue(data[0]['Location']);
        this.ProjectGroup.controls['PAddress'].setValue(data[0]['Address']);
        this.ProjectGroup.controls['EmailId'].setValue(data[0]['EmailId']);
        this.ProjectGroup.controls['ContNo'].setValue(data[0]['MobileNo']);
        this.ProjectGroup.controls['PersonName'].setValue(data[0]['PersonName']);
      }else{
        this.toaster.error("Project not found, please try again");
      }
      this.ScrollTop();
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  Delete(ProjectId){
    this.dialog.openConfirmationDialog("Are you sure deleted project ?").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.DeleteProject(ProjectId).subscribe((data:any)=>{
          if(data == 'Deleted'){
            this.GetAllproject();
            this.reset();
            this.toaster.success("Project delete successfully.");
          }else{
            this.toaster.error("Project not delete, please try again.");
          }
        },error=>{
          this.router.navigate(['index/Error']);
        })
      }
    })
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
}
