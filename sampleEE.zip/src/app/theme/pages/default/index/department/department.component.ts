import { Component, OnInit, ViewChild} from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { ConfirmDialogService }  from '../services/confirm-dialog.service';
@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styles: []
})
export class DepartmentComponent implements OnInit {
  DepGroup:any;
  dataSource;
  displayedColumns:string[] = ['Name','Action'];
  @ViewChild(MatPaginator) paginator :MatPaginator;
  @ViewChild(MatSort) sort :MatSort;
  formValue: any;
  DepId: any;
  constructor(private formBuilder:FormBuilder,
              private route:Router,
              private confirm:ConfirmDialogService,
              private mainService:AlphamobiService,
              private toast:ToastrService) { }

  ngOnInit() {
    this.DepGroup = this.formBuilder.group({
      DepartmentId:[null],
      Name:['',Validators.required]
    });
    this.GetAllDep();
  }
  reset(){
    this.DepGroup.reset();
  }
  GetAllDep(){
    this.mainService.GetAllDepartment().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toast.error("Data Is Not Found");
        }
      }else{
        this.toast.error("Data Is Not Found");
      }
    },error =>{
      this.route.navigate(['/index/Error']);
    })
  }
  OnSave(DepGroup){
    this.formValue = this.DepGroup.value;
    this.SaveDepartment(this.formValue);
  }
  SaveDepartment(formValue: any) {
    this.DepId = formValue.DepartmentId;
    if(this.DepId == null){
      this.mainService.SaveDepartment(this.formValue).subscribe((data:any)=>{
        if(data != null){
          if(data == 'Saved'){
            this.reset();
            this.GetAllDep();
            this.toast.success("Department Is Save Successfully.")
          }else if(data == 'Exist'){
            this.toast.error("Department Is Allready Exist.")
          }else{
            this.toast.error("Department Is Not Save, please Try Again.")
          }
        }else{  
          this.toast.error("Department Is Not Save, please Try Again.");
        }
    },error =>{
      this.route.navigate(['/index/Error']);
    })
    }else {
      this.mainService.UpdateDepartment(this.formValue).subscribe(data=>{
        if(data == 'Updated'){
          this.toast.success("Department Is Update Successfuly.");
          this.reset();
          this.GetAllDep();
        }else{
          this.toast.error("Department Is Not Update, please Try Again.");
        }
      },error =>{
        this.route.navigate(['/index/Error']);
      })
    }
  }
  Edit(DepartmentId){
    this.mainService.GetDepartmentById(DepartmentId).subscribe((data:any)=>{
        if(data != null){
          if(data.length != 0){
            this.DepGroup.controls['DepartmentId'].setValue(data[0]['DepartmentId']);
            this.DepGroup.controls['Name'].setValue(data[0]['Name']);
          }else{
            this.toast.error("Department Is Not Found.");
          }
        }else{
          this.toast.error("Department Is Not Found.");
        }  
    },error=>{
      this.route.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  Delete(DepartmentId){
    this.confirm.openConfirmationDialog("Are You Sure Delete Department ?").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.DeleteDepartment(DepartmentId).subscribe(data=>{
          if(data == 'Deleted'){
            this.GetAllDep();
            this.reset();
            this.toast.success("Department Is Delete Successfuly.");
          }else {
            this.toast.success("Department Is Not Delete, Please Try Again.");
          }
        },error =>{
          this.route.navigate(['/index/Error']);
        })
      }
    });
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
