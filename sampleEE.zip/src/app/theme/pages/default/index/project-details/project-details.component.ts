import { Component, OnInit ,ViewChild} from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort} from '@angular/material';

import { AlphamobiService } from '../../index/services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute,Router} from '@angular/router'; 
@Component({
  selector: 'app-project-details',
  templateUrl:'./project-details.component.html',
   
  styles: []
})
export class ProjectDetailsComponent implements OnInit {
  ProjectId: any;
  projectName: any;
  ProjectGroup: any;
  displayedColumns: string[] = ['Department','Address','PersonName','ContactNo','EmailId'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: any;
  builderName: any;
  location: any;

  constructor(private mainService: AlphamobiService,
    private toaster:ToastrService,
    private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(param=>{
    this.ProjectId = atob(param['ProjectId']);
    });
    this.GetProjectById();
    this.GetDepProjectById();

  }
  

  GetProjectById(){
    this.mainService.GetByIdProject(this.ProjectId).subscribe((data:any)=>{
      var projectdata = data;
      
      this.projectName = projectdata[0]['Name'];
      this.builderName = projectdata[0]['BuilderName'];
      this.location = projectdata[0]['Location'];
      
    });
  }

  GetDepProjectById(){
    this.mainService.GetProjectDeptGetByProjectId(this.ProjectId).subscribe((data:any)=>{
   
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
