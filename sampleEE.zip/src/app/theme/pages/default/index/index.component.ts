import { Component, OnInit, ViewEncapsulation} from '@angular/core';
import { AlphamobiService } from './services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';


@Component({
    selector: "app-index",
    templateUrl: "./index.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class IndexComponent implements OnInit {
    dataSource;
    TotalBook:number;
    TodayUser:number;
    CatCount: number;
    constructor(private mainService: AlphamobiService,private router:Router,private toaster:ToastrService) {
    }
    ngOnInit() {
    
       //this.GetAllCount();
    }
   
    GetAllCount(){
      this.mainService.GetallCountCount().subscribe((CountList:any)=>{
          if(CountList!=null){
            this.TotalBook = CountList[0]['BookCount'];
            this.TodayUser = CountList[0]['UserCount'];
            this.CatCount = CountList[0]['CategoryCount'];
          }else{
            this.toaster.error("No Data Found");
          }
      },error=>{
        this.router.navigate(['/index/Error']);
      });
    }

 
  
    applyFilter(filterValue: string) {
        this.dataSource.filter = filterValue.trim().toLowerCase();
      } 
}