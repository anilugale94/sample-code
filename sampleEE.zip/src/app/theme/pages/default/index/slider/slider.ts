export class Slider {
    SliderId:number;
    Position:string;
    ImgUrl:string;
}
