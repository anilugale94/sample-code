import { Component, OnInit, ViewChild,ViewEncapsulation,AfterViewInit} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
@Component({
  selector: 'app-slider',
  templateUrl:'./slider.component.html' ,
  styles: [],
  encapsulation: ViewEncapsulation.None
})
export class SliderComponent implements OnInit{
  dataSource;
  SliderGroup:any;
  imgUrl:string;
  formValue:any;
  file:any;
  fileToUpload:File=null;
  displayedColumns:string[]=['Name','ImgUrl','Action']
  @ViewChild(MatPaginator) paginator:MatPaginator;
  @ViewChild(MatSort) sort:MatSort;
  ImgId: any;
  datatList:any;

  constructor(private mainService: AlphamobiService, private formBuilder: FormBuilder,private toastr:ToastrService,private router: Router,private dialog:ConfirmDialogService) { }

  ngOnInit() {
    this.SliderGroup = this.formBuilder.group({
      SliderId:[null],
      Name:[''],
      ImgUrl:['',Validators.required]
    })
    this.GetAllSliderImg();
    this.reset();

  }
  reset(){
    this.SliderGroup.reset();
  }
  GetAllSliderImg(){
    this.mainService.GetAllSliderImg().subscribe((data:any)=>{
      if(data!=null){
        if(data.length != 0){
          this.datatList = data;
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toastr.error("Data Not Found");
        }
      }else{
        this.toastr.error("Data Not Found")
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  ImageChange(file:FileList){
    this.fileToUpload = file.item(0);
    var reader = new FileReader();
    reader.onload=(event:any)=>{
      this.imgUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }
  OnSaveImage(SliderGroup){
    this.formValue = this.SliderGroup.value;
    this.SaveImage(this.formValue,this.fileToUpload);
  }
  SaveImage(formValue,fileToUpload){
    this.ImgId = formValue.SliderId;
    if(this.ImgId == null){
      this.mainService.SaveSliderImage(formValue,this.fileToUpload).subscribe(data=>{
        if(data == "Saved"){
          this.toastr.success("Slider Image Save Successfully");
          this.GetAllSliderImg();
          this.reset();
        }else if(data == "Exist"){
          this.toastr.error("Slider Image Is Already Exist.");
        }else{
          this.toastr.error("Slider Image Is Not Save, Please Try Again");
        }
      });
    
    }else{
      this.mainService.UpdateSliderImage(formValue,this.fileToUpload).subscribe(data=>{
        if(data == 'Updated'){
          this.toastr.success("Slider Image Update Successfully");
          this.GetAllSliderImg();
          this.reset();
        }else if(data == 'Exist'){
          this.toastr.error("Slider Image Is Already Exist.");
        }else{
          this.toastr.error("Slider Image Is Not Update, Please Try Again");
        }
      })
    }
  } 
  EditImg(SliderId){
    this.mainService.GetSliderImageId(SliderId).subscribe(ImgList=>{
      if(ImgList != null){
        this.SliderGroup.controls['SliderId'].setValue(ImgList[0]['SliderId']);
        this.SliderGroup.controls['Name'].setValue(ImgList[0]['Name']);
        this.imgUrl = 'http://eagleconstruction.co.in/'+ ImgList[0]['ImgUrl'];
      }else{
        this.toastr.error("Data Not Found");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    });
    this.ScrollTop();
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0, pos - 20); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 16);
}
  DeleteImg(SliderId){
    this.dialog.openConfirmationDialog("Are You Sure Delete Slider Image").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.DeleteSliderImg(SliderId).subscribe(data=>{
          if(data != null){
            this.toastr.success("Slider Image Delete Successfully");
            this.GetAllSliderImg();
          }else{
            this.toastr.error("Slider Image Not Delete.");
            this.GetAllSliderImg();
          }
        },error=>{
          this.router.navigate(['index/Error']);
        })
      }
    })
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
 
}
