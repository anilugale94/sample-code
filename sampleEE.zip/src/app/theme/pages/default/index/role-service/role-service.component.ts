import { Component, OnInit, ViewChild} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../services/confirm-dialog.service';

@Component({
  selector: 'app-role-service',
  templateUrl: './role-service.component.html',
  styles: []
})
export class RoleServiceComponent implements OnInit {
  displayedColumns: string[] = ['RoleWorkCategoryName','RoleName','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  ServiceGroup: any;
  dataSource;
  serviceId: any;
  ServiceList: any;
  formValue: any;

  constructor(private mainService: AlphamobiService, private formBuilder: FormBuilder,private toaster:ToastrService,private route:Router,private dialog:ConfirmDialogService  ) { }

  ngOnInit() {
    this.ServiceGroup = this.formBuilder.group({
      RoleId: ['', Validators.required],
      RoleWorkCategoryId:[''],
      RoleWorkCategoryName: ['', Validators.required],
  });
  this.reset();
  this.GetRole();
  this.GetAllService();
  }
  reset(){
    this.ServiceGroup.reset();
  }
  GetAllService(){
    this.mainService.GetByAllService().subscribe((data:any)=>{
      if(data != 0){
        if(data != null){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Data Not Found");
        }

      }else{
        this.toaster.error("Data Not Found");
      }
    },error=>{
      this.route.navigate(['/index/Error']);
    })
  } 
  GetRole(){
    this.mainService.GetTwoRole().subscribe((Rolelist: any) => {
      if(Rolelist.length != 0){
        if(Rolelist != null){
          this.ServiceList = Rolelist;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },
    error =>{ 
      this.route.navigate(['/index/Error']);
    });
  }
  onSaveService(ServiceGroup){
    this.formValue = this.ServiceGroup.value;
    this.SaveService(this.formValue);
  }
  SaveService(FormValue){
    this.serviceId = FormValue.RoleWorkCategoryId;
    if(this.serviceId == null){ 
      this.mainService.SaveService(FormValue).subscribe(data=>{
        if(data == 'Saved'){
        this.toaster.success("Service Save Successfully.");
        this.GetAllService();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Service Is Already Exist.");
        }
      },
        error =>{ 
          this.route.navigate(['/index/Error']);
        });
    
    }else{
    this.mainService.UpdateService(this.ServiceGroup.value).subscribe(data=>{
      if(data == 'Updated'){
        this.toaster.success("Service Update Successfully.");
        this.GetAllService();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Service Is Already Exist.");
        }
      },
      error =>{ 
        this.route.navigate(['/index/Error']);
      });
    }
  }  
  Delete(RoleWorkCategoryId){
    this.dialog.openConfirmationDialog("Are Sure Delete Service ?").afterClosed().subscribe(res=>{
      if(res){
      this.mainService.DeleteService(RoleWorkCategoryId).subscribe(data=>{
        if(data == "Deleted"){
          this.toaster.success("Service Delete Successfully.");
          this.GetAllService();
          this.reset();
        }else{
          this.toaster.error("Service Is Not Delete, Please Try Again.");
        }
      },error =>{ 
          this.route.navigate(['/index/Error']);
        });
      }
    });
  }
  Edit(RoleWorkCategoryId){
    this.mainService.GetServiceById(RoleWorkCategoryId).subscribe((CatList:any)=>{
      if(CatList!=null){
         this.ServiceGroup.controls['RoleWorkCategoryId'].setValue(CatList[0]['RoleWorkCategoryId']);
        this.ServiceGroup.controls['RoleId'].setValue(CatList[0]['RoleId']);
        this.ServiceGroup.controls['RoleWorkCategoryName'].setValue(CatList[0]['RoleWorkCategoryName']);
      }else{
        this.toaster.error("Data Not Found");
      }
    },
    error =>{ 
      this.route.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
