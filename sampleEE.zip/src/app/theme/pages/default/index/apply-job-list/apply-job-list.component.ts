import { Component, OnInit, ViewChild} from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort} from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router} from '@angular/router';

@Component({
  selector: 'app-apply-job-list',
  templateUrl: './apply-job-list.component.html',
  styles: []
})
export class ApplyJobListComponent implements OnInit {
  dataSource;
  displayedColumns: string[] = ['FirstName','RoleName','OrganizationName','PersonName','MobileNo1','MobileNo2','Address','Latitude','Longitude','Comment','Interested'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private mainService: AlphamobiService,
    private toaster:ToastrService,
    private router:Router) { }

  ngOnInit() {
    this.GetAllEnqiry();
  }
  GetAllEnqiry() {
    this.mainService.GetAllEnqiry().subscribe((data: any) => {
      if(data != null ){
        if(data.length != 0){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error=>{
       this.router.navigate(['/index/Error']);
    });
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
