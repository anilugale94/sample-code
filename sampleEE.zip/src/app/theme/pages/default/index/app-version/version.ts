export class Version {
    Name:string;
    MustRequired:boolean;
}
