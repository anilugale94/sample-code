import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AlphamobiService } from '../services/alphamobi.service'; 
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-app-version',
  templateUrl: './app-version.component.html',
  styles: []
})
export class AppVersionComponent implements OnInit {
dataSource;
VersionGroup:any;
FormValue:any;
error:any; 
displayedColumns: string[] = ['Name','MustRequired'];
@ViewChild(MatPaginator) paginator : MatPaginator;
@ViewChild(MatSort) sort : MatSort;
  constructor(private mainService : AlphamobiService,private toster:ToastrService,private formBuilder:FormBuilder,private route:Router) { }

  ngOnInit() {
    this.VersionGroup = this.formBuilder.group({
      Name:['',Validators.required],
      MustRequired:[false]
    })
    this.reset();
    this.GetAllVersion();
  }
  reset(){
    this.VersionGroup.reset();
  }
  GetAllVersion(){
    this.mainService.GetAllVersion().subscribe(data=>{
      if(data!=null){
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }else{
        this.toster.error("No Data Found");
      }
    },error =>{ 
      this.error = error;
      this.route.navigate(['/index/Error']);
    })
  }
  OnSaveVersion(VersionGroup){
    this.FormValue = this.VersionGroup.value;
    this.SaveVersion(this.FormValue);
  }
  SaveVersion(version){
    this.mainService.SaveVersion(version).subscribe(data=>{
     if(data!=''){
       this.toster.success("Version Save Successfully");
       this.reset();
       this.GetAllVersion();
     } 
     else{
      this.toster.error("Version Not Save");
     }
    },error =>{ 
      this.error = error;
      this.route.navigate(['/index/Error']);
    })
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
