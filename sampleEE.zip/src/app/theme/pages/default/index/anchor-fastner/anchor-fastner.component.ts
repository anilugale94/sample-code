import { Component, OnInit,ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../services/confirm-dialog.service';

@Component({
  selector: 'app-anchor-fastner',
  templateUrl: './anchor-fastner.component.html',
  styles: []
})
export class AnchorFastnerComponent implements OnInit {

  displayedColumns: string[] = ['AnchorFastner','Action'];
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

  dataSource: any;
  FormValue: any;
  AnchorGroup: any;
  AnchorFastnerId: any;

  constructor(private mainService: AlphamobiService, 
    private formBuilder: FormBuilder,
    private toaster:ToastrService,
    private router:Router,
    private dialog:ConfirmDialogService) { }

  ngOnInit() {
    this.AnchorGroup = this.formBuilder.group({
      AnchorFastnerId:[null],
      Name:['',Validators.required]
    });
   this.GetAllAnchorFastner();
  }

  reset(){
    this.AnchorGroup.reset();
  }
  
  GetAllAnchorFastner() {
    this.mainService.GetAllAnchorFastner().subscribe((Catlist: any) => {
      if(Catlist.length != 0){
        if(Catlist != null){
          this.dataSource = new MatTableDataSource(Catlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }

  OnSaveAnchor(AnchorGroup){
    this.FormValue = this.AnchorGroup.value;
    this.SaveAnchor(this.FormValue);
  }

  SaveAnchor(FormValue){
    this.AnchorFastnerId = FormValue.AnchorFastnerId;
    if(this.AnchorFastnerId == null){ 
      this.mainService.SaveAnchorFastner(FormValue).subscribe(data=>{
        if(data == 'Saved'){
        this.toaster.success("Anchor Fastner Save Successfully.");
        this.GetAllAnchorFastner();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Anchor Fastner Is Already Exist.");
        }
      },error =>{ 
          this.router.navigate(['/index/Error']);
        });
    
    }else{
    this.mainService.UpdateAnchorFastner(FormValue).subscribe(data=>{
      if(data == 'Updated'){
        this.toaster.success("Anchor Fastner Update Successfully.");
        this.GetAllAnchorFastner();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Anchor Fastner Is Already Exist.");
        }
      },error =>{ 
        this.router.navigate(['/index/Error']);
      });
    }
  } 
  Delete(AnchorFastnerId){
    this.dialog.openConfirmationDialog("Are Sure Delete Anchor Fastner?").afterClosed().subscribe(res=>{
      if(res){
      this.mainService.DeleteAnchorFastner(AnchorFastnerId).subscribe(data=>{
        console.log(data);
        if(data == 'Deleted'){
          this.toaster.success("Anchor Fastner Delete Successfully.");
          this.GetAllAnchorFastner();
          this.reset();
        }else{
          this.toaster.error("Anchor Fastner Is Not Delete,Please Try Again.");
        }
      },error =>{ 
          this.router.navigate(['/index/Error']);
        });
      }
    });
  }
  Edit(AnchorFastnerId){
    this.mainService.GetAnchorFastnerById(AnchorFastnerId).subscribe((data:any)=>{
      if(data!=null){
        if(data.length != 0){
          this.AnchorGroup.controls['AnchorFastnerId'].setValue(data[0]['AnchorFastnerId']);
          this.AnchorGroup.controls['Name'].setValue(data[0]['Name']);
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },
    error =>{ 
      this.router.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
