import { Component, OnInit,ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
@Component({
  selector: 'app-orientation',
  templateUrl: './orientation.component.html',
  styles: []
})
export class OrientationComponent implements OnInit {
  displayedColumns: string[] = ['Name','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  OrientationGroup: any;
  dataSource;
  FormValue: any;
  OrientationId: any;

  constructor(private mainService: AlphamobiService, 
    private formBuilder: FormBuilder,
    private toaster:ToastrService,
    private route:Router,
    private dialog:ConfirmDialogService) { }

  ngOnInit() {
    this.OrientationGroup = this.formBuilder.group({
      OrientationId:[''],
      Name: ['', Validators.required],
    });
    this.reset();
    this.GetAllOrientaion();
  }
  reset(){
    this.OrientationGroup.reset();
  }
  GetAllOrientaion(){
    this.mainService.GetAllOrientation().subscribe((Projlist: any) => {
      if(Projlist.length != 0){
        if(Projlist != null){
          this.dataSource = new MatTableDataSource(Projlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.route.navigate(['/index/Error']);
    });
  }
  OnSaveRole(OrientationGroup){
    this.FormValue = this.OrientationGroup.value;
    this.SaveOrientation(this.FormValue);
  }
  SaveOrientation(FormValue){
    this.OrientationId = FormValue.OrientationId;
    if(this.OrientationId == null){ 
      this.mainService.SaveOrientation(FormValue).subscribe(data=>{
        if(data == 'Saved'){
        this.toaster.success("Orientation Save Successfully.");
        this.GetAllOrientaion();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Orientation Is Already Exist.");
        }
      },error =>{ 
          this.route.navigate(['/index/Error']);
        });
    
    }else{
    this.mainService.UpdateOrientation(FormValue).subscribe(data=>{
      if(data == 'Updated'){
        this.toaster.success("Orientation Update Successfully.");
        this.GetAllOrientaion();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Orientation Is Already Exist.");
        }
      },error =>{ 
        this.route.navigate(['/index/Error']);
      });
    }
  } 
  Delete(OrientationId){
    this.dialog.openConfirmationDialog("Are Sure Delete Orientation?").afterClosed().subscribe(res=>{
      if(res){
      this.mainService.DeleteOrientation(OrientationId).subscribe(data=>{
        if(data == "Deleted"){
          this.toaster.success("Orientation Delete Successfully.");
          this.GetAllOrientaion();
          this.reset();
        }else{
          this.toaster.error("Orientation Is Not Delete, Please Try Again.");
        }
      },error =>{ 
          this.route.navigate(['/index/Error']);
        });
      }
    });
  }
  Edit(OrientationId){
    this.mainService.GetOrientationById(OrientationId).subscribe((data:any)=>{
      if(data!=null){
        if(data.length != 0){
          this.OrientationGroup.controls['OrientationId'].setValue(data[0]['OrientationId']);
          this.OrientationGroup.controls['Name'].setValue(data[0]['Name']);
        }else{
          this.toaster.error("Data Not Found");
        }
      
      }else{
        this.toaster.error("Data Not Found");
      }
    },
    error =>{ 
      this.route.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
