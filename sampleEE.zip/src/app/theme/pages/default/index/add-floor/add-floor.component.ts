import { Component, OnInit, ViewChild} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatTableDataSource, MatPaginator,MatSort } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
import { ToastrService } from 'ngx-toastr';
  
@Component({
  selector: 'app-add-floor',
  templateUrl: './add-floor.component.html',
  styles: []
})
export class AddFloorComponent implements OnInit {
  FloorGroup;
  @ViewChild(MatPaginator) paginator : MatPaginator;
  @ViewChild(MatSort) sort : MatSort; 
  displayedColumns:string[]=['floorName','BuildingName','projectName','Action'];
  dataSource;
  projectList: any;
  buildingList: any;
  formvalue: any;
  constructor(private mainService : AlphamobiService,
    private router:Router,
    private formBuilder:FormBuilder,
    private confirm:ConfirmDialogService,
    private toastr:ToastrService) { }

  ngOnInit() {
    this.FloorGroup = this.formBuilder.group({
      FloorId:[null],
      ProjectId:['',Validators.required],
      BuildingId:['',Validators.required],
      FloorName:['',Validators.required]
    });
    this.GetAllFloor();
    this.GetAllproject();
    this.reset();
  }
  reset(){
    this.FloorGroup.reset();
  }
  GetAllFloor(){
    this.mainService.GetAllBuildingFloor().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toastr.error("Data not found");
        }
      }else{
        this.toastr.error("Data not found");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  GetAllproject(){
    this.mainService.GetAllProject().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
         this.projectList = data;
        }else{
          this.toastr.error("Data not found");
        }
      }else{
        this.toastr.error("Data not found");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  GetAllBuilding(event){
    this.FloorGroup.controls['BuildingId'].setValue("");
    var projectId = event.value;
    this.mainService.GetBuildingByProjectId(projectId).subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
         this.buildingList = data;
        }else{
          this.toastr.error("Data not found");
        }
      }else{
        this.toastr.error("Data not found");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  onSave(FloorGroup){
    this.formvalue = this.FloorGroup.value;
 
    if(this.formvalue.FloorId == null){
      this.mainService.SaveBuildingFloor(this.formvalue).subscribe((data:any)=>{
        if(data =="Saved"){
            this.toastr.success("Floor save successfully.");
            this.GetAllFloor();
            this.reset();
        }else if(data =="Exist"){
          this.toastr.error("Floor is already exist.");
        }else{
          this.toastr.error("Floor not save, please try again.");
        }
      },error=>{
        this.router.navigate(['index/Error']);
      })
    }else{
      this.mainService.UpdateBuildingFloor(this.formvalue).subscribe((data:any)=>{
        if(data =="Updated"){
            this.toastr.success("Floor update successfully.");
            this.GetAllFloor();
            this.reset();
        }else if(data =="Exist"){
          this.toastr.error("Floor is already exist.");
        }else{
          this.toastr.error("Floor not update, please try again.");
        }
      },error=>{
        this.router.navigate(['index/Error']);
      })
    }
  }
  Edit(FloorId){
    this.mainService.GetBuildingFloorById(FloorId).subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.FloorGroup.controls['FloorId'].setValue(data[0]['FloorId']);
          this.FloorGroup.controls['BuildingId'].setValue(data[0]['BuildingId']);
          this.FloorGroup.controls['ProjectId'].setValue(data[0]['ProjectId']);
          this.FloorGroup.controls['FloorName'].setValue(data[0]['FloorName']);
          this.ScrollTop();
        }else{
          this.toastr.error("Please try again");
        }
      }else{
        this.toastr.error("Please try again");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  Delete(FloorId){
    this.confirm.openConfirmationDialog("Are you sure delete Floor ?").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.DeleteBuildingFloorById(FloorId).subscribe((data:any)=>{
          if(data == "Deleted"){
            this.toastr.success("Floor delete successfully.");
            this.GetAllFloor();
            
          }else{
            this.toastr.error("Floor not delete, please try again.");
          }
        },error=>{
          this.router.navigate(['index/Error']);
        })
      }
    })
  
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
}
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
