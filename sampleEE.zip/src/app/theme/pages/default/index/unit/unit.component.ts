import { Component, OnInit, ViewChild} from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
@Component({
  selector: 'app-unit',
  templateUrl:'./unit.component.html',
  styles: []
})
export class UnitComponent implements OnInit {
  UnitGroup:any;
  dataSource;
  displayedColumns:string[] = ['Name','Action'];
  @ViewChild(MatPaginator) paginator :MatPaginator;
  @ViewChild(MatSort) sort :MatSort;
  formValue: any;
  UnitId: any;
  constructor(private formBuilder:FormBuilder,
              private route:Router,
              private confirm:ConfirmDialogService,
              private mainService:AlphamobiService,
              private toast:ToastrService) { }

  ngOnInit() {
    this.UnitGroup = this.formBuilder.group({
      UnitId:[null],
      Name:['',Validators.required]
    });
    this.reset();
    this.GetAllUnit();
  }
  reset(){
    this.UnitGroup.reset();
  }
  GetAllUnit(){
    this.mainService.GetAllUnit().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toast.error("Data Is Not Found");
        }
      }else{
        this.toast.error("Data Is Not Found");
      }
    },error =>{
      this.route.navigate(['/index/Error']);
    })
  }
  OnSave(UnitGroup){
    this.formValue = this.UnitGroup.value;
    this.SaveUnit(this.formValue);
  }
  SaveUnit(formValue: any) {
    this.UnitId = formValue.UnitId;
    if(this.UnitId == null){
      this.mainService.SaveUnit(this.formValue).subscribe((data:any)=>{
        if(data != null){
          if(data == 'Saved'){
            this.reset();
            this.GetAllUnit();
            this.toast.success("Unit Is Save Successfully.")
          }else if(data == 'Exist'){
            this.toast.error("Unit Is Allready Exist.")
          }else{
            this.toast.error("Unit Is Not Save, please Try Again.")
          }
        }else{  
          this.toast.error("Unit Is Not Save, please Try Again.");
        }
    },error =>{
      this.route.navigate(['/index/Error']);
    })
    }else {
      this.mainService.UpdateUnit(this.formValue).subscribe(data=>{
        if(data == 'Updated'){
          this.toast.success("Unit Is Update Successfuly.");
          this.reset();
          this.GetAllUnit();
        }else{
          this.toast.error("Unit Is Not Update, please Try Again.");
        }
      },error =>{
        this.route.navigate(['/index/Error']);
      })
    }
  }
  Edit(UnitId){
    this.mainService.GetUnitById(UnitId).subscribe((data:any)=>{
        if(data != null){
          if(data.length != 0){
            this.UnitGroup.controls['UnitId'].setValue(data[0]['UnitId']);
            this.UnitGroup.controls['Name'].setValue(data[0]['Name']);
          }else{
            this.toast.error("Unit Is Not Found.");
          }
        }else{
          this.toast.error("Unit Is Not Found.");
        }  
    },error=>{
      this.route.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  Delete(UnitId){
    this.confirm.openConfirmationDialog("Are You Sure Delete Unit ?").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.DeleteUnit(UnitId).subscribe(data=>{
          if(data == 'Deleted'){
            this.toast.success("Unit Is Delete Successfuly.");
            this.GetAllUnit();
            this.reset();
          }else {
            this.toast.success("Unit Is Not Delete, Please Try Again.");
          }
        },error =>{
          this.route.navigate(['/index/Error']);
        })
      }
    })
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
