import { Component, OnInit, ViewChild} from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
@Component({
  selector: 'app-add-company',
  templateUrl:'./add-company.component.html',
  styles: []
})
export class AddCompanyComponent implements OnInit {
  BrandGroup:any;
  dataSource;
  CompanyId:any;
  displayedColumns:string[] = ['Name','Action'];
  @ViewChild(MatPaginator) paginator :MatPaginator;
  @ViewChild(MatSort) sort :MatSort;
  formValue: any;
  constructor(private formBuilder:FormBuilder,
              private route:Router,
              private confirm:ConfirmDialogService,
              private mainService:AlphamobiService,
              private toast:ToastrService) { }

  ngOnInit() {
    this.BrandGroup = this.formBuilder.group({
      CompanyId:[''],
      Name:['',Validators.required]
    });
    this.reset();
    this.GetAllBrand();
  }
  reset(){
    this.BrandGroup.reset();
  }
  GetAllBrand(){
    this.mainService.GetAllCompany().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toast.error("Data Is Not Found");
        }
      }else{
        this.toast.error("Data Is Not Found");
      }
    },error =>{
      this.route.navigate(['/index/Error']);
    })
  }
  OnSave(UnitGroup){
    this.formValue = this.BrandGroup.value;
    this.SaveBrand(this.formValue);
  }
  SaveBrand(formValue: any) {
    this.CompanyId = formValue.CompanyId;
    if(this.CompanyId == null){
      this.mainService.SaveCompany(this.formValue).subscribe((data:any)=>{
        if(data != null){
          if(data == 'Saved'){
            this.reset();
            this.GetAllBrand();
            this.toast.success("Brand Is Save Successfully.")
          }else if(data == 'Exist'){
            this.toast.error("Brand Is Allready Exist.")
          }else{
            this.toast.error("Brand Is Not Save, please Try Again.")
          }
        }else{  
          this.toast.error("Brand Is Not Save, please Try Again.");
        }
    },error =>{
      this.route.navigate(['/index/Error']);
    })
    }else {
      this.mainService.UpdateCompany(this.formValue).subscribe(data=>{
        if(data == 'Updated'){
          this.toast.success("Brand Is Update Successfuly.");
          this.reset();
          this.GetAllBrand();
        }else{
          this.toast.error("Brand Is Not Update, please Try Again.");
        }
      },error =>{
        this.route.navigate(['/index/Error']);
      })
    }
  }
  Edit(CompanyId){
    this.mainService.GetCompanyById(CompanyId).subscribe((data:any)=>{
        if(data != null){
          if(data.length != 0){
            this.BrandGroup.controls['CompanyId'].setValue(data[0]['CompanyId']);
            this.BrandGroup.controls['Name'].setValue(data[0]['Name']);
          }else{
            this.toast.error("Brand Is Not Found.");
          }
        }else{
          this.toast.error("Brand Is Not Found.");
        }  
    },error=>{
      this.route.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  Delete(CompanyId){
    this.confirm.openConfirmationDialog("Are You Sure Delete Brand ?").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.DeleteCompany(CompanyId).subscribe(data=>{
          if(data == 'Deleted'){
            this.toast.success("Brand Is Delete Successfuly.");
            this.GetAllBrand();
            this.reset();
          }else {
            this.toast.success("Brand Is Not Delete, Please Try Again.");
          }
        },error =>{
          this.route.navigate(['/index/Error']);
        })
      }
    })
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
