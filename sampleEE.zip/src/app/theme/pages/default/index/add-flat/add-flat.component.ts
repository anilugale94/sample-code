import { Component, OnInit, ViewChild} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatTableDataSource, MatPaginator,MatSort } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-add-flat',
  templateUrl: './add-flat.component.html',
  styles: []
})
export class AddFlatComponent implements OnInit {
  FlatGroup;
  @ViewChild(MatPaginator) paginator : MatPaginator;
  @ViewChild(MatSort) sort : MatSort; 
  displayedColumns:string[]=['flatName','floorName','BuildingName','projectName','Action'];
  dataSource;
  projectList: any;
  buildingList: any;
  formvalue: any;
  floorList: any;
  constructor(private mainService : AlphamobiService,
              private router:Router,
              private formBuilder:FormBuilder,
              private confirm:ConfirmDialogService,
              private toastr:ToastrService) { }

  ngOnInit() {
    this.FlatGroup = this.formBuilder.group({
      FlatId:[null],
      ProjectId:['',Validators.required],
      BuildingId:['',Validators.required],
      FloorId:['',Validators.required],
      FlatName:['',Validators.required]
    });
    this.GetAllFlat();
    this.GetAllproject();
    this.reset();

  }
  reset(){
    this.FlatGroup.reset();
  }
  GetAllFlat(){
    this.mainService.GetAllBuildingFlat().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toastr.error("Data not found");
        }
      }else{
        this.toastr.error("Data not found");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  GetAllproject(){
    this.mainService.GetAllProject().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
         this.projectList = data;
        }else{
          this.toastr.error("Data not found");
        }
      }else{
        this.toastr.error("Data not found");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  GetAllBuilding(event){
    var ProjectId = event.value;
    this.FlatGroup.controls['BuildingId'].setValue("");
    this.mainService.GetBuildingByProjectId(ProjectId).subscribe((data:any)=>{
      console.log("building",data);
      if(data != null){
        if(data.length != 0){
         this.buildingList = data;
        }else{
          this.toastr.error("Data not found");
        }
      }else{
        this.toastr.error("Data not found");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  GetAllFloor(event){
    var BuildingId = event.value;
    this.FlatGroup.controls['FloorId'].setValue("");
    this.mainService.GetFloorByBuildingId(BuildingId).subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
         this.floorList = data;
        }else{
          this.toastr.error("Data not found");
        }
      }else{
        this.toastr.error("Data not found");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  onSave(FlatGroup){
    this.formvalue = this.FlatGroup.value;
 
    if(this.formvalue.FlatId == null){
      this.mainService.SaveBuildingFlat(this.formvalue).subscribe((data:any)=>{
        if(data =="Saved"){
            this.toastr.success("Flat save successfully.");
            this.reset();
            this.GetAllFlat();
         
        }else if(data =="Exist"){
          this.toastr.error("Flat is already exist.");
        }else{
          this.toastr.error("Flat not save, please try again.");
        }
      },error=>{
        this.router.navigate(['index/Error']);
      })
    }else{
      this.mainService.UpdateBuildingFlat(this.formvalue).subscribe((data:any)=>{
        if(data =="Updated"){
            this.toastr.success("Flat update successfully.");
            this.reset();
            this.GetAllFlat();
          
        }else if(data =="Exist"){
          this.toastr.error("Flat is already exist.");
        }else{
          this.toastr.error("Flat not update, please try again.");
        }
      },error=>{
        this.router.navigate(['index/Error']);
      })
    }
  }
  Edit(FlatId){
    this.mainService.GetBuildingFlatById(FlatId).subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.FlatGroup.controls['FlatId'].setValue(data[0]['PlotId']);
          this.FlatGroup.controls['BuildingId'].setValue(data[0]['BuildingId']);
          this.FlatGroup.controls['ProjectId'].setValue(data[0]['ProjectId']);
          this.FlatGroup.controls['FloorId'].setValue(data[0]['FloorId']);
          this.FlatGroup.controls['FlatName'].setValue(data[0]['PlotName']);
          this.ScrollTop();
        }else{
          this.toastr.error("Please try again");
        }
      }else{
        this.toastr.error("Please try again");
      }
    },error=>{
      this.router.navigate(['index/Error']);
    })
  }
  Delete(FlatId){
    this.confirm.openConfirmationDialog("Are you sure delete Flat ?").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.DeleteBuildingFlatById(FlatId).subscribe((data:any)=>{
          if(data == "Deleted"){
            this.toastr.success("Flat delete successfully.");
            this.GetAllFlat();
            
          }else{
            this.toastr.error("Flat not delete, please try again.");
          }
        },error=>{
          this.router.navigate(['index/Error']);
        })
      }
    })
  
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
}
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
