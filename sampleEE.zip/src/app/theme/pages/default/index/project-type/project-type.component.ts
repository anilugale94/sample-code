import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../services/confirm-dialog.service';

@Component({
  selector: 'app-project-type',
  templateUrl:'./project-type.component.html',
  styles: []
})
export class ProjectTypeComponent implements OnInit {
  ProjTypeGroup:any;
  dataSource;
  displayedColumns: string[] = ['Name','Action'];
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
  FormValue: any;
  ProjectTypeId: any;
  constructor(private mainService: AlphamobiService, private formBuilder: FormBuilder,private toaster:ToastrService,private route:Router,private dialog:ConfirmDialogService) { }

  ngOnInit() {
    this.ProjTypeGroup = this.formBuilder.group({
      ProjectTypeId:[null],
      Name:['',Validators.required]
    });
    this.reset();
    this.GetAllProjectType();
  }
  reset(){
    this.ProjTypeGroup.reset();
  }
  GetAllProjectType() {
    this.mainService.GetAllProjectType().subscribe((Projlist: any) => {
      if(Projlist.length != 0){
        if(Projlist != null){
          this.dataSource = new MatTableDataSource(Projlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.route.navigate(['/index/Error']);
    });
  }
  OnSave(ProjTypeGroup){
    this.FormValue = this.ProjTypeGroup.value;
    this.SaveProjectType(this.FormValue);
  }
  SaveProjectType(FormValue){
    this.ProjectTypeId = FormValue.ProjectTypeId;
    if(this.ProjectTypeId == null){ 
      this.mainService.SaveProjectType(FormValue).subscribe(data=>{
        if(data == 'Saved'){
        this.toaster.success("Project Type Save Successfully.");
        this.GetAllProjectType();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Project Type Is Already Exist.");
        }
      },error =>{ 
          this.route.navigate(['/index/Error']);
        });
    
    }else{
    this.mainService.UpdateProjectType(FormValue).subscribe(data=>{
      if(data == 'Updated'){
        this.toaster.success("Project Type Update Successfully.");
        this.GetAllProjectType();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Project Type Is Already Exist.");
        }
      },error =>{ 
        this.route.navigate(['/index/Error']);
      });
    }
  } 
  Delete(ProjectTypeId){
    this.dialog.openConfirmationDialog("Are Sure Delete Project Type?").afterClosed().subscribe(res=>{
      if(res){
      this.mainService.DeleteProjectType(ProjectTypeId).subscribe(data=>{
        if(data == "Deleted"){
          this.toaster.success("Project Type Delete Successfully.");
          this.GetAllProjectType();
          this.reset();
        }else{
          this.toaster.error("Project Type Is Not Delete, Please Try Again.");
        }
      },error =>{ 
          this.route.navigate(['/index/Error']);
        });
      }
    });
  }
  Edit(ProjectTypeId){
    this.mainService.GetProjectTypeByProjId(ProjectTypeId).subscribe((data:any)=>{
      if(data!=null){
        if(data.length != 0){
          this.ProjTypeGroup.controls['ProjectTypeId'].setValue(data[0]['ProjectTypeId']);
          this.ProjTypeGroup.controls['Name'].setValue(data[0]['Name']);
        }else{
          this.toaster.error("Data Not Found");
        }
      
      }else{
        this.toaster.error("Data Not Found");
      }
    },
    error =>{ 
      this.route.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
