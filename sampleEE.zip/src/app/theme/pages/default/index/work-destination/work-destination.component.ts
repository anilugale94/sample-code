import { Component, OnInit,ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../services/confirm-dialog.service';

@Component({
  selector: 'app-work-destination',
  templateUrl: './work-destination.component.html',
  styles: []
})
export class WorkDestinationComponent implements OnInit {
  displayedColumns: string[] = ['WorkDestination','Action'];
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

  dataSource: any;
  FormValue: any;
  WorkGroup: any;
  WorkDestinationId: any;

  constructor(private mainService: AlphamobiService, 
    private formBuilder: FormBuilder,
    private toaster:ToastrService,
    private router:Router,
    private dialog:ConfirmDialogService) { }

  ngOnInit() {
    this.WorkGroup = this.formBuilder.group({
      WorkDestinationId:[null],
      Name:['',Validators.required]
    });
    this.GetAllWorkDestination();
  }
  reset(){
    this.WorkGroup.reset();
  }
  GetAllWorkDestination() {
    this.mainService.GetAllWorkDestination().subscribe((Catlist: any) => {
      if(Catlist.length != 0){
        if(Catlist != null){
          this.dataSource = new MatTableDataSource(Catlist);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error =>{ 
      this.router.navigate(['/index/Error']);
    });
  }
  OnSaveRole(RoleGroup){
    this.FormValue = this.WorkGroup.value;
    this.SaveRole(this.FormValue);
  }
  SaveRole(FormValue){
    this.WorkDestinationId = FormValue.WorkDestinationId;
    if(this.WorkDestinationId == null){ 
      this.mainService.SaveWorkDestination(FormValue).subscribe(data=>{
        if(data == 'Saved'){
        this.toaster.success("Work Destination Save Successfully.");
        this.GetAllWorkDestination();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Work Destination Is Already Exist.");
        }
      },error =>{ 
          this.router.navigate(['/index/Error']);
        });
    
    }else{
    this.mainService.UpdateWorkDestination(FormValue).subscribe(data=>{
      if(data == 'Updated'){
        this.toaster.success("Work Destination Update Successfully.");
        this.GetAllWorkDestination();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Work Destination Is Already Exist.");
        }
      },error =>{ 
        this.router.navigate(['/index/Error']);
      });
    }
  } 
  Delete(WorkDestinationId){
    this.dialog.openConfirmationDialog("Are Sure Delete Work Destination?").afterClosed().subscribe(res=>{
      if(res){
      this.mainService.DeleteWorkDestination(WorkDestinationId).subscribe(data=>{
        if(data == "Deleted"){
          this.toaster.success("Work Destination Delete Successfully.");
          this.GetAllWorkDestination();
          this.reset();
        }else{
          this.toaster.error("Work Destination Is Not Delete,Please Try Again.");
        }
      },error =>{ 
          this.router.navigate(['/index/Error']);
        });
      }
    });
  }
  Edit(WorkDestinationId){
    this.mainService.GetWorkDestinationById(WorkDestinationId).subscribe((data:any)=>{
      if(data!=null){
        if(data.length != 0){
          this.WorkGroup.controls['WorkDestinationId'].setValue(data[0]['WorkDestinationId']);
          this.WorkGroup.controls['Name'].setValue(data[0]['Name']);
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },
    error =>{ 
      this.router.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}
