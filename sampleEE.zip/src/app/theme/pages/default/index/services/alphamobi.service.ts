import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError } from 'rxjs/operators/catchError';
import 'rxjs/add/operator/map';
import { environment } from '../../../../../../environments/environment';

@Injectable()
export class AlphamobiService {
    Url: string = environment.baseUrl;
    headerOption = new HttpHeaders({'content-type':'application/x-www-form-urlencoded'});
    requestOption = {headers:this.headerOption};
    fileToUpload: File;
    AadhaarFile:File;
    Pancard:File;
    Bank:File;
    Address:File;
    Voting:File;
    uplodfile=[];
    constructor(private http: HttpClient) { }

    private handlerError(errorResponse:HttpErrorResponse){
      if(errorResponse.error instanceof ErrorEvent){
        console.log("Client Side Error:",errorResponse.error.message);
      }else{
        console.log("Server Side Error:",errorResponse);
      }
    return ErrorObservable.create(new Error('oops!'));
    }
     GetallCountCount():Observable<any>{
       return this.http.post(this.Url + 'ADCountGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
  
      GetCategoryAll(): Observable<any> {
          var headerOption = new HttpHeaders({ 'content-type': 'application/json' });
          var requestOption = { headers: headerOption };
          return this.http.post(this.Url + 'ADCategoryGetByAll', requestOption)
          .pipe(catchError(this.handlerError));
      }
      SaveCategory(formValue){
        return this.http.post(this.Url+'ADCategorySave?Name='+ formValue.CategoryName,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      UpdateCategory(formValue){
        return this.http.post(this.Url+'ADCategoryUpdate?CategoryId='+ formValue.CategoryId+'&Name='+formValue.CategoryName,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      DeleteCategory(CategoryId){
        var body = 'CategoryId='+CategoryId;
        return this.http.post(this.Url+'ADCategoryDelete',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      GetCategoryById(CategoryId):Observable<any>{
        var body = 'CategoryId='+CategoryId;
        return this.http.post(this.Url+'ADCategoryGetById',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      GetAllRole():Observable<any>{
        return this.http.post(this.Url+'ADRoleGetByAll',this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      SaveRole(formValue){
        var body = 'Name='+formValue.Name;
        return this.http.post(this.Url+'ADRoleSave',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      UpdateRole(formValue){
        var body = 'RoleId='+formValue.RoleId+'&Name='+formValue.Name;
        return this.http.post(this.Url+'ADRoleUpdate',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      GetRoleById(RoleId){
        var body = 'RoleId='+RoleId;
        return this.http.post(this.Url+'ADRoleGetById',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      DeleteRole(RoleId):Observable<any>{
        var body = 'RoleId='+RoleId;
        return this.http.post(this.Url+'ADRoleDelete',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }

      GetAllWorkDestination():Observable<any>{
        return this.http.post(this.Url+'ADWorkDestinationGetByAll',this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      SaveWorkDestination(formValue){
        var body = 'Name='+formValue.Name;
        return this.http.post(this.Url+'ADWorkDestinationSave',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      UpdateWorkDestination(formValue){
        var body = 'WorkDestinationId='+formValue.WorkDestinationId+'&Name='+formValue.Name;
        return this.http.post(this.Url+'ADWorkDestinationUpdate',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      GetWorkDestinationById(WorkDestinationId){
        var body = 'WorkDestinationId='+WorkDestinationId;
        return this.http.post(this.Url+'ADWorkDestinationGetById',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      DeleteWorkDestination(WorkDestinationId):Observable<any>{
        var body = 'WorkDestinationId='+WorkDestinationId;
        return this.http.post(this.Url+'ADWorkDestinationDelete',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }

      GetAllAnchorFastner():Observable<any>{
        return this.http.post(this.Url+'ADAnchorFastnerGetByAll',this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      SaveAnchorFastner(formValue){
        var body = 'Name='+formValue.Name;
        return this.http.post(this.Url+'ADAnchorFastnerSave',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      UpdateAnchorFastner(formValue){
        var body = 'AnchorFastnerId='+formValue.AnchorFastnerId+'&Name='+formValue.Name;
        return this.http.post(this.Url+'ADAnchorFastnerUpdate',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      GetAnchorFastnerById(AnchorFastnerId){
        var body = 'AnchorFastnerId='+AnchorFastnerId;
        return this.http.post(this.Url+'ADAnchorFastnerGetById',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      DeleteAnchorFastner(AnchorFastnerId):Observable<any>{
        var body = 'AnchorFastnerId='+AnchorFastnerId;
        return this.http.post(this.Url+'ADAnchorFastnerDelete',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      GetTwoRole(){
        return this.http.post(this.Url+'ADRoleGetByContBySup',this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      GetAllJobCat(){
        return this.http.post(this.Url+'ADJobCategoryGetByAll',this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      SaveJobCat(formValue){
        var body = 'Name='+formValue.Name;
        return this.http.post(this.Url+'ADJobCategorySave',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      UpdateJobCat(formValue){
        var body = 'JobCategoryId='+formValue.JobCategoryId+'&Name='+formValue.Name;
        return this.http.post(this.Url+'ADJobCategoryUpdate',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      DeleteJobCat(JobCategoryId):Observable<any>{
        var body = 'JobCategoryId='+JobCategoryId;
        return this.http.post(this.Url+'ADJobCategoryDelete',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      GetJobCatById(JobCategoryId){
        var body = 'JobCategoryId='+JobCategoryId;
        return this.http.post(this.Url+'ADJobCategoryGetById',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      GetAllSliderImg():Observable<any>{
        return this.http.post(this.Url+'ADSliderGetByAll',this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      SaveSliderImage(formValue,fileToUpload){
        var formData:any = new FormData();
        formData.append("file",fileToUpload);
        return this.http.post(this.Url+'ADSliderSave?Name='+formValue.Name,formData).pipe(catchError(this.handlerError));
      }
      UpdateSliderImage(formValue,fileToUpload){
        var formData:any = new FormData();
        formData.append("file",fileToUpload);
         return this.http.post(this.Url+'ADSliderUpdate?SliderId='+formValue.SliderId+'&Name='+formValue.Name,formData).pipe(catchError(this.handlerError));
      }
      GetSliderImageId(SliderId){
        var body = 'SliderId='+SliderId;
        return this.http.post(this.Url+'ADSliderGetById',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
      DeleteSliderImg(SliderId):Observable<any>{
        var body = 'SliderId='+SliderId;
        return this.http.post(this.Url+'ADSliderDelete',body,this.requestOption)
        .pipe(catchError(this.handlerError));
      }
     
      GetByAllUser(){
        return this.http.post(this.Url +'ADUserGetByAll',this.requestOption).pipe(catchError(this.handlerError));
      }
      GetByUserByMobile(formValue){
        var body = 'MobileNo='+formValue.MobileNo;
        return this.http.post(this.Url +'ADUserGetByMobileNo',body,this.requestOption).pipe(catchError(this.handlerError));
      }
      SaveUser(formValue){
        return this.http.post(this.Url +'ADUserSave?RoleId='+formValue.RoleId+'&FirstName='+formValue.FirstName+'&LastName='+formValue.LastName+'&MotherName='+formValue.MotherName+'&FatherName='+formValue.FatherName+'&DOB='+formValue.DOB+'&MobileNo='+formValue.MobileNo+'&EmailId='+formValue.EmailId+'&Gender='+formValue.Gender+'&DOJ='+formValue.DOJ+'&SalaryPerMonth='+formValue.SalaryPerMonth+'&ContractBasicRate='+formValue.ContractBasicRate+'&EndContractDate='+formValue.EndContractDate+'&Address='+formValue.Address,this.requestOption).pipe(catchError(this.handlerError));
      }
      UpdateUser(formValue){
        return this.http.post(this.Url +'ADUserUpdate?UserId='+formValue.UserId+'&RoleId='+formValue.RoleId+'&FirstName='+formValue.FirstName+'&LastName='+formValue.LastName+'&MotherName='+formValue.MotherName+'&FatherName='+formValue.FatherName+'&DOB='+formValue.DOB+'&MobileNo='+formValue.MobileNo+'&EmailId='+formValue.EmailId+'&Gender='+formValue.Gender+'&GST='+formValue.GST+'&Pancard='+formValue.Pancard+'&DOJ='+formValue.DOJ+'&SalaryPerMonth='+formValue.SalaryPerMonth+'&ContractBasicRate='+formValue.ContractBasicRate+'&EndContractDate='+formValue.EndContractDate+'&Address='+formValue.Address,this.requestOption).pipe(catchError(this.handlerError));
      }
      SaveUserImg(UserId,fileToUpload){
        var profile:any = new FormData();
        profile.append("file",fileToUpload);
        return this.http.post(this.Url +'UIUserImgUpdate?UserId='+UserId,profile);
      }
      SaveUserAadhar(UserId,AadhaarFile){
        var Aadhar:any = new FormData();
        Aadhar.append("file",AadhaarFile);
        return this.http.post(this.Url +'UIAadhaarUpdate?UserId='+UserId,Aadhar);
      }
      SaveUserPan(UserId,Pancard){
        var Pan:any = new FormData();
        Pan.append("file",Pancard);
          return this.http.post(this.Url +'UIPancardUpdate?UserId='+UserId,Pan);
      }
      SaveUserVoting(UserId,Voting){
        var voting:any = new FormData();
        voting.append("file",Voting);
          return this.http.post(this.Url +'UIVotingCardUpdate?UserId='+UserId,voting);
      }
      SaveUserAddress(UserId,Address){
        var address:any = new FormData();
        address.append("file",Address);
          return this.http.post(this.Url +'UIAddressProofUpdate?UserId='+UserId,address);
      }
      SaveUserBank(UserId,Bank){
        var bank:any = new FormData();
        bank.append("file",Bank);
          return this.http.post(this.Url +'UIBankStatementUpdate?UserId='+UserId,bank);
      }
     SaveUserService(UserId,RoleWorkCategoryId){
       var body ='UserId='+UserId+'&RoleWorkCategoryId='+RoleWorkCategoryId;
       return this.http.post(this.Url + 'ADUserRoleWorkCategorySave',body,this.requestOption).pipe(catchError(this.handlerError));
     }
     ServiceDelete(UserId){
      var body ='UserId='+UserId;
      return this.http.post(this.Url + 'ADUserRoleWorkCategoryDeleteByUserId',body,this.requestOption).pipe(catchError(this.handlerError));
     }
     GetServiceByUserId(UserId){
       var body = 'UserId='+UserId;
       return this.http.post(this.Url +'ADUserRoleWorkCategoryGetByUserId',body,this.requestOption).pipe(catchError(this.handlerError));
     }
     GetByIdAllUser(UserId):Observable<any>{
        var body = 'UserId='+UserId;
        return this.http.post(this.Url+'ADUserGetById',body,this.requestOption)
        .pipe(catchError(this.handlerError));
     }
     DeleteUser(UserId):Observable<any>{
      var body = 'UserId='+UserId;
      return this.http.post(this.Url+'ADUserDelete',body,this.requestOption)
      .pipe(catchError(this.handlerError));
   }
    UpdateUserStatus(UserId):Observable<any>{
      var body = 'UserId='+ UserId;
      return this.http.post(this.Url+'ADUserUpdateStatus',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }

    GetAllEnqiry(){
      return this.http.post(this.Url + 'ADEnquiryGetByAll',this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    SaveEnquiry(formvalue,lat,lng){
      var id=localStorage.getItem('currentUser');
      var body='UserId='+id+'&ProjectId='+formvalue.ProjectName+'&ProjectAddr='+formvalue.PAddress+'&ContPerName='+formvalue.ContactPerson+'&DepartmentId='+formvalue.CPDepartment+'&Latitude='+lat+'&Longitude='+lng+'&MobileNo='+formvalue.MobileNo+'&EmailId='+formvalue.Email+'&CompWebUrl='+formvalue.CompanyURL;
      return this.http.post(this.Url+'ADEnquirySave',body,this.requestOption).pipe(catchError(this.handlerError));

     //return this.http.post(this.Url+'ADEnquirySave?RoleWorkCategoryId='+formvalue.Service+'ProjectTypeId='+formvalue.ProjType+'ProductId='+formvalue.CompanyProduct+'OrientationId='+formvalue.Orientation+'RateRequiredInId='+formvalue.RateRequiredin+'OrganizationName='+formvalue.ProjectName+'&PersonName='+formvalue.BuilderName+'&Address='+formvalue.PAddress+'&FirstName='+formvalue.ContactPerson+'&RoleName='+formvalue.CPDepartment+'&MobileNo='+formvalue.MobileNo+'&EmailId='+formvalue.EmailId,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetEnqiryById(EnquiryId){
      var body = 'EnquiryId='+EnquiryId;
      return this.http.post(this.Url + 'ADEnquiryGetById',body,this.requestOption)
      .pipe(catchError(this.handlerError)
      );
    }
    GetEnquiryServiceAll(){
      return this.http.post(this.Url+'ADEnquiryServiceGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    // SaveEnquiryService(formvalue){
    //   var body= 'EnquiryId='+formvalue.EnquiryId+'&RoleWorkCategoryId='+formvalue.Service+'&UnitId='+formvalue.UnitId+'&Diameter='+formvalue.Diameter+'&Depth='+formvalue.Depth+'&Hole='+formvalue.Hole+'&Quantity='+formvalue.Quantity;
    //   return this.http.post(this.Url+'ADEnquiryServiceSave',body,this.requestOption).pipe(catchError(this.handlerError));
    // }
    UpdateEnquiryService(formvalue){
      var body= 'EnquiryServiceId='+formvalue.EnquiryServiceId+'&EnquiryId='+formvalue.EnquiryId+'&RoleWorkCategoryId='+formvalue.Service+'&UnitId='+formvalue.UnitId+'&Diameter='+formvalue.Diameter+'&Depth='+formvalue.Depth+'&Hole='+formvalue.Hole+'&Quantity='+formvalue.Quantity;
      return this.http.post(this.Url+'ADEnquiryServiceUpdate',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetEnquiryServiceById(EnquiryServiceId){
      var body= 'EnquiryServiceId='+EnquiryServiceId;
      return this.http.post(this.Url+'ADEnquiryServiceGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteEnquiryServiceById(EnquiryServiceId){
      var body= 'EnquiryServiceId='+EnquiryServiceId;
      return this.http.post(this.Url+'ADEnquiryServiceDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateEnquiryImage1(EnquiryId,fileToUpload)
    {
      var Enquiry1:any = new FormData();
      Enquiry1.append("file",fileToUpload);
      return this.http.post(this.Url +'UIEnquiryUpdateImg1?EnquiryId='+EnquiryId,Enquiry1).pipe(catchError(this.handlerError));
    }
    UpdateEnquiryImage2(EnquiryId,fileToUpload)
    {
      var Enquiry2:any = new FormData();
      Enquiry2.append("file",fileToUpload);
      return this.http.post(this.Url +'UIEnquiryUpdateImg2?EnquiryId='+EnquiryId,Enquiry2).pipe(catchError(this.handlerError));
    }
    GetScopeRequiredGetByRoleWorkCateId(RoleWorkCategoryId){
      var body= 'RoleWorkCategoryId='+RoleWorkCategoryId;
      return this.http.post(this.Url+'ADScopeRequiredGetByRoleWorkCateId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetProjectDeptGetByProjectId(ProjectId){
      var body= 'ProjectId='+ProjectId;
      return this.http.post(this.Url+'ADProjectDeptGetByProjectId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetProductGetByCompanyId(CompanyId){
      var body= 'CompanyId='+CompanyId;
      return this.http.post(this.Url+'ADProductGetByCompanyId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllVersion():Observable<any>{
      return this.http.post(this.Url + 'ADVersionGetByAll',this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    SaveVersion(version):Observable<any>{
        var body = 'Name='+version.Name+'&MustRequired='+version.MustRequired;
        return this.http.post(this.Url+'ADVersionSave',body,this.requestOption)
        .pipe(catchError(this.handlerError));
    }
    GetByAllService():Observable<any>{
      return this.http.post(this.Url + 'ADRoleWorkCategoryGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveService(formValue):Observable<any>{      
      return this.http.post(this.Url + 'ADRoleWorkCategorySave?RoleId='+formValue.RoleId+'&Name='+formValue.RoleWorkCategoryName,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetServiceById(RoleWorkCategoryId):Observable<any>{      
      var body = 'RoleWorkCategoryId='+ RoleWorkCategoryId;
      return this.http.post(this.Url + 'ADRoleWorkCategoryGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateService(formValue):Observable<any>{     
      return this.http.post(this.Url + 'ADRoleWorkCategoryUpdate?RoleWorkCategoryId='+ formValue.RoleWorkCategoryId +'&RoleId='+formValue.RoleId+'&Name='+formValue.RoleWorkCategoryName,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteService(RoleWorkCategoryId):Observable<any>{  
      var body = 'RoleWorkCategoryId='+ RoleWorkCategoryId;   
      return this.http.post(this.Url + 'ADRoleWorkCategoryDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllServiceByRole(RoleId){
      var body = 'RoleId='+ RoleId;   
      return this.http.post(this.Url + 'ADRoleWorkCategoryGetByRoleId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveContractor(formValue){
      return this.http.post(this.Url +'ADUserSave?RoleId='+2+'&FirstName='+formValue.Company+'&LastName='+formValue.ContactName+'&MobileNo='+formValue.MobileNo+'&AlterMobNo='+formValue.OfficeNo+'&EmailId='+formValue.EmailId+'&GST='+formValue.GST+'&Pancard='+formValue.PAN+'&Address='+formValue.Address+'&Description='+formValue.Description+'&LicenseNo='+formValue.LicenseNo,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateContractor(formValue){
      return this.http.post(this.Url +'ADUserUpdate?UserId='+formValue.UserId+'&RoleId='+2+'&FirstName='+formValue.Company+'&LastName='+formValue.ContactName+'&MobileNo='+formValue.MobileNo+'&AlterMobNo='+formValue.OfficeNo+'&EmailId='+formValue.EmailId+'&GST='+formValue.GST+'&Pancard='+formValue.PAN+'&Address='+formValue.Address+'&Description='+formValue.Description+'&LicenseNo='+formValue.LicenseNo,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetByAllUserByRoleId(RoleId){
      var body = 'RoleId='+RoleId;
      return this.http.post(this.Url +'ADUserGetByRoleId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveSupplier(formValue){
      return this.http.post(this.Url +'ADUserSave?RoleId='+2+'&FirstName='+formValue.Company+'&LastName='+formValue.ContactName+'&MobileNo='+formValue.MobileNo+'&AlterMobNo='+formValue.OfficeNo+'&EmailId='+formValue.EmailId+'&GST='+formValue.GST+'&Pancard='+formValue.PAN+'&Address='+formValue.Address+'&Description='+formValue.Description+'&RegistrationNo='+formValue.RegistrationNo,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateSupplier(formValue){
      return this.http.post(this.Url +'ADUserUpdate?UserId='+formValue.UserId+'&RoleId='+2+'&FirstName='+formValue.Company+'&LastName='+formValue.ContactName+'&MobileNo='+formValue.MobileNo+'&AlterMobNo='+formValue.OfficeNo+'&EmailId='+formValue.EmailId+'&GST='+formValue.GST+'&Pancard='+formValue.PAN+'&Address='+formValue.Address+'&Description='+formValue.Description+'&RegistrationNo='+formValue.RegistrationNo,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllClient(){
      return this.http.post(this.Url +'ADClientGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveClient(formValue){
      var body = 'DepartmentId='+formValue.DepId+'&CompanyName='+formValue.CName+'&CompOfficeAddr='+formValue.COffAddress+'&CompBillingAddr='+formValue.CBillAddress+'&CompWebUrl='+formValue.CWebUrl+'&ProjName='+formValue.ProName+'&SiteAddr='+formValue.ProAddress+'&MobileNo='+formValue.MobileNo+'&AlternateMobNo='+formValue.AlternateNo+'&EmailId='+formValue.EmailId;
      return this.http.post(this.Url +'ADClientSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateClient(formValue){
      var body = 'ClientId='+formValue.ClientId+'&DepartmentId='+formValue.DepId+'&CompanyName='+formValue.CName+'&CompOfficeAddr='+formValue.COffAddress+'&CompBillingAddr='+formValue.CBillAddress+'&CompWebUrl='+formValue.CWebUrl+'&ProjName='+formValue.ProName+'&SiteAddr='+formValue.ProAddress+'&MobileNo='+formValue.MobileNo+'&AlternateMobNo='+formValue.AlternateNo+'&EmailId='+formValue.EmailId;
      return this.http.post(this.Url +'ADClientUpdate',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetClientById(ClientId){
      var body = 'ClientId='+ClientId;
      return this.http.post(this.Url +'ADClientGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteClient(ClientId){
      var body = 'ClientId='+ClientId;
      return this.http.post(this.Url +'ADClientDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveClientSiteImg1(ClientId,fileToUpload){  
      var Client1:any = new FormData();
      Client1.append("file",fileToUpload);
      return this.http.post(this.Url +'UIClientUpdateSiteImg1?ClientId='+ClientId,Client1).pipe(catchError(this.handlerError));
    }
    SaveClientSiteImg2(ClientId,fileToUpload){
      var Client2:any = new FormData();
      Client2.append("file",fileToUpload);
      return this.http.post(this.Url +'UIClientUpdateSiteImg2?ClientId='+ClientId,Client2).pipe(catchError(this.handlerError));
    }
    GetAllDepartment(){
      return this.http.post(this.Url + 'ADDepartmentGetByAll',this.requestOption)
      .pipe(catchError(this.handlerError)
      );
    }
    SaveDepartment(formValue){
      var body = 'Name='+formValue.Name;
      return this.http.post(this.Url+'ADDepartmentSave',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    UpdateDepartment(formValue){
      var body = 'DepartmentId='+formValue.DepartmentId+'&Name='+formValue.Name;
      return this.http.post(this.Url+'ADDepartmentUpdate',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    GetDepartmentById(DepartmentId){
      var body = 'DepartmentId='+DepartmentId;
      return this.http.post(this.Url+'ADDepartmentGetById',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    DeleteDepartment(DepartmentId):Observable<any>{
      var body = 'DepartmentId='+DepartmentId;
      return this.http.post(this.Url+'ADDepartmentDelete',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    GetAllUnit(){
      return this.http.post(this.Url + 'ADUnitGetByAll',this.requestOption)
      .pipe(catchError(this.handlerError)
      );
    }
    SaveUnit(formValue){
      var body = 'Name='+formValue.Name;
      return this.http.post(this.Url+'ADUnitSave',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    UpdateUnit(formValue){
      var body = 'UnitId='+formValue.UnitId+'&Name='+formValue.Name;
      return this.http.post(this.Url+'ADUnitUpdate',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    GetUnitById(UnitId){
      var body = 'UnitId='+UnitId;
      return this.http.post(this.Url+'ADUnitGetById',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    DeleteUnit(UnitId):Observable<any>{
      var body = 'UnitId='+UnitId;
      return this.http.post(this.Url+'ADUnitDelete',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    GetAllProject(){
      return this.http.post(this.Url + 'ADProjectGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveProject(formvalue){
      var body = 'Name='+formvalue.ProjectName+'&BuilderId='+formvalue.BuilderName+'&Location='+formvalue.Location+'&Address='+formvalue.PAddress+'&EmailId='+formvalue.EmailId+'&MobileNo='+formvalue.ContNo+'&PersonName='+formvalue.PersonName;
      return this.http.post(this.Url + 'ADProjectSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateProject(formvalue){
      var body = 'ProjectId='+formvalue.ProjectId+'&Name='+formvalue.ProjectName+'&BuilderId='+formvalue.BuilderName+'&Location='+formvalue.Location+'&Address='+formvalue.PAddress+'&EmailId='+formvalue.EmailId+'&MobileNo='+formvalue.ContNo+'&PersonName='+formvalue.PersonName;
      return this.http.post(this.Url+'ADProjectUpdate',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetByIdProject(ProjectId){
      var body = 'ProjectId='+ProjectId;
      return this.http.post(this.Url+'ADProjectGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteProject(ProjectId){
      var body = 'ProjectId='+ProjectId;
      return this.http.post(this.Url+'ADProjectDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveProjectAddress(projectId,formvalue){
      var body = 'ProjectId='+projectId+'&DepartmentId='+formvalue.DepartmentId+'&Address='+formvalue.Address+'&PersonName='+formvalue.PersonName+'&ContactNo='+formvalue.ContactNo+'&EmailId='+formvalue.EmailId;
      return this.http.post(this.Url+'ADProjectDeptSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateProjectAddress(formvalue){
      var body = 'ProjectDeptId='+formvalue.ProjectDeptId+'&ProjectId='+formvalue.ProjectId+'&DepartmentId='+formvalue.DepartmentId+'&Address='+formvalue.Address+'&PersonName='+formvalue.PersonName+'&ContactNo='+formvalue.ContactNo+'&EmailId='+formvalue.EmailId;
      return this.http.post(this.Url+'ADProjectDeptSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllprojectBuilding(){
      return this.http.post(this.Url+'ADBuildingGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveProjectBuilding(formvalue){
      var body = 'ProjectId='+formvalue.ProjectId+'&Name='+formvalue.Building;
      return this.http.post(this.Url+'ADBuildingSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateProjectBuilding(formvalue){
      var body = 'BuildingId='+formvalue.BuildingId+'&ProjectId='+formvalue.ProjectId+'&Name='+formvalue.Building;
      return this.http.post(this.Url+'ADBuildingUpdate',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetProjectBuildingById(BuildingId){
      var body = 'BuildingId='+BuildingId;
      return this.http.post(this.Url+'ADBuildingGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteProjectBuildingById(BuildingId){
      var body = 'BuildingId='+BuildingId;
      return this.http.post(this.Url+'ADBuildingDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllBuildingFloor(){
      return this.http.post(this.Url+'ADFloorGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveBuildingFloor(formvalue){
      var body = 'ProjectId='+formvalue.ProjectId+'&BuildingId='+formvalue.BuildingId+'&Name='+formvalue.FloorName;
      return this.http.post(this.Url+'ADFloorSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateBuildingFloor(formvalue){
      var body = 'FloorId='+formvalue.FloorId+'&BuildingId='+formvalue.BuildingId+'&ProjectId='+formvalue.ProjectId+'&Name='+formvalue.FloorName;
      return this.http.post(this.Url+'ADFloorUpdate',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetBuildingFloorById(FloorId){
      var body = 'FloorId='+FloorId;
      return this.http.post(this.Url+'ADFloorGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteBuildingFloorById(FloorId){
      var body = 'FloorId='+FloorId;
      return this.http.post(this.Url+'ADFloorDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllBuildingFlat(){
      return this.http.post(this.Url+'ADPlotGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveBuildingFlat(formvalue){
      var body = 'ProjectId='+formvalue.ProjectId+'&BuildingId='+formvalue.BuildingId+'&FloorId='+formvalue.FloorId+'&Name='+formvalue.FlatName;
      return this.http.post(this.Url+'ADPlotSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateBuildingFlat(formvalue){
      var body = 'PlotId='+formvalue.FlatId+'&FloorId='+formvalue.FloorId+'&BuildingId='+formvalue.BuildingId+'&ProjectId='+formvalue.ProjectId+'&Name='+formvalue.FlatName;
      return this.http.post(this.Url+'ADPlotUpdate',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetBuildingFlatById(FlatId){
      var body = 'PlotId='+FlatId;
      return this.http.post(this.Url+'ADPlotGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetPlotGetByFloorId(FloorId){
      var body = 'FloorId='+FloorId;
      return this.http.post(this.Url+'ADPlotGetByFloorId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteBuildingFlatById(FlatId){
      var body = 'PlotId='+FlatId;
      return this.http.post(this.Url+'ADPlotDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetBuildingByProjectId(ProjectId){
      var body = 'ProjectId='+ProjectId;
      return this.http.post(this.Url+'ADBuildingGetByProjectId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetFloorByBuildingId(BuildingId){
      var body = 'BuildingId='+BuildingId;
      return this.http.post(this.Url+'ADFloorGetByBuildingId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllProjectType(){
      return this.http.post(this.Url+'ADProjectTypeGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveProjectType(formvalue){
      var body = 'Name='+formvalue.Name;
      return this.http.post(this.Url+'ADProjectTypeSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateProjectType(formvalue){
      var body = 'ProjectTypeId='+formvalue.ProjectTypeId+'&Name='+formvalue.Name;
      return this.http.post(this.Url+'ADProjectTypeUpdate',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetProjectTypeByProjId(ProjectTypeId){
      var body = 'ProjectTypeId='+ProjectTypeId;
      return this.http.post(this.Url+'ADProjectTypeGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteProjectType(ProjectTypeId){
      var body = 'ProjectTypeId='+ProjectTypeId;
      return this.http.post(this.Url+'ADProjectTypeDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllOrientation(){
      return this.http.post(this.Url+'ADOrientationGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveOrientation(formvalue){
      var body = 'Name='+formvalue.Name;
      return this.http.post(this.Url+'ADOrientationSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateOrientation(formvalue){
      var body = 'OrientationId='+formvalue.OrientationId+'&Name='+formvalue.Name;
      return this.http.post(this.Url+'ADOrientationUpdate',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetOrientationById(OrientationId){
      var body = 'OrientationId='+OrientationId;
      return this.http.post(this.Url+'ADOrientationGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteOrientation(OrientationId){
      var body = 'OrientationId='+OrientationId;
      return this.http.post(this.Url+'ADOrientationDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllScopeRequird(){
      return this.http.post(this.Url+'ADScopeRequiredGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveScopeRequird(formvalue){
      var body = 'RoleWorkCategoryId='+formvalue.RoleWorkCategoryId+'&Name='+formvalue.ScopRequired;
      return this.http.post(this.Url+'ADScopeRequiredSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateScopeRequird(formvalue){
      var body = 'ScopeRequiredId='+formvalue.ScopeRequiredId+'RoleWorkCategoryId='+formvalue.RoleWorkCategoryId+'&Name='+formvalue.ScopRequired;
      return this.http.post(this.Url+'ADScopeRequiredUpdate ',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetScopeRequirdById(ScopeRequiredId){
      var body = 'ScopeRequiredId='+ScopeRequiredId;
      return this.http.post(this.Url+'ADScopeRequiredGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteScopeRequird(ScopeRequiredId){
      var body = 'ScopeRequiredId='+ScopeRequiredId;
      return this.http.post(this.Url+'ADScopeRequiredDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllCompany(){
      return this.http.post(this.Url+'ADCompanyGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveCompany(formvalue){
      var body = 'Name='+formvalue.Name;
      return this.http.post(this.Url+'ADCompanySave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateCompany(formvalue){
      var body = 'CompanyId='+formvalue.CompanyId+'&Name='+formvalue.Name;
      return this.http.post(this.Url+'ADCompanyUpdate',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetCompanyById(CompanyId){
      var body = 'CompanyId='+CompanyId;
      return this.http.post(this.Url+'ADCompanyGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteCompany(CompanyId){
      var body = 'CompanyId='+CompanyId;
      return this.http.post(this.Url+'ADCompanyDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllCompanyProd(){
      return this.http.post(this.Url+'ADProductGetByAll',this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveCompanyProd(formvalue,fileToUpload){
      var formData:any = new FormData();
        formData.append("file",fileToUpload);
        
     // var body = 'CompanyId='+formvalue.CompanyId+'&Name='+formvalue.Name+'&Description='+formvalue.Description;
      return this.http.post(this.Url+'ADProductSave?CompanyId='+formvalue.CompanyId+'&Name='+formvalue.Name+'&Description='+formvalue.Description+'&UnitId='+formvalue.Unit+'&Price='+formvalue.MRP+'&OurPrice='+formvalue.OurPrice+'&Quantity='+formvalue.QtyLimit+'&Unit='+formvalue.UnitName,this.requestOption).pipe(catchError(this.handlerError));
    }
    UpdateCompanyProd(formvalue,fileToUpload){
      var formData:any = new FormData();
        formData.append("file",fileToUpload);
      //var body = 'ProductId='+formvalue.ProductId+'&CompanyId='+formvalue.CompanyId+'&Name='+formvalue.Name+'&Description='+formvalue.Description;
      return this.http.post(this.Url+'ADProductUpdate?ProductId='+formvalue.ProductId+'&CompanyId='+formvalue.CompanyId+'&Name='+formvalue.Name+'&Description='+formvalue.Description+'&UnitId='+formvalue.Unit+'&Price='+formvalue.MRP+'&OurPrice='+formvalue.OurPrice+'&Quantity='+formvalue.QtyLimit+'&Unit='+formvalue.UnitName,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetCompanyProdById(ProductId){
      var body = 'ProductId='+ProductId;
      return this.http.post(this.Url+'ADProductGetById',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    DeleteCompanyProd(ProductId){
      var body = 'ProductId='+ProductId;
      return this.http.post(this.Url+'ADProductDelete',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllRateReqUnit(){
      return this.http.post(this.Url + 'ADRateRequiredInGetByAll',this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    SaveRateReqUnit(formValue){
      var body = 'Name='+formValue.Name;
      return this.http.post(this.Url+'ADRateRequiredInSave',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    UpdateRateReqUnit(formValue){
      var body = 'RateRequiredInId='+formValue.RateRequiredInId+'&Name='+formValue.Name;
      return this.http.post(this.Url+'ADRateRequiredInUpdate',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    GetRateReqUnitById(RateRequiredInId){
      var body = 'RateRequiredInId='+RateRequiredInId;
      return this.http.post(this.Url+'ADRateRequiredInGetById',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    DeleteRateReqUnit(RateRequiredInId):Observable<any>{
      var body = 'RateRequiredInId='+RateRequiredInId;
      return this.http.post(this.Url+'ADRateRequiredInDelete',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    SaveQuotation(EnqServiceId,CoreDia,DrillDia,BarDia,AnchorDepth,AnchorDia
      ,CoreDepth,BarDepth,TotalHoleQty,HoleQtyPerDay,Height,Length,TotalSqFt,SqFtQtyPerDay,AnchorFastner,Email){
      var body='EnquiryServiceId='+EnqServiceId+'&CoreDia='+CoreDia+'&DrillDia='+DrillDia+'&BarDia='+BarDia+'&AnchorDepth='+AnchorDepth+'&AnchorDia='+AnchorDia+'&CoreDepth='+CoreDepth+
      '&BarDepth='+BarDepth+'&TotalHoleQty='+TotalHoleQty+'&HoleQtyPerDay='+HoleQtyPerDay+'&Height='+Height+'&Length='+Length+'&TotalSqFt='+TotalSqFt+'&SqFtQtyPerDay='+SqFtQtyPerDay+'&AnchorFastnerId='+AnchorFastner+'&EmailId='+Email;
      console.log("Quotation",body);
      return this.http.post(this.Url+'ADQuotationSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    // GetQuotationGetByEnquiryServiceId(EnquiryServiceId){
    //   var body= 'EnquiryServiceId='+EnquiryServiceId;
    //   return this.http.post(this.Url+'ADQuotationGetByEnquiryServiceId',body,this.requestOption).pipe(catchError(this.handlerError));
    // }
    GetQuotationGetByEnquiryId(EnquiryId){
      var body= 'EnquiryId='+EnquiryId;
      return this.http.post(this.Url+'ADQuotationGetByEnquiryId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    EnquiryServiceSave(EnquiryId,Service,ProjectType,Orientation,RateReq,ProdId){
      var body='EnquiryId='+EnquiryId+'&RoleWorkCategoryId='+Service+'&ProjectTypeId='+ProjectType+'&OrientationId='+Orientation+'&RateRequiredInId='+RateReq+'&ProductId='+ProdId;
      console.log("Service",body);
      return this.http.post(this.Url+'ADEnquiryServiceSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    SaveServiceScopeRequired(EnquiryServiceId,ScopeRequiredId){
      var body = 'EnquiryServiceId='+EnquiryServiceId+'&ScopeRequiredId='+ScopeRequiredId;
      return this.http.post(this.Url+'ADServiceScopeRequiredSave',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetEnqiryServiceByEnqId(EnquiryId){
      var body = 'EnquiryId='+EnquiryId;
      return this.http.post(this.Url+'ADEnquiryServiceGetByEnquiryId',body,this.requestOption)
      .pipe(catchError(this.handlerError)
      );
    }
    GetAllBuilderName():Observable<any>{
      return this.http.post(this.Url+'ADBuilderGetByAll',this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    SaveBuilderName(formValue){
      var body = 'Name='+formValue.Name;
      return this.http.post(this.Url+'ADBuilderSave',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    UpdateBuilderName(formValue){
      var body = 'BuilderId='+formValue.BuilderId+'&Name='+formValue.Name;
      return this.http.post(this.Url+'ADBuilderUpdate',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    GetBuilderNameById(BuilderId){
      var body = 'BuilderId='+BuilderId;
      return this.http.post(this.Url+'ADBuilderGetById',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    DeleteBuilderName(BuilderId):Observable<any>{
      var body = 'BuilderId='+BuilderId;
      return this.http.post(this.Url+'ADBuilderDelete',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    ProjectGetByBuilderId(BuilderId){
      var body = 'BuilderId='+BuilderId;
      return this.http.post(this.Url+'ADProjectGetByBuilderId',body,this.requestOption).pipe(catchError(this.handlerError));
    }
    GetAllWorkOrder():Observable<any>{
      return this.http.post(this.Url+'ADWorkOrderGetByAll',this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    SaveWorkOrder(formValue){
      var body = 'UserId='+formValue.ProjManager+'&BuilderId='+formValue.BuilderId+'&ProjectId='+formValue.ProjectId+'&BuildingId='+formValue.BuildingId+'&FloorId='+formValue.FloorId+'&PlotId='+formValue.PlotId+'&WorkDestinationId='+formValue.Workdest+'&OrientationId='+formValue.orientation+'&OrderNo='+formValue.order;
       return this.http.post(this.Url+'ADWorkOrderSave',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    UpdateWorkOrder(formValue){
      var body = 'WorkOrderId='+formValue.WorkOrderId+'&UserId='+formValue.ProjManager+'&BuilderId='+formValue.BuilderId+'&ProjectId='+formValue.ProjectId+'&BuildingId='+formValue.BuildingId+'&FloorId='+formValue.FloorId+'&PlotId='+formValue.PlotId+'&WorkDestinationId='+formValue.Workdest+'&OrientationId='+formValue.orientation+'&OrderNo='+formValue.order;
      return this.http.post(this.Url+'ADWorkOrderUpdate',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    GetWorkOrderById(WorkOrderId){
      var body = 'WorkOrderId='+WorkOrderId;
      return this.http.post(this.Url+'ADWorkOrderGetById',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    DeleteWorkOrder(WorkOrderId):Observable<any>{
      var body = 'WorkOrderId='+WorkOrderId;
      return this.http.post(this.Url+'ADWorkOrderDelete',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    SaveUserProduct(UserId,ProductId){
      var body = 'UserId='+UserId+'&ProductId='+ProductId;
       return this.http.post(this.Url+'ADUserProductSave',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    GetUserProductGetByUserId(UserId){
      var body = 'UserId='+UserId;
      return this.http.post(this.Url+'ADUserProductGetByUserId',body,this.requestOption)
      .pipe(catchError(this.handlerError));
    }
    UserGetByManager(){
       return this.http.post(this.Url+'ADUserGetByManager',this.requestOption)
      .pipe(catchError(this.handlerError));
    }

}
