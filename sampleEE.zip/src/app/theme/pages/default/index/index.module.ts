import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './index.component';
import { ReactiveFormsModule ,FormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { ToastrModule } from 'ngx-toastr';
import { HttpClientModule } from '@angular/common/http';
import { LayoutModule } from '../../../layouts/layout.module';
import { DefaultComponent } from '../default.component';
import { AlphamobiService } from './services/alphamobi.service';
import { MatToolbarModule, MatButtonModule, MatCheckboxModule, MatSidenavModule, MatIconModule, MatListModule,MatInputModule,MatTableModule,MatPaginatorModule,MatSortModule,MatSelectModule,MatMenuModule,MatGridListModule, MatDialogModule,MatTooltipModule,MatDatepickerModule,MatNativeDateModule, MatProgressSpinnerModule, MatAutocompleteModule } from '@angular/material';
import 'hammerjs';
import { SliderComponent } from './slider/slider.component';
import { AppVersionComponent } from './app-version/app-version.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ErrorComponent } from './error/error.component';
import { ConfirmDialogService } from './services/confirm-dialog.service';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { UserRoleComponent } from './user-role/user-role.component';
import { RoleServiceComponent } from './role-service/role-service.component';
import { JobCategoryComponent } from './job-category/job-category.component';
import { ApplyJobListComponent } from './apply-job-list/apply-job-list.component';
import { UnitComponent } from './unit/unit.component';
import { DepartmentComponent } from './department/department.component';
import { AddProjectManagerComponent } from './add-project-manager/add-project-manager.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { AddBuildingComponent } from './add-building/add-building.component';
import { AddFlatComponent } from './add-flat/add-flat.component';
import { AddFloorComponent } from './add-floor/add-floor.component';
import { ScopeRequiredComponent } from './scope-required/scope-required.component';
import { OrientationComponent } from './orientation/orientation.component';
import { ProductBrandComponent } from './product-brand/product-brand.component';
import { ProjectTypeComponent } from './project-type/project-type.component';
import { AddCompanyComponent } from './add-company/add-company.component';
import { RateReqUnitComponent } from './rate-req-unit/rate-req-unit.component';
import { ProjectDetailsComponent } from './project-details/project-details.component';
import { WorkDestinationComponent } from './work-destination/work-destination.component';
import { AnchorFastnerComponent } from './anchor-fastner/anchor-fastner.component';
import { AddBuilderComponent } from './add-builder/add-builder.component';

const routes: Routes = [
    {
        "path": "",
        "component": DefaultComponent,
        "children": [
            {
                "path": "",
                "component": IndexComponent
            },
            {
                "path": "Add_Role",
                "component": UserRoleComponent
            },
            {
                "path": "Add_Job_Category",
                "component": JobCategoryComponent
            },
            {
                "path": "Apply_Job_List",
                "component": ApplyJobListComponent
            },
         
            {
                "path": "Role_service",
                "component": RoleServiceComponent
            },
           
            {
                "path": "Project_Details/:ProjectId",
                "component": ProjectDetailsComponent
            },
            {
                "path": "Slider_Images",
                "component": SliderComponent,
            },
            {
                "path": "Department",
                "component": DepartmentComponent,
            },
            {
                "path": "Add_Project",
                "component": AddProjectComponent,
            },
            {
                "path": "Add_Building",
                "component": AddBuildingComponent,
            },
            {
                "path": "Add_Builder",
                "component": AddBuilderComponent,
            },
            {
                "path": "Add_Floor",
                "component": AddFloorComponent,
            },
            {
                "path": "Add_Flat",
                "component": AddFlatComponent,
            },
            {
                "path": "Unit",
                "component": UnitComponent,
            },
            {
                "path": "Rate_Unit",
                "component": RateReqUnitComponent,
            },
            {
                "path": "App_Version",
                "component": AppVersionComponent
            },
            {
                "path": "Project_type",
                "component": ProjectTypeComponent,
            },
            {
                "path": "Scope_Required",
                "component": ScopeRequiredComponent
            },
            {
                "path": "Add_Orientation",
                "component": OrientationComponent
            },
            {
                "path": "Product_Brand",
                "component": ProductBrandComponent
            },
            {
                "path": "Brand",
                "component": AddCompanyComponent
            },
            {
                "path": "Work_Destination",
                "component": WorkDestinationComponent
            },
            {
                "path": "Anchor_Fastner",
                "component": AnchorFastnerComponent
            },
            {
                "path": "Error",
                "component": ErrorComponent
            },
	        { path: '**', component: NotFoundComponent }
        ]
    }
];
@NgModule({
    imports: [
        CommonModule, RouterModule.forChild(routes), LayoutModule,
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        HttpClientModule,
        MatToolbarModule,
        MatButtonModule,
        MatSidenavModule,
        MatIconModule,
        MatListModule,
        MatInputModule,
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatSelectModule,
        MatMenuModule,
        MatGridListModule,
        MatCheckboxModule,
        MatDialogModule,
        MatTooltipModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatProgressSpinnerModule,
        MatAutocompleteModule,
        OwlDateTimeModule, 
        OwlNativeDateTimeModule,
       
        ToastrModule.forRoot()
    ], exports: [
        RouterModule,
    ], declarations: [
        IndexComponent,
        SliderComponent,
        AppVersionComponent,
        NotFoundComponent,
        ErrorComponent,
       // ConfirmDialogComponent,
        UserRoleComponent,
        RoleServiceComponent,
        JobCategoryComponent,
        ApplyJobListComponent,
        UnitComponent,
        DepartmentComponent,
        AddProjectManagerComponent,
        AddProjectComponent,
        AddBuildingComponent,
        AddBuilderComponent,
        AddFlatComponent,
        AddFloorComponent,
        ScopeRequiredComponent,
        OrientationComponent,
        ProductBrandComponent,
        ProjectTypeComponent,
        AddCompanyComponent,
        RateReqUnitComponent,
        ProjectDetailsComponent,
        WorkDestinationComponent,
        AnchorFastnerComponent
    ],
    providers: [AlphamobiService,ConfirmDialogService,MatDatepickerModule,DatePipe ],
    //entryComponents:[ConfirmDialogComponent]
})
export class IndexModule {



}