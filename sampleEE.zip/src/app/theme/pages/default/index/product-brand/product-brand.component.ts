import { Component, OnInit,ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { AlphamobiService } from '../services/alphamobi.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ConfirmDialogService } from '../services/confirm-dialog.service';
@Component({
  selector: 'app-product-brand',
  templateUrl: './product-brand.component.html',
  styles: []
})
export class ProductBrandComponent implements OnInit {
  displayedColumns: string[] = ['CompanyName','Product','Description','MRP','OurPrice','Quantity','Unit','UnitName','Action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  
  ProductGroup: any;
  dataSource;
  formValue: any;
  CompanyId:any;
  CompanyList: any;
  ProductId: any;
  fileToUpload: File;
  ImgUrl: any;
  AllUnit: any;

  constructor(private mainService: AlphamobiService, 
    private formBuilder: FormBuilder,
    private toaster:ToastrService,
    private route:Router,
    private confirm:ConfirmDialogService,) { }

  ngOnInit() {
    this.ProductGroup = this.formBuilder.group({
      ProductId:[''],
      CompanyId: ['', Validators.required],
      Name:['',Validators.required],
      Description:['',Validators.required],
      ImgUrl:['',Validators.required],
      MRP:['',Validators.required],
      OurPrice:['',Validators.required],
      QtyLimit:['',Validators.required],
      UnitName:['',Validators.required],
      Unit:['',Validators.required]
    });
    this.reset();
    this.GetAllCompanyProd();
    this.GetAllCompany();
    this.GetAllUnit();
  }
  reset()
  {
    this.ProductGroup.reset();
  }


  GetAllUnit(){
    this.mainService.GetAllUnit().subscribe((data:any)=>{
      if(data != null){
        if(data.length != 0){
          this.AllUnit = data;
        }else{
          this.toaster.error("Data Is Not Found");
        }
      }else{
        this.toaster.error("Data Is Not Found");
      }
    },error =>{
      this.route.navigate(['/index/Error']);
    })
  }

  GetAllCompany(){
    this.mainService.GetAllCompany().subscribe((data:any)=>{
      if(data != 0){
        if(data != null){
         this.CompanyList = data;
        }else{
          this.toaster.error("Data Not Found");
        }

      }else{
        this.toaster.error("Data Not Found");
      }
    },error=>{
      this.route.navigate(['/index/Error']);
    })
  }
  GetAllCompanyProd(){
    this.mainService.GetAllCompanyProd().subscribe((data:any)=>{
      if(data != 0){
        if(data != null){
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }else{
          this.toaster.error("Data Not Found");
        }
      }else{
        this.toaster.error("Data Not Found");
      }
    },error=>{
      this.route.navigate(['/index/Error']);
    })
  }
  OnSave(ProductGroup){
    this.formValue = this.ProductGroup.value;
    this.ProductId = this.formValue.ProductId;
    if(this.ProductId == null){ 
      this.mainService.SaveCompanyProd(this.formValue,this.fileToUpload).subscribe(data=>{

        if(data > 0 ){
        this.toaster.success("Company Product Save Successfully.");
        this.GetAllCompanyProd();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Company Product Is Already Exist.");
        }
      },
        error =>{ 
          this.route.navigate(['/index/Error']);
        });
    
    }else{
    this.mainService.UpdateCompanyProd(this.formValue,this.fileToUpload).subscribe(data=>{
      if(data == 'Updated'){
        this.toaster.success("Company Product Update Successfully.");
        this.GetAllCompanyProd();
        this.reset();
        }else if(data == 'Exist'){
          this.toaster.error("Company Product Is Already Exist.");
        }
      },
      error =>{ 
        this.route.navigate(['/index/Error']);
      });
    }
  }
  Edit(ProductId){
    this.mainService.GetCompanyProdById(ProductId).subscribe((data:any)=>{
        if(data != null){
          if(data.length != 0){
            this.ProductGroup.controls['ProductId'].setValue(data[0]['ProductId']);
            this.ProductGroup.controls['CompanyId'].setValue(data[0]['CompanyId']);
            this.ProductGroup.controls['Name'].setValue(data[0]['ProductName']);
            this.ProductGroup.controls['Description'].setValue(data[0]['Description']);
            this.ProductGroup.controls['MRP'].setValue(data[0]['Price']);
            this.ProductGroup.controls['OurPrice'].setValue(data[0]['OurPrice']);
            this.ProductGroup.controls['QtyLimit'].setValue(data[0]['Quantity']);
            this.ProductGroup.controls['Unit'].setValue(data[0]['Unit']);
            this.ProductGroup.controls['UnitId'].setValue(data[0]['Unit']);
            this.ImgUrl = 'http://eagleconstruction.co.in/'+ data[0]['ImgUrl'];
          }else{
            this.toaster.error("Company Product Is Not Found.");
          }
        }else{
          this.toaster.error("Company Product Is Not Found.");
        }  
    },error=>{
      this.route.navigate(['/index/Error']);
    })
    this.ScrollTop();
  }
  Delete(ProductId){
    this.confirm.openConfirmationDialog("Are You Sure Delete Company Product ?").afterClosed().subscribe(res=>{
      if(res){
        this.mainService.DeleteCompanyProd(ProductId).subscribe(data=>{
          if(data == 'Deleted'){
            this.GetAllCompanyProd();
            this.reset();
            this.toaster.success("Company Product Is Delete Successfuly.");
          }else {
            this.toaster.success("Company Product Is Not Delete, Please Try Again.");
          }
        },error =>{
          this.route.navigate(['/index/Error']);
        })
      }
    });
  }
  ScrollTop() {
    let scrollToTop = window.setInterval(() => {
        let pos = window.pageYOffset;
        if (pos > 0) {
            window.scrollTo(0,0); // how far to scroll on each step
        } else {
            window.clearInterval(scrollToTop);
        }
    }, 0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  ImageChange(file:FileList){
    this.fileToUpload = file.item(0);
    var reader = new FileReader();
    reader.onload=(event:any)=>{
      this.ImgUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }
}
