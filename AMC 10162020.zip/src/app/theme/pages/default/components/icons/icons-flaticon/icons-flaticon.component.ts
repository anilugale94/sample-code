import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
    selector: "app-icons-flaticon",
    templateUrl: "./icons-flaticon.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class IconsFlaticonComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}