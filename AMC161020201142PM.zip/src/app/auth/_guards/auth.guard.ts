import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from "@angular/router";


@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private _router: Router) {
    }

    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        return true;
        // if (localStorage.getItem('Token') != null)
        //     return true;
        // this._router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
        // return false;
    }
}