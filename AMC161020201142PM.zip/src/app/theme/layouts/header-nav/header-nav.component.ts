import { Component, OnInit, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Helpers } from '../../../helpers';
import { LayoutService } from '../layout.service';
import { ToastrService } from 'ngx-toastr';
declare let mLayout: any;
@Component({
    selector: "app-header-nav",
    templateUrl: "./header-nav.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class HeaderNavComponent implements OnInit, AfterViewInit {
    LoginName: any;
    EmailId: any;

    constructor(private LayoutService: LayoutService, private toster: ToastrService) {

    }
    ngOnInit() {

        this.GetAllUser();
    }
    ngAfterViewInit() {

        mLayout.initHeader();

    }
    GetAllUser() {
        var UserId = localStorage.getItem("currentUser");
        this.LayoutService.GetAllUser(UserId).subscribe((data: any) => {
            this.LoginName = data[0]['FirstName'] + data[0]['LastName'];
            this.EmailId = data[0]['EmailId'];
        })
    }
}