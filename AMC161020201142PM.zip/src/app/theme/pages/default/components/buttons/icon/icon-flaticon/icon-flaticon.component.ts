import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
    selector: "app-icon-flaticon",
    templateUrl: "./icon-flaticon.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class IconFlaticonComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}