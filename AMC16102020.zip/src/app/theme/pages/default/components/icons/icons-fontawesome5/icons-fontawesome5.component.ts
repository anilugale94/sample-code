import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
    selector: "app-icons-fontawesome5",
    templateUrl: "./icons-fontawesome5.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class IconsFontawesome5Component implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}