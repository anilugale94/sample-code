import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class LayoutService {
  Url: string = environment.baseUrl + 'api/';
  headerOption = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': 'Bearer ' + localStorage.getItem('Token') });
  requestOption = { headers: this.headerOption };
  constructor(private http: HttpClient) { }
  GetAllUser(UserId) {
    var body = 'UserId=' + UserId;
    return this.http.post(this.Url + 'ADUserGetById', body, this.requestOption);
  }
  GetMACID(Status) {
    var body = 'Status=' + Status;
    return this.http.post(this.Url + 'ADMACChangeGetByStatus', body, this.requestOption)

  }
}
