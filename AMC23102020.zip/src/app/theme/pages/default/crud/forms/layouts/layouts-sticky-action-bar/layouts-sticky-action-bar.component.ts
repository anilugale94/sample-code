import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
    selector: "app-layouts-sticky-action-bar",
    templateUrl: "./layouts-sticky-action-bar.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class LayoutsStickyActionBarComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}