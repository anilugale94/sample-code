import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
    selector: "app-portlets-tabbed",
    templateUrl: "./portlets-tabbed.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class PortletsTabbedComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}