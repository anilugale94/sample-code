import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from "../_models/index";

@Injectable()
export class UserService {
    Url: string = 'http://library.alphamobi.co/api/';
    headerOption = new HttpHeaders({'content-type':'application/x-www-form-urlencoded'});
    requestOption = {headers:this.headerOption};
    constructor(private http: HttpClient) {
    }

    create(formValue) {
       var body = 'FirstName='+formValue.FirstName+'&LastName='+formValue.LastName+'&EmailId='+formValue.EmailId+'&MobileNo='+formValue.MobileNo+'&Gender='+formValue.Gender+'&UserType=Admin';
        return this.http.post(this.Url+'ADUserSave', body,this.requestOption);
    }
    forgotPassword(email: any) {
        var body = 'MobileNo='+email;
        return this.http.post(this.Url + 'UIGetOtp',body,this.requestOption);
    }
    ChangePassword(UserId,Password){
         var body = 'UserId='+UserId+'&Password='+Password+'&UserType=Admin';
        return this.http.post(this.Url+'ADUserUpdatePassword',body,this.requestOption);
    }

    
    // delete(id: number) {
    //     return this.http.delete('/api/users/' + id, this.jwt()).map((response: Response) => response.json());
    // }

    // private helper methods

    
}